import {
  CommonModule,
  HashLocationStrategy,
  LocationStrategy
} from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from './material.module';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import {
  MatMomentDateModule,
  MomentDateAdapter
} from '@angular/material-moment-adapter';
import { NavigationItem } from './core/navbars/navigation/navigation';
import { ApiService } from './services/api.service';
import { UtilityService } from './services/utility.service';
import { LoaderService } from './services/loader.service';
import { AuthService } from './services/auth.service';
import { AuthGuard } from './services/auth.guard';
import { SpinnerComponent } from './shared/components/spinner/spinner.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    // adminRoutes
    // AdminRoutingModule,
    // BrowserModule,
    // NgxPaginationModule,
    NgSelectModule,
    // BrowserAnimationsModule,
    // HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    NgMultiSelectDropDownModule,
    // ModulesModule,
    NgbModule,
    MatSelectModule,
    MatProgressBarModule,
    MatMomentDateModule,
    // NgxMaskModule,
    SpinnerComponent,
    
  ],
  providers: [
    NavigationItem,
    ApiService,
    UtilityService,
    LoaderService,
    AuthService,
    MomentDateAdapter,
    AuthGuard,

    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    }
  ]
})
export class AppComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }
}
