import { Routes } from '@angular/router';
import { AuthGuard } from './services/auth.guard';
import { HomePageComponent } from './component/home-page/home-page.component';
import { MainLayoutComponent } from './component/main-layout/main-layout.component';
import { ResetPasswordComponent } from './component/authentication/reset-password/reset-password.component';
import { SummaryPageComponent } from './component/summary-page/summary-page.component';
import { UploadDocComponent } from './component/upload-doc/upload-doc.component';
import { ScreeningComponent } from './component/screening/screening.component';
import { AuthComponent } from './core/themes/layout/auth/auth.component';
import { LoginComponent } from './component/authentication/login/login.component';
import { ForgotPasswordComponent } from './component/authentication/forget-password/forgot-password.component';
import { ConsolidatedPageComponent } from './component/consolidated-page/consolidated-page.component';
import { DocumentListingComponent } from './component/document-listing/document-listing.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/documents',
    pathMatch: 'full',
  },
  {
    path: '',
    component: AuthComponent,
    children: [
      {
        path: 'login',
        data: { title: 'Login' },
        loadComponent:()=> import('./component/authentication/login/login.component').then(mod => mod.LoginComponent),
      },
      {
        path: 'forgot-password',
        data: { title: 'Forgot' },
        loadComponent:()=> import('./component/authentication/forget-password/forgot-password.component').then(mod => mod.ForgotPasswordComponent),
      },
      {
        path: 'password_reset/:token',
        data: { title: 'Password Reset' },
        loadComponent:()=> import('./component/authentication/reset-password/reset-password.component').then(mod => mod.ResetPasswordComponent),
      },
    ],
  },
  {
    path: '',
    loadComponent:()=> import('./component/main-layout/main-layout.component').then(mod => mod.MainLayoutComponent),
    children: [
      {
        path: 'dashboard',
        data: { title: 'Dashboard', name: 'Dashboard' },
        loadComponent:()=> import('./component/home-page/home-page.component').then(mod => mod.HomePageComponent),
        canActivate: [AuthGuard],
      },
      {
        path: 'documents',
        data: { title: 'Documents', name: 'Document Listing' },
        loadComponent:()=> import('./component/document-listing/document-listing.component').then(mod => mod.DocumentListingComponent),
        canActivate: [AuthGuard],
      },

      {
        path: 'documents/summary/:id',
        data: { title: 'Summary', name: 'Summary Page' },
        loadComponent:()=> import('./component/summary-page/summary-page.component').then(mod => mod.SummaryPageComponent),
        canActivate: [AuthGuard],
      },
      {
        path: 'documents/summary/:documentId/Screening/:childDocumentId',
        data: { title: 'Screening', name: 'Consolidated Page' },
        loadComponent:()=> import('./component/consolidated-page/consolidated-page.component').then(mod => mod.ConsolidatedPageComponent),
        canActivate: [AuthGuard],
      },
      {
        path: 'upload',
        data: { title: 'Upload', name: 'Document Upload' },
        loadComponent:()=> import('./component/upload-doc/upload-doc.component').then(mod => mod.UploadDocComponent),
        canActivate: [AuthGuard],
      },
      {
        path: 'admin',
        loadChildren: () =>
          import('./modules/admin/admin-routing.module').then(
            (module) => module.AdminRoutingModule
          ),
      },
    ],
  },
  {
    path: '**',
    redirectTo: '/documents',
    pathMatch: 'full',
  },
];


