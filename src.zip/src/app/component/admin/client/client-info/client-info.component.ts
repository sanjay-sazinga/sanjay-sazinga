import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-client-info',
  templateUrl: './client-info.component.html',
  styleUrls: ['./client-info.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule]
})
export class ClientInfoComponent {
  @Input() client: any;
  @Input() clientUsers: any;
  @Input() clientApprovers: any;
  @Input() clientAnalysts: any;

  constructor(public modal: NgbActiveModal) {}
}
