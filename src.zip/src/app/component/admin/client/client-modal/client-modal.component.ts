import { Component, Input, OnInit } from '@angular/core';
import {
  NgbActiveModal,
  NgbDatepickerModule
} from '@ng-bootstrap/ng-bootstrap';
import { ClientService } from '../../../../services/client.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaskDirective, NgxMaskPipe } from 'ngx-mask';

@Component({
  selector: 'app-client-modal',
  templateUrl: './client-modal.component.html',
  styleUrls: ['./client-modal.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,ReactiveFormsModule, NgxMaskDirective, NgxMaskPipe,NgbDatepickerModule]
})
export class ClientModalComponent implements OnInit {
  public maskTeleUS = [
    '(',
    /\d/,
    /\d/,
    /\d/,
    ')',
    ' ',
    /\d/,
    /\d/,
    /\d/,
    '-',
    /\d/,
    /\d/,
    /\d/,
    /\d/
  ];
  @Input()
  public client: any = {};
  public clientExists: boolean;
  public startEnd: boolean;
  public showEmailRequiredError = false;
  public emailError = '';

  public showNameRequiredError: boolean;
  public showPhoneRequiredError: boolean;
  public nameError = '';
  public phoneError = '';

  constructor(
    public modal: NgbActiveModal,
    private clientService: ClientService
  ) {}

  isDateRangeInvalid(): boolean {
    return (
      new Date(this.client.startDate).getTime() >=
      new Date(this.client.endDate).getTime()
    );
  }

  saveClient(): void {
    if (this.client.email == undefined) {
      this.showEmailRequiredError = true;
      this.emailError = 'Enter E-Mail ID';
    }
    if (this.client.name == undefined) {
      this.showNameRequiredError = true;
      this.nameError = 'Enter Name';
    }
    if (this.client.phone == undefined) {
      this.showPhoneRequiredError = true;
      this.phoneError = 'Enter Phone';
    }

    if (
      this.client.phone != undefined &&
      this.client.name != undefined &&
      this.client.email != undefined
    ) {
      this.showEmailRequiredError = false;
      this.showNameRequiredError = false;
      this.showPhoneRequiredError = false;

      if (this.client._id) {
        if (this.isDateRangeInvalid()) {
          this.startEnd = true;
          return;
        }
        this.modal.close(this.client);
      } else {
        this.clientService.fetchAllClients(null).then((clients: any[]) => {
          for (let i = 0; i < clients.length; i++) {
            if (
              this.client.name.toLowerCase() === clients[i].name.toLowerCase()
            ) {
              this.clientExists = true;
              return;
            }
          }
          if (this.isDateRangeInvalid()) {
            this.startEnd = true;
            return;
          }
          this.modal.close(this.client);
        });
      }
    }
  }

  ngOnInit(): void {
    if (this.client._id) {
      this.client.startDate = this.client.startDate.split('T')[0];
      this.client.endDate = this.client.endDate.split('T')[0];
    }
  }
}
