import { Component, OnInit, ViewChild } from '@angular/core';
import { ClientService } from '../../../services/client.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from '../../../services/user.service';
import { ClientModalComponent } from './client-modal/client-modal.component';
import { ClientInfoComponent } from './client-info/client-info.component';
import { ToastrService, ToastContainerDirective } from 'ngx-toastr';
// import {NgxMaskModule} from 'ngx-mask';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardComponent } from 'src/app/shared/components/card/card.component';
import { DataTablesModule } from 'angular-datatables';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CardComponent,
    DataTablesModule,
    ClientModalComponent,
    ClientInfoComponent,
  ],
})
export class ClientComponent implements OnInit {
  @ViewChild(ToastContainerDirective, { static: true })
  toastContainer: ToastContainerDirective;
  clients: any[] = [];
  expand: any[] = [];
  inactive = 0;
  active = 0;
  users: any[] = [];
  ClientUsers: any = {};
  ClientApprovers: any = {};
  ClientAnalyst: any = {};

  constructor(
    private clientService: ClientService,
    private ngbModalService: NgbModal,
    private userService: UserService,
    private toast: ToastrService
  ) {}

  ngOnInit(): void {
    this.toast.overlayContainer = this.toastContainer;
    this.fetchClients();
    this.getUsers();
  }
  refreshPage(): void {
    this.clients = [];
    this.fetchClients();
  }

  viewClientInfo(client) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      ClientInfoComponent,
      {
        size: 'lg',
        centered: true,
      }
    );
    modalRef.componentInstance.client = client;
    let Approvers = [];
    let Analysts = [];
    let Users = [];
    Approvers = this.ClientApprovers[client._id];
    Analysts = this.ClientAnalyst[client._id];
    Users = this.ClientUsers[client._id];
    modalRef.componentInstance.clientApprovers = Approvers;
    modalRef.componentInstance.clientAnalysts = Analysts;
    modalRef.componentInstance.clientUsers = Users;
  }

  addClient() {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      ClientModalComponent,
      {
        size: 'lg',
        centered: true,
      }
    );
    modalRef.result
      .then((client: any) => {
        this.clientService
          .createClient(client)
          .then((clients) => {
            this.refreshPage();
          })
          .catch((err) => {
            this.refreshPage();
          });
      })
      .catch((err) => {
        this.refreshPage();
      });
  }

  editClient(client: any) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      ClientModalComponent,
      {
        size: 'lg',
        centered: true,
      }
    );
    modalRef.componentInstance.client = client;
    modalRef.result
      .then((client: any) => {
        this.clientService
          .editClient(client)
          .then((clients) => {
            this.refreshPage();
          })
          .catch((err) => {
            this.refreshPage();
          });
      })
      .catch((err) => {
        this.refreshPage();
      });
  }

  deleteClient(client: any) {
    Swal.fire({
      title: 'Delete Client !',
      text:
        'Are you sure you want to delete "' +
        client.name +
        '" from the system ?',
      icon: 'warning',
      showCloseButton: true,
      showCancelButton: true,
    }).then((willDelete) => {
      if (!willDelete.dismiss) {
        this.clientService
          .deleteClient(client._id)
          .then((response) => {
            this.toast.success(
              'Success',
              'Client "' + client.name + '" Deleted Successfully!',
              {
                timeOut: 5000,
                toastClass: 'ngx-toastr',
                closeButton: true,
              }
            );
            this.refreshPage();
          })
          .catch(() => {
            this.refreshPage();
          });
      }
    });
  }

  restoreClient(client: any) {
    Swal.fire({
      title: 'Restore Client !',
      text:
        'Are you sure you want to restore "' +
        client.name +
        '" from the system ?',
      icon: 'warning',
      showCloseButton: true,
      showCancelButton: true,
    }).then((willDelete) => {
      if (!willDelete.dismiss) {
        this.clientService
          .restoreClient(client._id)
          .then((response) => {
            this.toast.success(
              'Success',
              'Client "' + client.name + '" Restored Successfully!',
              {
                closeButton: true,
                timeOut: 5000,
                toastClass: 'ngx-toastr',
              }
            );
            this.refreshPage();
          })
          .catch(() => {
            this.refreshPage();
          });
      }
    });
  }

  fetchClients() {
    this.clientService.fetchAllClients({ all: true }).then((clients) => {
      this.clients = clients;
      this.expand = [];
      this.inactive = 0;
      for (let i = 0; i < this.clients.length; i++) {
        this.expand[i] = false;
        if (this.clients[i].is_deleted) {
          this.inactive = this.inactive + 1;
        }
      }
      this.active = this.clients.length - this.inactive;
    });
  }
  getUsers() {
    this.userService.getAll().then((response) => {
      this.users = response.users;
      this.users.forEach((user) => {
        if (user.status == 'Active') {
          user.roles.forEach((role) => {
            if (role.parentRole.name === 'Approver') {
              user.clients.forEach((client) => {
                if (this.ClientApprovers[client._id] == undefined) {
                  this.ClientApprovers[client._id] = [];
                  this.ClientApprovers[client._id].push(user.email);
                } else {
                  this.ClientApprovers[client._id].push(user.email);
                }
              });
            } else if (role.parentRole.name === 'Analyst') {
              user.clients.forEach((client) => {
                if (this.ClientAnalyst[client._id] == undefined) {
                  this.ClientAnalyst[client._id] = [];
                  this.ClientAnalyst[client._id].push(user.email);
                } else {
                  this.ClientAnalyst[client._id].push(user.email);
                }
              });
            } else if (
              user.roles.length > 1 &&
              role.parentRole.name === 'Client'
            ) {
              user.clients.forEach((client) => {
                if (this.ClientUsers[client._id] == undefined) {
                  this.ClientUsers[client._id] = [];
                  this.ClientUsers[client._id].push(user.email);
                } else {
                  this.ClientUsers[client._id].push(user.email);
                }
              });
            } else {
              user.clients.forEach((client) => {
                if (this.ClientUsers[client._id] == undefined) {
                  this.ClientUsers[client._id] = [];
                  this.ClientUsers[client._id].push(user.email);
                } else {
                  this.ClientUsers[client._id].push(user.email);
                }
              });
            }
          });
        }
      });
    });
  }
}
