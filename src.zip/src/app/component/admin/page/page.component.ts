import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Node } from '../tree-view/treeViewNode';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TreeViewComponent } from 'src/app/component/admin/tree-view/tree-view.component';
import { PageService } from './page.service';
import { RoleService } from '../role/role.service';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, TreeViewComponent]
})
export class PageComponent implements OnInit {
  @Input() roleId: any;
  @Input() parentRoleId: any;
  @Input() page: any;

  action = 'Edit';
  subRole: any = {};
  system: any = { pages: [] };
  selected: any = { page: null };

  items: Node[] = [];

  constructor(
    public modal: NgbActiveModal,
    private roleService: RoleService,
    private pageService: PageService
  ) {}

  save(): void {
    if (this.selected.page) {
      this.selected.page.allowedComponent =
        this.selected.page.components.reduce((result, component) => {
          if (component.selected) {
            result.push(component.name);
          }
          return result;
        }, []);

      this.subRole.pageFilters.push(this.selected.page);
      this.roleService
        .saveSubRole(this.subRole)
        .then((response) => {
          this.modal.close();
        })
        .catch((error) => {
          this.modal.dismiss();
        });
    }
  }

  redrawTree(): void {
    this.items = [];
    this.system.pages.forEach((pg) => {
      if (pg.selected) {
        const children = [];
        if (this.selected.page && this.selected.page.selectableComponents) {
          this.selected.page.selectableComponents.forEach((comp) => {
            if (comp.selected) {
              children.push({
                name: comp.name
              });
            }
          });
        }
        this.items.push({
          name: pg.name,
          children: children
        });
      }
    });
  }

  displayComponent(page) {
    this.system.pages.forEach((pg) => {
      if (pg.name !== page.name) {
        pg.selected = false;
      }
    });
    if (this.selected.page) {
      this.selected.page = null;
      this.selected.componentDisplay = false;
      this.selected.showExploreDrawer = false;
    }
    if (page.selected) {
      this.selected.componentDisplay = true;
      this.selected.showExploreDrawer = true;
      this.selected.page = page;
      this.selected.page.selectableComponents = this.selected.page.components;
    }
    this.redrawTree();
  }

  filterSystemPages(page): void {
    this.system.pages = this.system.pages.filter((sysPage) => {
      const pageFound = sysPage.name === page.name;
      if (pageFound) {
        page.components = sysPage.components;
        page.components.forEach((component) => {
          component.selected = page.allowedComponent.includes(component.name);
        });
      }
      return !pageFound;
    });
  }

  populatePageFilters(pageFilters: any[]): void {
    if (this.page) {
      let pageIndex = -1;
      pageFilters.forEach((pageFilter, index) => {
        if (pageFilter.name === this.page.name) {
          pageIndex = index;
        }
      });
      pageFilters.splice(pageIndex, 1);
    }
    this.pageService.listPages().then((response) => {
      if (this.page) {
        this.system.pages = response.filter((sysPage) => {
          return sysPage.name === this.page.name;
        });
        if (this.system.pages[0] && this.system.pages[0].components) {
          this.system.pages[0].components =
            this.system.pages[0].components.reduce((result, component) => {
              result.push({
                name: component,
                selected: this.page.allowedComponent.indexOf(component) !== -1
              });
              return result;
            }, []);
          this.system.pages[0].selected = true;
          this.displayComponent(this.system.pages[0]);
        }
      } else {
        this.system.pages = response;
        this.system.pages.forEach((page) => {
          page.components = page.components.reduce((result, component) => {
            result.push({ name: component, selected: true });
            return result;
          }, []);
        });

        pageFilters.forEach((page) => {
          this.filterSystemPages(page);
          if (!page.components && page.allowedComponent) {
            page.components = page.allowedComponent.reduce(
              (result, component) => {
                result.push({ name: component, selected: true });
                return result;
              },
              []
            );
          }
        });
      }
    });
  }

  ngOnInit(): void {
    this.subRole.parentRoleId = this.parentRoleId;
    this.roleService.getSubRole(this.roleId).then((response) => {
      Object.assign(this.subRole, response);
      this.subRole.parentRoleId = this.subRole.parentRole;
      this.populatePageFilters(this.subRole.pageFilters);
      this.redrawTree();
    });
  }
}
