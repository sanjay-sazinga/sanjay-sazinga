import { Component, Input, OnInit } from '@angular/core';
import {
  NgbActiveModal,
  NgbModal,
  NgbModalRef
} from '@ng-bootstrap/ng-bootstrap';
import { SubRoleInfoComponent } from '../sub-role-info/sub-role-info.component';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/material.module';
import { RoleService } from '../role.service';

@Component({
  selector: 'app-role-info',
  templateUrl: './role-info.component.html',
  styleUrls: ['./role-info.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    SubRoleInfoComponent
  ]
})
export class RoleInfoComponent implements OnInit {
  @Input()
  role: any;
  subRoles: any[] = [];
  active = true;

  constructor(
    public modal: NgbActiveModal,
    private ngbModalService: NgbModal,
    private roleService: RoleService
  ) {}

  viewSubRoleInfo(subRole) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      SubRoleInfoComponent,
      {
        size: 'lg',
        centered: true
      }
    );
    modalRef.componentInstance.id = subRole._id;
    modalRef.componentInstance.users = subRole.users;
    this.active = false;
    modalRef.result
      .then(() => {
        this.active = true;
      })
      .catch(() => {
        this.active = true;
      });
  }

  editSubRole(subRole) {
    this.modal.close({
      editSubRole: subRole._id
    });
  }

  deleteSubRole(subRole) {
    Swal.fire({
      title: 'Delete Sub-Role !',
      text:
        'Are you sure you want to delete ' +
        subRole.name +
        ' from the system ?',
      icon: 'warning',
      showCloseButton: true,
      showCancelButton: true
    }).then((willDelete) => {
      if (!willDelete.dismiss) {
        this.roleService
          .deleteSubRole(subRole._id)
          .then((response) => {
            this.modal.close();
          })
          .catch(() => {
            this.modal.close();
          });
      }
    });
  }

  refresh(): void {
    this.subRoles = [];
    this.roleService.getParentRole(this.role._id).then((response) => {
      this.subRoles = response.subRoles.filter((item) => {
        return item.status === 'Active';
      });
    });
  }

  ngOnInit(): void {
    this.subRoles = JSON.parse(JSON.stringify(this.role.subRoles));
    this.subRoles = this.subRoles.filter((item) => {
      return item.status === 'Active';
    });
  }
}
