import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoleService } from '../role.service';

@Component({
  selector: 'app-role-modal',
  templateUrl: './role-modal.component.html',
  styleUrls: ['./role-modal.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, NgbNavModule]
})
export class RoleModalComponent implements OnInit {
  @Input()
  public role: any = {};
  public subRole: any = {};
  public subRoles: any[] = [];
  public showNameRequiredError: boolean;
  public showSubNameRequiredError: boolean;
  public isRoleExists: boolean;
  public isSubRoleExists: boolean;
  public nameError= '';
  public subRoleNameError = '';
  public activeTab = 1;
  public roleTab = true;
  public subRoleTab: boolean;
  public action= 'Add';

  constructor(public modal: NgbActiveModal, private roleService: RoleService) {}

  resetVariables(): void {
    this.isRoleExists = false;
    this.isSubRoleExists = false;
    this.showSubNameRequiredError = false;
    this.showNameRequiredError = false;
  }

  saveRole(): void {
    this.roleService.checkNameExist(this.role).then((resp) => {
      if (resp.nameExist) {
        this.isRoleExists = true;
        return;
      } else {
        this.roleService
          .saveRole(this.role)
          .then((data) => {
            this.role = data.role;
            this.resetVariables();
            this.activeTab = 2;
            this.subRoleTab = true;
          })
          .catch((error) => {
            console.error('error', error);
          });
      }
    });
  }

  getAllSubRoles(): void {
    this.roleService.getAllSubRoles(this.role._id).then((subRoles) => {
      this.subRoles = subRoles;
    });
  }

  saveSubRole(): void {
    const checkNameRoleObj = {
      _id: this.subRole._id,
      name: this.subRole.name,
      parentRoleId: this.role._id
    };
    this.roleService.checkSubRoleNameExist(checkNameRoleObj).then((resp) => {
      if (resp.found) {
        this.isSubRoleExists = true;
      } else {
        this.subRole.parentRoleId = this.role._id;
        this.subRole.parentRole = this.role;
        this.subRole.priority = this.subRoles.length + 1;
        this.roleService
          .saveSubRole(this.subRole)
          .then((response) => {
            this.getAllSubRoles();
            this.subRole = {};
            this.resetVariables();
          })
          .catch(() => {
            this.getAllSubRoles();
            this.resetVariables();
          });
      }
    });
  }

  editSubRole(subRole): void {
    this.showSubNameRequiredError = false;
    this.subRole = JSON.parse(JSON.stringify(subRole));
  }

  clearSubRole(): void {
    this.subRole = {};
  }

  ngOnInit(): void {
    if (this.role._id) {
      this.action = 'Edit';
      this.roleService.getParentRole(this.role._id).then((response) => {
        this.role = response;
        this.subRoles = this.role.subRoles.filter((item) => {
          return item.status === 'Active';
        });
        this.subRoleTab = true;
      });
    }
  }
}
