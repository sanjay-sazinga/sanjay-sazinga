import { Component, OnInit } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { RoleModalComponent } from './role-modal/role-modal.component';
import Swal from 'sweetalert2';
import { RoleInfoComponent } from './role-info/role-info.component';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardComponent } from 'src/app/shared/components/card/card.component';
import { DataTablesModule } from 'angular-datatables';
import { RoleService } from './role.service';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CardComponent,
    DataTablesModule,
    RoleModalComponent
  ]
})
export class RoleComponent implements OnInit {
  roles: any[] = [];

  constructor(
    private roleService: RoleService,
    private ngbModalService: NgbModal,
    private router: Router
  ) {}

  refreshPage(): void {
    this.roles = [];
    this.fetchRoles();
  }

  addRole() {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      RoleModalComponent,
      {
        size: 'lg',
        centered: true
      }
    );
    modalRef.result
      .then(() => {
        this.refreshPage();
      })
      .catch(() => {
        this.refreshPage();
      });
  }

  editRole(role: any) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      RoleModalComponent,
      {
        size: 'lg',
        centered: true
      }
    );
    modalRef.componentInstance.role = role;
    modalRef.result
      .then(() => {
        this.refreshPage();
      })
      .catch(() => {
        this.refreshPage();
      });
  }

  deleteRole(role: any) {
    Swal.fire({
      title: 'Delete Role !',
      text:
        'Are you sure you want to delete ' + role.name + ' from the system ?',
      icon: 'warning',
      showCloseButton: true,
      showCancelButton: true
    }).then((willDelete) => {
      if (!willDelete.dismiss) {
        this.roleService
          .deleteRole(role._id)
          .then((response) => {
            this.refreshPage();
          })
          .catch(() => {
            this.refreshPage();
          });
      }
    });
  }

  fetchRoles(): void {
    this.roleService.getAll().then((response) => {
      this.roles = response.roles;
    });
  }

  viewRoleInfo(role): void {
    const modalRef: NgbModalRef = this.ngbModalService.open(RoleInfoComponent, {
      size: 'lg',
      centered: true
    });
    modalRef.componentInstance.role = role;
    modalRef.result
      .then((res) => {
        if (res && res.editSubRole) {
          this.router.navigateByUrl('/admin/editsubrole/' + res.editSubRole);
        } else {
          this.refreshPage();
        }
      })
      .catch(() => {
        this.refreshPage();
      });
  }

  ngOnInit(): void {
    this.fetchRoles();
  }
}
