import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubRoleInfoComponent } from './sub-role-info.component';

describe('SubRoleInfoComponent', () => {
  let component: SubRoleInfoComponent;
  let fixture: ComponentFixture<SubRoleInfoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SubRoleInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubRoleInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
