import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Node } from '../../tree-view/treeViewNode';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/material.module';
import { TreeViewComponent } from 'src/app/component/admin/tree-view/tree-view.component';
import { RoleService } from '../role.service';

@Component({
  selector: 'app-sub-role-info',
  templateUrl: './sub-role-info.component.html',
  styleUrls: ['./sub-role-info.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    TreeViewComponent
  ]
})
export class SubRoleInfoComponent implements OnInit {
  @Input()
  id: string;
  @Input()
  users: any[] = [];
  subRole: any = {};
  items: Node[] = [];

  constructor(public modal: NgbActiveModal, private roleService: RoleService) {}

  ngOnInit(): void {
    this.roleService.getSubRole(this.id).then((resp) => {
      this.subRole = resp;
      this.subRole.pageFilters.forEach((page) => {
        const children = [];
        page.allowedComponent.forEach((comp) => {
          children.push({
            name: comp
          });
        });
        this.items.push({
          name: page.name,
          children: children
        });
      });
    });
  }
}
