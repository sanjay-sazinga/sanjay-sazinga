import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageFilterInfoComponent } from './page-filter-info.component';

describe('PageFilterInfoComponent', () => {
  let component: PageFilterInfoComponent;
  let fixture: ComponentFixture<PageFilterInfoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ PageFilterInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageFilterInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
