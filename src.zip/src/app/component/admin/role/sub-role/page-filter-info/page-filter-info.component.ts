import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Node } from '../../../tree-view/treeViewNode';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TreeViewComponent } from 'src/app/component/admin/tree-view/tree-view.component';

@Component({
  selector: 'app-page-filter-info',
  templateUrl: './page-filter-info.component.html',
  styleUrls: ['./page-filter-info.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, TreeViewComponent]
})
export class PageFilterInfoComponent implements OnInit {
  @Input()
  page: any;
  items: Node[] = [];

  constructor(public modal: NgbActiveModal) {}

  ngOnInit(): void {
    const children = [];
    this.page.allowedComponent.forEach((comp) => {
      children.push({
        name: comp
      });
    });
    this.items.push({
      name: this.page.name,
      children: children
    });
  }
}
