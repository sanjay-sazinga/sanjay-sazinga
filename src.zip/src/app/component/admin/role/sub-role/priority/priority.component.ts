import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import {
  CdkDragDrop,
  DragDropModule,
  moveItemInArray
} from '@angular/cdk/drag-drop';
import { ToastrService, ToastContainerDirective } from 'ngx-toastr';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoleService } from '../../role.service';

@Component({
  selector: 'app-priority',
  templateUrl: './priority.component.html',
  styleUrls: ['./priority.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, DragDropModule]
})
export class PriorityComponent implements OnInit {
  @Input()
  roleId: string;
  role: any = {};

  constructor(
    public modal: NgbActiveModal,
    private roleService: RoleService,
    private toastService: ToastrService
  ) {}
  ngOnInit(): void {
    this.roleService
      .getParentRole(this.roleId)
      .then((response) => {
        this.role = response;
        this.role.subRoles = this.role.subRoles.filter((item) => {
          return item.status === 'Active';
        });
      })
      .catch((error) => {
        this.modal.close();
      });
  }
  save(): void {
    this.roleService
      .saveSubRolePriority(this.role)
      .then((response) => {
        this.toastService.success(
          'Success',
          'SubRole Priority Updated Successfully!',
          {
            closeButton: true,
            timeOut: 5000,
            positionClass: 'ngx-toastr'
          }
        );
      })
      .catch((err) => {
        this.toastService.error('Error', 'There seems to be an error.', {
          closeButton: true,
          timeOut: 5000,
          positionClass: 'ngx-toastr'
        });
      });
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousIndex !== event.currentIndex) {
      const priority = this.role.subRoles[event.currentIndex].priority;
      this.role.subRoles[event.currentIndex].priority =
        this.role.subRoles[event.previousIndex].priority;
      this.role.subRoles[event.previousIndex].priority = priority;
      moveItemInArray(
        this.role.subRoles,
        event.previousIndex,
        event.currentIndex
      );
      this.save();
    }
  }

 
}
