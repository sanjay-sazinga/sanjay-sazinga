import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2';
import { PriorityComponent } from './priority/priority.component';
import { ToastrService, ToastContainerDirective } from 'ngx-toastr';
import { PageFilterInfoComponent } from './page-filter-info/page-filter-info.component';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardComponent } from 'src/app/shared/components/card/card.component';
import { DataTablesModule } from 'angular-datatables';
import { RoleService } from '../role.service';
import { PageComponent } from '../../page/page.component';

@Component({
  selector: 'app-sub-role',
  templateUrl: './sub-role.component.html',
  styleUrls: ['./sub-role.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CardComponent,
    DataTablesModule,
    PriorityComponent,
    PageComponent,
  ],
})
export class SubRoleComponent implements OnInit {
  id = '';
  active = true;
  subRole: any = {};
  showSubNameRequiredError: boolean;
  subRoleNameError: string;
  isSubRoleExists: boolean;
  pages: any[] = [];
  dataFilters: any;
  @ViewChild(ToastContainerDirective, { static: true })
  toastContainer: ToastContainerDirective;

  constructor(
    private ngbModalService: NgbModal,
    private roleService: RoleService,
    private toastService: ToastrService,
    private route: ActivatedRoute
  ) {}

  resetVariables() {
    this.isSubRoleExists = false;
    this.showSubNameRequiredError = false;
  }

  save(): void {
    const checkNameRoleObj = {
      _id: this.subRole._id,
      name: this.subRole.name,
      parentRoleId: this.subRole.parentRole._id,
    };
    this.roleService
      .checkSubRoleNameExist(checkNameRoleObj)
      .then((response) => {
        if (response.found) {
          this.isSubRoleExists = true;
        } else {
          this.roleService
            .saveSubRole(this.subRole)
            .then((response) => {
              this.resetVariables();
              this.toastService.success(
                'Success',
                'SubRole"' + this.subRole.name + '" Updated Successfully!',
                {
                  closeButton: true,
                  timeOut: 5000,
                  positionClass: 'ngx-toastr',
                }
              );
            })
            .catch((err) => {
              this.toastService.error(
                'Error',
                'Error while updating "' + this.subRole.name + '".',
                {
                  closeButton: true,
                  timeOut: 5000,
                  positionClass: 'ngx-toastr',
                }
              );
            });
        }
      })
      .catch((err) => {
        console.error(err);
      });
  }

  setPriority(): void {
    const modalRef: NgbModalRef = this.ngbModalService.open(PriorityComponent, {
      size: 'lg',
      centered: true,
    });
    modalRef.componentInstance.roleId = this.subRole.parentRole._id;
    this.active = false;
    modalRef.result
      .then(() => {
        this.init();
      })
      .catch(() => {
        this.init();
      });
  }

  viewPageFilterInfo(page: any): void {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      PageFilterInfoComponent,
      {
        centered: true,
      }
    );
    modalRef.componentInstance.page = page;
  }

  addPageFilter(): void {
    const modalRef: NgbModalRef = this.ngbModalService.open(PageComponent, {
      size: 'lg',
      centered: true,
    });
    modalRef.componentInstance.roleId = this.subRole._id;
    modalRef.componentInstance.parentRoleId = this.subRole.parentRole._id;
    modalRef.result.then(() => {
      this.toastService.success('Success', 'Page Filter Added Successfully!', {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'ngx-toastr',
      });
      this.init();
    });
  }

  editPageFilter(page): void {
    const modalRef: NgbModalRef = this.ngbModalService.open(PageComponent, {
      size: 'lg',
      centered: true,
    });
    modalRef.componentInstance.roleId = this.subRole._id;
    modalRef.componentInstance.parentRoleId = this.subRole.parentRole._id;
    modalRef.componentInstance.page = page;
    modalRef.result.then(() => {
      this.toastService.success(
        'Success',
        'Page Filter "' + page.name + '" Updated Successfully!',
        {
          closeButton: true,
          timeOut: 5000,
          positionClass: 'ngx-toastr',
        }
      );
      this.init();
    });
  }

  removeSavedPageFilter(page: any, index: number): void {
    Swal.fire({
      title: 'Delete Page Filter !',
      text:
        'Are you sure you want to delete ' + page.name + ' from the system ?',
      icon: 'warning',
      showCloseButton: true,
      showCancelButton: true,
    }).then((willDelete) => {
      if (!willDelete.dismiss) {
        this.subRole.pageFilters.splice(index, 1);
        this.roleService.saveSubRole(this.subRole).then((response) => {
          this.init();
        });
      }
    });
  }

  init(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.roleService.getSubRole(this.id).then((resp) => {
      this.subRole = resp;
      this.pages = this.subRole.pageFilters;
      this.dataFilters = this.subRole.pageFilters;
    });
  }

  ngOnInit(): void {
    this.toastService.overlayContainer = this.toastContainer;
    this.init();
  }
}
