/**
 * Node with nested structure.
 * Each node has a name and an optional list of children.
 */
export interface Node {
  name: string;
  children?: Node[];
}

/** Flat node with expandable and level information */
export interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}
