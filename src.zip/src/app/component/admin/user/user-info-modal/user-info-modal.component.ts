import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Node } from '../../tree-view/treeViewNode';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/material.module';
import { TreeViewComponent } from '../../tree-view/tree-view.component';

@Component({
  selector: 'app-user-info-modal',
  templateUrl: './user-info-modal.component.html',
  styleUrls: ['./user-info-modal.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    TreeViewComponent
  ]
})
export class UserInfoModalComponent implements OnInit {
  @Input()
  user: any;
  items: Node[] = [];

  constructor(public modal: NgbActiveModal) {}

  ngOnInit(): void {
    this.user.pageFilters.forEach((page) => {
      const children = [];
      page.allowedComponent.forEach((comp) => {
        children.push({
          name: comp
        });
      });
      this.items.push({
        name: page.name,
        children: children
      });
    });
  }
}
