import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ClientService } from 'src/app/services/client.service';
import { DocumentService } from 'src/app/services/document.service';
import { RoleService } from 'src/app/services/role.service';
import { UserService } from 'src/app/services/user.service';
import { NgSelectModule } from '@ng-select/ng-select';

@Component({
  selector: 'app-user-modal',
  templateUrl: './user-modal.component.html',
  styleUrls: ['./user-modal.component.scss'],
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule, NgSelectModule]
})
export class UserModalComponent implements OnInit {
  @Input()
  public id: any;
  public action: string;
  public user: any = {};
  public clients: any[] = [];
  public showClients: boolean;
  public userExists: boolean;
  public system: any = {};
  public roleMap: any = {};
  public subRoleMap: any = {};
  public selectedRole = '';
  public roleOptions: Array<any> = [];
  public clientMap: any = {};
  public selectedClients: string[] = [];
  public clientOptions: Array<any> = [];
  public showEmailRequiredError = false;
  public emailError = '';
  public saveDisabled: boolean;
  public isUserExists: boolean;
  public showNameRequiredError: boolean;
  public showRoleRequiredError: boolean;
  public nameError = '';
  public roleError = '';

  constructor(
    public modal: NgbActiveModal,
    private clientService: ClientService,
    private userService: UserService,
    private roleService: RoleService,
    private documentService: DocumentService
  ) {}

  getSubRoles() {
    return this.roleMap[this.selectedRole]
      ? Object.keys(this.roleMap[this.selectedRole].subRoleStatus)
      : [];
  }

  toggleSubRoleStatus(subRole) {
    this.roleMap[this.selectedRole].subRoleStatus[subRole] =
      !this.roleMap[this.selectedRole].subRoleStatus[subRole];
  }

  roleChanged(): void {
    this.showClients =
      this.selectedRole['value'] !== 'Admin' && this.selectedRole !== '';
    this.user.roles = [this.roleMap[this.selectedRole['label']]];
    if (this.user.roles && this.user.roles.length) {
      this.user.roles.forEach((role, index) => {
        role.priority =
          this.user.roles[0].parentRole.type === 'Admin' ? index : index + 1;
      });
    }
    if (this.selectedRole === 'Admin') {
      this.selectedClients = [];
      this.user.clients = [];
    }
  }

  clientAdded(): void {
    const clients = [];
    this.selectedClients.forEach((client) => {
      clients.push(this.clientMap[client['label']]);
    });
    this.user.clients = clients;
  }

  activateUser(): Promise<any> {
    // TODO: Ask for Sweet-alert permission to activate user
    return this.userService.activateUser(this.user.email);
  }

  saveUserDetails() {
    if (this.selectedRole['value'] == 'Admin') {
      this.user.type = 'Admin';
    }
    this.userService
      .save(this.user)
      .then((resp) => {
        this.modal.close('Success');
      })
      .catch((err) => {
        this.modal.dismiss('Failure');
      });
  }

  save(): void {
    if (this.user.email == undefined) {
      this.showEmailRequiredError = true;
      this.emailError = 'Enter E-Mail ID';
    }
    if (this.user.name == undefined) {
      this.showNameRequiredError = true;
      this.nameError = 'Enter Name';
    }
    if (this.user.roles == undefined) {
      this.showRoleRequiredError = true;
      this.roleError = 'Enter Role';
    }

    if (
      this.user.roles != undefined &&
      this.user.name != undefined &&
      this.user.email != undefined
    ) {
      this.showEmailRequiredError = false;
      this.showNameRequiredError = false;
      this.showRoleRequiredError = false;
      this.userService.checkEmailExist(this.user).then((response) => {
        if (response.exist) {
          if (response.status === 'Inactive') {
            this.activateUser().then(() => {
              this.saveUserDetails();
            });
          } else {
            this.isUserExists = true;
          }
        } else {
          this.saveUserDetails();
        }
      });
    }
  }

  async fetchRoles(): Promise<void> {
    const response: any = await this.roleService.getAll();
    this.system.roles = response.roles;
    response.roles.forEach((role, index) => {
      this.roleOptions.push({
        value: role.name,
        label: role.name
      });
      const subRoleStatus = {};
      role.subRoles.forEach((sub) => {
        if (sub.status === 'Active') {
          subRoleStatus[sub._id] = true;
          this.subRoleMap[sub._id] = sub;
        }
      });
      this.roleMap[role.name] = {
        tempId: index + 1,
        parentRole: role,
        subRoleStatus: subRoleStatus
      };
    });
  }

  async fetchClients(): Promise<void> {
    this.system.clients = await this.documentService.getAllClients();
    this.system.clients.forEach((client) => {
      this.clientMap[client.name] = client;
      this.clientOptions.push({
        label: client.name,
        value: client.name
      });
    });
  }

  init(): void {
    this.clientService.fetchAllClients(null).then((clients) => {
      this.clients = clients;
    });
    if (this.id) {
      this.action = 'Edit';
      this.userExists = true;
      this.userService
        .get(this.id)
        .then((user) => {
          this.user = user;
          this.user.roles.forEach((role) => {
            role.tempId = role._id;
          });
          return this.fetchRoles();
        })
        .then(() => {
          return this.fetchClients();
        })
        .then(() => {
          if (this.user.roles.length) {
            this.selectedRole = this.user.roles[0].parentRole.name;
            this.showClients =
              this.selectedRole['value'] !== 'Admin' &&
              this.selectedRole !== '';
          }
          if (this.user.clients.length) {
            this.user.clients.forEach((client) => {
              this.selectedClients.push(client.name);
            });
          }
        });
    } else {
      this.action = 'Add';
      Promise.all([this.fetchRoles(), this.fetchClients()]);
    }
  }

  ngOnInit(): void {
    this.init();
  }
}
