import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { UserModalComponent } from './user-modal/user-modal.component';
import Swal from 'sweetalert2';
import { UserInfoModalComponent } from './user-info-modal/user-info-modal.component';
import { ToastrService, ToastContainerDirective } from 'ngx-toastr';
import { CardComponent } from 'src/app/shared/components/card/card.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { UserService } from 'src/app/services/user.service';
import { ChangePasswordComponent } from '../../authentication/change-password/change-password.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CardComponent,
    DataTablesModule,
    UserModalComponent,
    UserInfoModalComponent
  ]
})
export class UserComponent implements OnInit {
  users: any[] = [];
  @ViewChild(ToastContainerDirective, { static: true })
  toastContainer: ToastContainerDirective;

  constructor(
    public userService: UserService,
    private ngbModalService: NgbModal,
    private toastService: ToastrService
  ) {}

  ngOnInit(): void {
    this.toastService.overlayContainer = this.toastContainer;
    this.fetchUsers();
  }
  refreshPage(): void {
    this.users = [];
    this.fetchUsers();
  }

  addUser() {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      UserModalComponent,
      {
        size: 'lg',
        centered: true
      }
    );
    modalRef.result
      .then((resp) => {
        this.refreshPage();
      })
      .catch(() => {
        this.refreshPage();
      });
  }

  editUser(user: any) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      UserModalComponent,
      {
        size: 'lg',
        centered: true
      }
    );
    modalRef.componentInstance.id = user._id;
    modalRef.result
      .then((resp) => {
        this.refreshPage();
      })
      .catch(() => {
        this.refreshPage();
      });
  }

  deleteUser(user: any) {
    Swal.fire({
      title: 'Delete User !',
      text:
        'Are you sure you want to delete ' + user.name + ' from the system ?',
      icon: 'warning',
      showCloseButton: true,
      showCancelButton: true
    }).then((willDelete) => {
      if (!willDelete.dismiss) {
        this.userService
          .deleteUser(user._id)
          .then((response) => {
            this.refreshPage();
          })
          .catch(() => {
            this.refreshPage();
          });
        // Swal.fire('', 'Poof! Your imaginary file has been deleted!', 'success');
      }
    });
  }

  transformPageFilterForView(user) {
    user.pageFilters = [];
    user.roles.sort((a, b) => {
      return a.priority - b.priority;
    });
    if (user.roles.length && user.roles[0].parentRole.type === 'Admin') {
      user.pageFilters.push({
        name: 'All Pages are visible to Admin',
        allowedComponent: []
      });
    } else {
      user.roles.some((roleObj) => {
        const activeSubRoles = roleObj.parentRole.subRoles;
        activeSubRoles.sort((a, b) => {
          return a.priority - b.priority;
        });

        return activeSubRoles.some((role) => {
          role.pageFilters = role.pageFilters || [];
          // just loop through list and check if that page has already come then ignore the components

          return role.pageFilters.some((filter) => {
            let page1 = null;
            user.pageFilters.forEach((page) => {
              if (page.name === filter.name) {
                page.allowedComponent = Array.from(
                  new Set([
                    ...page.allowedComponent,
                    ...filter.allowedComponent
                  ])
                );
                page1 = page;
              }
            });
            if (!page1) {
              page1 = filter;
              user.pageFilters.push(page1);
            }
          });
        });
      });
    }
  }

  fetchUsers() {
    this.userService.getAll().then((response) => {
      this.users = response.users;
      this.users.forEach((user) => {
        this.transformPageFilterForView(user);
      });
    });
  }

  viewUserInfo(user: any) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      UserInfoModalComponent,
      {
        size: 'lg',
        centered: true
      }
    );
    modalRef.componentInstance.user = user;
  }

  changePassword(user: any) {
    const modalRef: NgbModalRef = this.ngbModalService.open(
      ChangePasswordComponent,
      {
        centered: true
      }
    );
    modalRef.componentInstance.user = user;
    modalRef.result.then((resp) => {
      user.newPassword = resp.password;
      user.confirmNewPassword = resp.confirmPassword;
      this.userService
        .save(user)
        .then(() => {
          this.toastService.success(
            'Success',
            'User "' + user.name + '" Updated Successfully!',
            {
              closeButton: true,
              timeOut: 5000,
              positionClass: 'ngx-toastr'
            }
          );
        })
        .catch(() => {
          this.toastService.error(
            'Error',
            'Error while updating "' + user.name + '".',
            {
              closeButton: true,
              timeOut: 5000,
              positionClass: 'ngx-toastr'
            }
          );
        });
    });
  }
  restoreUser(user) {
    user.status = 'Active';
    this.userService.save(user).then((resp) => {
      window.location.reload();
    });
  }

  activateUser(user): Promise<any> {
    // TODO: Ask for Sweet-alert permission to activate user
    return this.userService.activateUser(user.email);
  }
}
