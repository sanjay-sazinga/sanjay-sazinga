import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Subject, Subscription } from 'rxjs';
import { DocumentService } from 'src/app/services/document.service';

const loremipsum = `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In massa tempor nec feugiat nisl pretium. Morbi leo urna molestie at. Cras pulvinar mattis nunc sed blandit libero volutpat. Facilisis magna etiam tempor orci eu. Feugiat sed lectus vestibulum mattis ullamcorper velit. Pellentesque elit eget gravida cum sociis natoque penatibus et. Facilisis sed odio morbi quis commodo odio. Orci phasellus egestas tellus rutrum tellus pellentesque. Id consectetur purus ut faucibus pulvinar elementum integer enim. Quis risus sed vulputate odio ut enim blandit volutpat maecenas. Nec tincidunt praesent semper feugiat nibh sed pulvinar. Convallis a cras semper auctor neque vitae tempus. Pretium vulputate sapien nec sagittis aliquam malesuada bibendum. Lectus vestibulum mattis ullamcorper velit. Sed risus ultricies tristique nulla aliquet enim tortor at. Odio aenean sed adipiscing diam donec adipiscing tristique. Tellus pellentesque eu tincidunt tortor.

Dictum sit amet justo donec. Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis. Tellus orci ac auctor augue mauris augue neque. Velit scelerisque in dictum non consectetur a erat. Morbi tempus iaculis urna id volutpat lacus laoreet non. Et netus et malesuada fames. Id semper risus in hendrerit gravida rutrum. Congue eu consequat ac felis donec et. Consequat interdum varius sit amet. Rhoncus dolor purus non enim praesent elementum facilisis leo. Pulvinar neque laoreet suspendisse interdum consectetur libero id faucibus nisl. Arcu non sodales neque sodales ut etiam sit amet.

Eget gravida cum sociis natoque penatibus et. Cursus mattis molestie a iaculis. At varius vel pharetra vel turpis nunc eget. Ultrices neque ornare aenean euismod. Hac habitasse platea dictumst quisque sagittis purus sit amet volutpat. Nisl nunc mi ipsum faucibus vitae aliquet nec ullamcorper. Libero id faucibus nisl tincidunt. Aenean sed adipiscing diam donec adipiscing tristique risus nec feugiat. Pellentesque nec nam aliquam sem et tortor consequat id. Et malesuada fames ac turpis egestas maecenas pharetra convallis posuere. Enim sed faucibus turpis in eu mi bibendum neque egestas. Facilisi nullam vehicula ipsum a arcu cursus vitae congue mauris. Gravida in fermentum et sollicitudin ac orci.`;

@Component({
  selector: 'app-ag-grid',
  templateUrl: './ag-grid.component.html',
  styleUrls: ['./ag-grid.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,ReactiveFormsModule, 
  ]
})
export class AgGridComponent implements OnInit {
  @Input() editable: Subject<boolean>;

  private gridApi;
  isEditable = null;
  // private gridOptions : GridOptions;
  editableSubscription: Subscription;
  table_data;
  allSecondaryTables = {};
  allPinnedRows = {};
  secondaryTableRows = [];
  secondaryTableCols = [];
  currentPrimaryTableRowIndex = null;
  currentPrimaryTableColId = null;
  showPrimaryTable = true;
  showSecondaryTable = false;
  secondaryTableOpened = false;
  showBlockContent = false;
  textKey = null;
  textValue = null;
  enableEdit = false;
  currentRowNode = null;
  previousText = null;
  addColumn = false;
  addRow = false;
  secondaryTableKey = null;
  dockeyRow = {};
  activeTab = 'extraction-results';
  columnOptions = ['vendor_name', 'vendor_address', 'invoice_no', 'amount'];
  columnDefs: any = [
    {
      field: 'key',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      flex: 1,
      minWidth: 150,
      rowDrag: true,
      pinned: 'left',
      cellStyle: {
        // 'font-weight': 'bold',
        color: '#ff7300',
        // 'background-color': '#8f8e93',
        // opacity: 0.5,
      },
    },
    {
      field: 'doc key',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      flex: 2,
      minWidth: 200,
    },
    {
      field: 'value',
      editable: (params) => {
        if (this.isEditable) {
          if (params.data.type === 'table') return false;
          return true;
        }
        return false;
      },
      resizable: true,
      minWidth: 150,
      flex: 2,
    },
    {
      field: 'type',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      minWidth: 150,
      flex: 1,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: ['entity', 'block', 'image', 'table'],
      },
    },
    {
      field: 'raw value',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      minWidth: 150,
      flex: 1,
    },
  ];
  rowData = [];
  gridOptions = {
    flex: 1,
    minHeight: '100%',
    onCellClicked: (e) => this.handleCellClicked(e),
  };

  secondaryGridOptions = {
    flex: 1,
    minHeight: '100%',
    onCellClicked: (e) => this.handleCellClicked(e),
    getRowStyle: (params) => {
      if (params.node.rowPinned) {
        return { background: '#f8f8f8', fontWeight: 'bold' };
      }
    },
  };

  onGridReady(params: GridReadyEvent) {
    console.log('ongridready= ', params);
    this.gridApi = params.api;
    var primaryTableEl: any = document.querySelector('#primaryTable');
    // Listen for click events on body
    document.body.addEventListener('click', function (event) {
      if (primaryTableEl.contains(event.target)) {
        console.log('clicked inside');
      } else {
        console.log('clicked outside');
        params.api.stopEditing();
      }
    });
  }
  onGridReady2(params: GridReadyEvent) {
    console.log('ongridready2= ', params);
    this.gridApi = params.api;
    this.gridApi.setPinnedTopRowData([this.dockeyRow]);
    var secondaryTableEl: any = document.querySelector('#secondaryTable');
    document.body.addEventListener('click', function (event) {
      if (secondaryTableEl.contains(event.target)) {
        console.log('clicked inside');
      } else {
        console.log('clicked outside');
        params.api.stopEditing();
      }
    });
  }

  addRowClicked() {
    this.addRow = true;
    const newRowNode = {};
    this.columnDefs.forEach((columnData) => {
      newRowNode[columnData['field']] = '';
    });

    this.gridApi.applyTransaction({ add: [newRowNode] });
    const lastRowIndex = this.gridApi.getLastDisplayedRow();
    // this.gridApi.getDisplayedRowAtIndex(lastRowIndex).setSelected(true);
    this.gridApi.ensureIndexVisible(lastRowIndex);
    // setInterval(() => {
    //   if (this.gridApi) {
    //     this.gridApi.getDisplayedRowAtIndex(lastRowIndex).setSelected(false);
    //   }
    // }, 100);
  }

  onDataChangeHandler() {}

  addColumnClicked() {
    console.log('add column clicked');

    this.addColumn = true;
  }

  onCellValueChanged(params) {
    if (params.oldValue !== params.newValue) {
      console.log('newValue= ', params.newValue);

      var column = params.column.colDef.field;
      params.column.colDef.cellStyle = { color: 'blue' };
      params.api.refreshCells({
        force: true,
        columns: [column],
        rowNodes: [params.node],
      });
    }
  }

  enableTextEdit() {
    this.enableEdit = !this.enableEdit;
    this.previousText = this.textValue;
  }
  cancelEdit() {
    this.enableEdit = false;
    this.textValue = this.previousText;
  }
  saveTextEdit() {
    console.log('data to save after editing= ', this.textValue);
    this.currentRowNode.data.value = this.textValue;
    console.log('current node in savetext edit= ', this.currentRowNode);

    this.gridApi.applyTransaction({ update: [this.currentRowNode.data] });
    this.showBlockContent = false;
    this.showPrimaryTable = true;
    this.enableEdit = false;
  }
  openPrimaryTable() {
    this.activeTab = 'extraction-results';
    this.showSecondaryTable = false;
    this.showPrimaryTable = true;
    this.gridApi.setFocusedCell(
      this.currentPrimaryTableRowIndex,
      this.currentPrimaryTableColId
    );
  }

  openSecondaryTable() {
    // if (this.showPrimaryTable) {
    //   this.showPrimaryTable = false;
    // }
    // this.showSecondaryTable = !this.showSecondaryTable;
    // if (this.showSecondaryTable) {
    //   this.activeTab = 'table';
    // }
    this.activeTab = 'table';
    this.showSecondaryTable = true;
    this.showPrimaryTable = false;
  }

  closeTextWindow() {
    this.showBlockContent = false;
    this.textKey = '';
    this.textValue = '';
    this.showPrimaryTable = true;
    this.enableEdit = false;
  }

  cancelAddColumn(form) {
    this.addColumn = false;
    form.reset();
  }

  addColumnToTable(form) {
    console.log('column form= ', form.value);
    const columnObj = {
      field: form.value.ssotkey,
      editable: true,
      resizable: true,
      flex: 1,
      minWidth: 150,
    };

    if (this.showPrimaryTable) {
      this.columnDefs = [...this.columnDefs, columnObj];
    } else if (this.showSecondaryTable) {
      this.secondaryTableCols = [...this.secondaryTableCols, columnObj];
      const currentPinnedRow = this.allPinnedRows[this.secondaryTableKey];
      currentPinnedRow[form.value.ssotkey] = form.value.columnName;
      this.allPinnedRows[this.secondaryTableKey] = currentPinnedRow;
      // this.allPinnedRows={...this.allPinnedRows, [this.secondaryTableKey]: {

      // } };
    }

    form.reset();
    this.addColumn = false;
  }

  handleCellClicked(e) {
    console.log('cell clicked=', e);
    if (e.column.colId === 'key') return;
    if (e.column.colId === 'value' && e.data.type === 'block') {
      this.showPrimaryTable = false;
      this.showBlockContent = true;
      this.textKey = e.data.key;
      this.textValue = e.data.value;
      // this.textValue = loremipsum;
      const rowIndex = e.rowIndex;
      this.currentRowNode = this.gridApi.getRowNode(rowIndex);
      // console.log(this.currentRowNode.setDataValue('value', this.textValue));
    }

    if (
      e.column.colId === 'value' &&
      (e.data.type === 'Table' || e.data.type === 'table')
    ) {
      console.log('here');
      this.activeTab = 'table';
      this.showPrimaryTable = false;
      this.currentPrimaryTableRowIndex = e.rowIndex;
      this.currentPrimaryTableColId = e.column.colId;
      this.secondaryTableCols = this.allSecondaryTables[e.data.key]['cols'];
      console.log('secondaryTableCols=', this.secondaryTableCols);
      // console.log('dockey row to pin= ', this.dockeyRow);
      this.secondaryTableKey = e.data.key;
      this.dockeyRow = this.allPinnedRows[e.data.key];
      this.secondaryTableRows =
        this.allSecondaryTables[e.data.key]['rows'].slice(1);
      this.showSecondaryTable = true;
      this.secondaryTableOpened = true;
    }
  }
  constructor(private documentService: DocumentService) {
    console.log('editable inside constructor= ', this.editable);
  }

  ngOnInit(): void {
    // get the dummy data from a file.
    // needs to be replaced by actual API call
    console.log('ng on init called');

    const editableSubscription = this.editable.subscribe((value) => {
      console.log('HERE');
      this.isEditable = value;
      console.log('value of isEditable= ', this.isEditable);
    });

    this.table_data = this.documentService.getDummyData();
    console.log('dummy_data=', this.table_data);

    this.table_data.forEach((entry) => {
      const key = entry['SSOTKey'];
      let value = entry['Value'];
      const type = entry['ValueType'];
      const rawValue = entry['RawValue'];
      const docKey = entry['DocKey'];
      // if type is a table then make a new ag-grid table and open in a new tab
      if (type === 'table') {
        const tableData = entry['Value'];
        const columnNames = new Set();
        const tableColDefs = [];
        const tableRows = [];
        const firstRow = {};
        tableData.forEach((row) => {
          const tableRowData = {};
          row.forEach((colData) => {
            if (!columnNames.has(colData['ColumnSSOT'])) {
              columnNames.add(colData['ColumnSSOT']);
              firstRow[colData['ColumnSSOT']] = colData['DocKey'];
              // this.dockeyRow[colData['ColumnSSOT']] = colData['DocKey'];
              tableColDefs.push({
                field: colData['ColumnSSOT'],
                resizable: true,
                flex: 1,
                editable: (params) => {
                  return this.isEditable;
                },
              });
            }
            tableRowData[colData['ColumnSSOT']] = colData['Value'];
          });
          console.log('dockey row= ', this.dockeyRow);

          tableRows.push(tableRowData);
        });

        console.log('tableColDefs= ', tableColDefs);
        console.log('tableRows= ', tableRows);
        value = 'Table';
        this.allPinnedRows[key] = firstRow;
        this.allSecondaryTables[key] = {
          rows: [firstRow, ...tableRows],
          cols: tableColDefs,
        };
      }

      this.rowData.push({
        key: key,
        value: value,
        type: type,
        'raw value': rawValue,
        'doc key': docKey,
      });
      console.log('allSecondaryTables= ', this.allSecondaryTables);
    });
  }
}
