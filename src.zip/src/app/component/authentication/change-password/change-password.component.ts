import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {UtilityService} from "../../../services/utility.service";
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
  standalone:true,
  imports:[CommonModule,RouterModule,AngularMaterialModule,FormsModule,ReactiveFormsModule],
})
export class ChangePasswordComponent implements OnInit {
  resetForm: FormGroup;

  constructor(private formBuilder: FormBuilder, public modal: NgbActiveModal) {
  }

  get formControls() {
    return this.resetForm.controls;
  }

  resetPassword() {
    if (this.resetForm.invalid) {
      return;
    }
    this.modal.close(this.resetForm.value);
  }

  ngOnInit(): void {
    this.resetForm = this.formBuilder.group({
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(14),
        // check whether the entered password has a number
        UtilityService.patternValidator(/\d/, {hasNumber: true}),
        // check whether the entered password has upper case letter
        UtilityService.patternValidator(/[A-Z]/, {hasCapitalCase: true}),
        // check whether the entered password has a lower-case letter
        UtilityService.patternValidator(/[a-z]/, {hasSmallCase: true})
      ]],
      confirmPassword: ['', [Validators.required]]
    }, {
      // check whether our password and confirm password match
      validator: UtilityService.passwordMatchValidator
    });
  }

}
