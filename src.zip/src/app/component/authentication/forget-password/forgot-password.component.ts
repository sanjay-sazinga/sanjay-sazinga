import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators} from "@angular/forms";
import {Router, RouterModule} from "@angular/router";
import {AuthService} from "../../../services/auth.service";
import {UtilityService} from "../../../services/utility.service";
import { GradientConfig } from 'src/app/app-config';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  standalone:true,
  imports:[CommonModule,RouterModule,AngularMaterialModule,FormsModule,ReactiveFormsModule],
})
export class ForgotPasswordComponent implements OnInit {
  authForm: FormGroup;
  isSubmitted = false;
  userMail: string;
  isEmailValid: boolean = false;
  cancelTimeout: boolean = false;
  isSent = false;
  error: any;
  projectName: string;
  redirect: any;
  //isEmailValid: boolean = false;

  isSubmitDisabled: boolean = true;
  constructor(private router: Router, private formBuilder: FormBuilder, private authService: AuthService) {
    this.projectName = GradientConfig.config.projectName;
  }

  get formControls() {
    return this.authForm.controls;
  }

  redirectToLogin() {
    this.redirect = setTimeout(() => {
      this.router.navigate(['login']);
    }, 5000);
  }
  changeemail()
  {
    clearTimeout(this.redirect);
    this.isSent=false;
  }
  resendemail()
  {
    clearTimeout(this.redirect);
  //  console.log(this.redirect);
    this.submit();


  }
  submit() {
    this.isSubmitted = true;

    const re =
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    if (re.test(this.userMail)) {
      this.isEmailValid = true;
    } else {
      this.isEmailValid = false;
    }

    this.error = { message: null };
    if (this.authForm.invalid) {
      return;
    }
    this.authService.sendResetMail(this.authForm.value).then((response) => {
      this.isSubmitted = false;
      this.isSent = true;
      this.redirectToLogin();
    }).catch((err) => {
      console.error(err);
      this.isSubmitted = false;
      // this.isSent = false;
     this.error.message = err.error;

    //  this.redirectToLogin();
    });
  }

  checkemailvalidity()
  {

    this.isSubmitted=true;
  }


  ngOnInit(): void {
    this.authForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(UtilityService.EmailPattern)]],
    });

    this.authForm.valueChanges.subscribe(value => {
      if(value.email)
      {

        this.isSubmitDisabled=false;
        this.userMail= value.email;
      //  console.log(this.isSubmitDisabled)

        const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        this.isEmailValid = re.test(this.userMail) ? this.isEmailValid = true : this.isEmailValid = false

        if (this.isEmailValid == false) {
          this.isSubmitDisabled = false;          

          // if (re.test(this.userMail)) {
          //   this.isEmailValid = true;
          // }
        }
        // if(re.test(value.email))
        // {
        // this.isSubmitDisabled=false;
        // }
        // else
        // {
        //   this.isSubmitDisabled=true;


      else
      {
        this.isSubmitDisabled=true;
      }


     // console.log(this.isLoginDisabled);
    }

    });
  }


}
