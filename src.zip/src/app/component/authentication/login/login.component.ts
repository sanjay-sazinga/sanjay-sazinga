import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { GradientConfig } from 'src/app/app-config';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from 'src/app/material.module';
import { UserService } from 'src/app/services/user.service';
import { AuthService } from 'src/app/services/auth.service';
import { UtilityService } from 'src/app/services/utility.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  standalone:true,
  imports:[CommonModule,RouterModule,AngularMaterialModule,FormsModule,ReactiveFormsModule],
})
export class LoginComponent implements OnInit {
  authForm: FormGroup;
  isSubmitted: boolean = false;
  error: any;
  otpSent: boolean = false;
  passwordNeedChange: boolean = false;
  enableOTP: boolean = false;
  timerOTP: boolean = false
  titleVisible: boolean = true;
  projectName: string;
  rememberMe: boolean;
  isEmailValid: boolean = false;
  isLoginDisabled: boolean= true;
  public gradientConfig: any;


  constructor(private router: Router, private formBuilder: FormBuilder,
    private userService: UserService, private authService: AuthService,
    private localStorageService:LocalStorageService) {
    this.gradientConfig = GradientConfig.config;
    this.projectName = this.gradientConfig.projectName;
    this.authForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(UtilityService.EmailPattern)]],
      password: ['', Validators.required],
      twoFactorCode: ['',],
      //rememberMe: ['',Validators.required]

    });
  }

  ngOnInit(): void {

    this.rememberMe=false;
    this.userService.getTwoFactorConfig().then((response) => {
      this.enableOTP = response.twoFactorAuthentication;
    }).catch((err) => {
      this.error.message = "Internal Server Error";
    });

    this.AutoLogin();
    this.authForm.valueChanges.subscribe(value => {
     // console.log(value);
      if(value.email && value.password)
      {
        this.isLoginDisabled=false;
         const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

         if(re.test(value.email))
         {
         this.isEmailValid=true;
         }
         else
         {
           this.isEmailValid=false;

         }
      }

      else
      {
        this.isLoginDisabled=true;
      }

     // console.log(this.isLoginDisabled);

    });
  }

  get formControls() {
    return this.authForm.controls;
  }

  redirectUser(user): void {
    console.log("Rediricting to home")
    console.log(user)
    // Logged in, redirect to home

    // user.roles.sort((a, b) => {
    //   return a.priority - b.priority;
    // });

    if (user.roles && user.roles.length > 0 && user.roles[0].parentRole.type === 'Admin') {
      this.localStorageService.setItem('user', 'Admin');
    }
    else if (user.roles && user.roles.length === 1) {
      this.localStorageService.setItem('user', user.roles[0].parentRole.name);

    }
    // else if (user.roles && user.roles.length === 1 && user.roles[0].parentRole.name === 'Approver') {
    //   localStorage.setItem('user', user.roles[0].parentRole.name);

    // }
    //todo: fix the below statement by removing ts-ignore
    // @ts-ignore

    this.router.navigateByUrl('/home', { queryParams: { user: user } });
  }

  sendOtp(): void {
    this.userService.checkUserExistsByEmail({
      email: this.authForm.value.email,
      password: this.authForm.value.password
    }).then((user) => {
      this.authService.sendToken({ email: this.authForm.value.email }).then(() => {
        this.otpSent = true;
        this.titleVisible = false;
      })
    }).catch((err) => {
      this.error.message = err.message;
    });
  }

  resendOTP(): void {
    if(this.timerOTP == false) {
      this.userService.checkUserExistsByEmail({
        email: this.authForm.value.email,
        password: this.authForm.value.password
      }).then((user) => {
        this.authService.sendToken({ email: this.authForm.value.email }).then(() => {
          this.otpSent = true;
          this.timerOTP = true;
        })
      }).catch((err) => {
        this.error.message = err.message;
      });
   } else {
      this.error.resentErrorMsg = "OTP is already sent, Please wait 30 seconds to resend";

      setTimeout(() => {
        this.timerOTP = false;
      }, 30000);
   }
  }

  finalLogin(): void {
    this.authService.login(this.authForm.value).then((user) => {
      this.isSubmitted = false;
      //console.log(user)



      //console.log(this.rememberMe);


       // console.log(user)
        this.redirectUser(user);

    }).catch((err) => {
      this.error.message = err.message;
    });
  }
  AutoLogin(){
    const accessuser = this.localStorageService.getItem("email");
    const rememberMe = this.localStorageService.getItem('rememberMe');
   // console.log(accessuser);
    if (accessuser && rememberMe == 'yes') {
      this.router.navigate(['/home']);
    } else {
     // console.log("You need to login")
    }
   }

  login() {

   // console.log("working")
    this.isSubmitted=true;
    this.error = { message: null };
  //  console.log(this.formControls.email.errors.pattern)
    //this.isSubmitted = true;
    if (this.authForm.invalid) {
     // console.log("invalid hai")
      // console.log(this.isSubmitted)
      // console.log(this.authForm.invalid)

      return;
    }
    if (this.enableOTP && !this.otpSent) {
      this.sendOtp();
    } else {
      this.userService.getUserDetails({ email: this.authForm.value.email }).then((userDetails) => {
        var today = new Date();
        var threeMonthDate = new Date();
        threeMonthDate.setMonth(today.getMonth() - 3);
        if (new Date(userDetails.lastPasswordChanged) < threeMonthDate) {
          this.authService.generateToken(userDetails.email).then((resp) => {

            this.passwordNeedChange = true;
            this.error.message = "The Password is more than 3 months old. Navigating to Password Reset Page."
            setTimeout(() => {
              this.router.navigate(["password_reset/" + resp.token])
            }, 3000);
          })
        }
        else {
          if (!this.enableOTP) {
            this.finalLogin();
          }
          else if (userDetails.otp && this.authForm.value.twoFactorCode
            && this.authForm.value.twoFactorCode === userDetails.otp) {
            this.finalLogin();
          } else {
            this.error.message = "Invalid OTP";
          }
        }
      }).catch((err) => {
        this.error.message = "Invalid Username or Password.";
      });
    }

  }

  checkemailvalidity()
  {
    //console.log("rerere")
    this.isSubmitted=true;
  }

}
