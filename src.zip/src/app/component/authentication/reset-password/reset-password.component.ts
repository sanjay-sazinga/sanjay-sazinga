import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { UtilityService } from "../../../services/utility.service";
import { AuthService } from "../../../services/auth.service";
import { ActivatedRoute, Router, RouterModule } from "@angular/router";
import { GradientConfig } from 'src/app/app-config';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  standalone:true,
  imports:[CommonModule,RouterModule,AngularMaterialModule,FormsModule,ReactiveFormsModule],
})
export class ResetPasswordComponent implements OnInit {
  token: string;
  resetForm: FormGroup;
  isPasswordTokenValid = true;
  isPasswordChanged;
  projectName: string;
  error: string;


  passwordcheck1: boolean=false;
  passwordcheck2: boolean=false;
  passwordcheck3: boolean=false;
  passwordcheck4: boolean=false;

  isSubmitDisabled: boolean= true;
  isPasswordValid: boolean=false;
  public gradientConfig: any;

  constructor(private route: ActivatedRoute, private router: Router, private formBuilder: FormBuilder,
    private authService: AuthService) {
    this.gradientConfig = GradientConfig.config;
    this.projectName = this.gradientConfig.projectName;
  }


  get formControls() {
    return this.resetForm.controls;
  }


  redirectToLogin() {
    setTimeout(() => {
      this.router.navigate(['login']);
    }, 5000);
  }

  resetPassword() {

    if (this.resetForm.invalid) {
      return;
    }
    this.authService.resetPasswordByToken(this.resetForm.value.password, this.resetForm.value.confirmPassword,
      this.token).then((response) => {
        this.isPasswordChanged = true;
        this.redirectToLogin();
      }).catch((err) => {
        console.error(err);
        this.error = err.error
        // this.redirectToLogin();
      });
  }
  calculatestrength(password)
  {
    this.passwordcheck1=false;
    this.passwordcheck2=false;
    this.passwordcheck3=false;
    this.passwordcheck4=false;

    if(password.length>=8 && password.length<=14)
    {
      this.passwordcheck1=true;
    }
    if(/\d/.test(password))
    {
      this.passwordcheck3=true;

    }
    if(/[A-Z]/.test(password) && /[a-z]/.test(password))
    {
      this.passwordcheck2=true;

    }
    var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
    if(format.test(password))
    {
      this.passwordcheck4=true;
    }




  }

  ngOnInit(): void {

    this.resetForm = this.formBuilder.group({
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(14),
        // check whether the entered password has a number
        UtilityService.patternValidator(/\d/, { hasNumber: true }),
        // check whether the entered password has upper case letter
        //UtilityService.patternValidator(/[A-Z]/, { hasCapitalCase: true }),
        // check whether the entered password has a lower-case letter
        UtilityService.patternValidator(/[a-z]/, { hasSmallCase: true })
      ]],
      confirmPassword: ['', [Validators.required]]
    }, {
      // check whether our password and confirm password match
      validator: UtilityService.passwordMatchValidator
    });

    this.resetForm.valueChanges.subscribe(value => {


      if(value.password)
      {
        this.calculatestrength(value.password);
        var passwordregex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,14}$/;

        if( passwordregex.test(value.password))
        {
        this.isPasswordValid=true;
        }
        else
        {
          this.isPasswordValid=false;
        }

      }
      else
      {
        this.passwordcheck1=false;
      this.passwordcheck2=false;
      this.passwordcheck3=false;
      this.passwordcheck4=false;
      }
      if(value.password && value.confirmPassword)
      {
        var passwordregex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,14}$/;

        if( passwordregex.test(value.password))
        {
        this.isPasswordValid=true;
        if(value.password == value.confirmPassword )
        {
          this.isSubmitDisabled=false;

        }
        else
        {
          this.isSubmitDisabled=true;
        }

        }
        else
        {
         this.isPasswordValid=false;
         this.isSubmitDisabled=true;

        }
      }

      else
      {

        this.isSubmitDisabled=true;
      }

      console.log(this.passwordcheck1);
      console.log(this.passwordcheck2);
      console.log(this.passwordcheck3);
      console.log(this.passwordcheck4);


    });









    this.token = this.route.snapshot.paramMap.get('token');
    this.authService.checkResetPasswordToken(this.token).then((status) => {
      if (!status.valid) {
        this.isPasswordTokenValid = false;
        // this.redirectToLogin();
      }
    }).catch((err) => {
      console.error(err);
      this.isPasswordTokenValid = false;
      // this.redirectToLogin();
    });
  }

}

// changePasswordVisibility()
//   {

//     this.hidePassword=!this.hidePassword;
//     //console.log(this.hidePassword);
//   }
//   changeConfirmPasswordVisibility()
//   {
//     this.hideConfirmPassword=!this.hideConfirmPassword;


//   }
