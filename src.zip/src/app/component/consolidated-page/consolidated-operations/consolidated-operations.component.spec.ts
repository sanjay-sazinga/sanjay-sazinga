import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatedOperationsComponent } from './consolidated-operations.component';

describe('ConsolidatedOperationsComponent', () => {
  let component: ConsolidatedOperationsComponent;
  let fixture: ComponentFixture<ConsolidatedOperationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidatedOperationsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsolidatedOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
