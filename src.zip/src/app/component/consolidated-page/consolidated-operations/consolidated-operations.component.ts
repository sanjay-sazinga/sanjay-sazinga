import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ViewChild,
} from '@angular/core';
import { DocumentService } from 'src/app/services/document.service';
import { UserService } from 'src/app/services/user.service';
import { RoleService } from 'src/app/services/role.service';
import { Router } from '@angular/router';
// import Spreadsheet from 'x-data-spreadsheet';
import { Subject } from 'rxjs';
import Swal from 'sweetalert2';
import {
  Column,
  ColumnContextMenuConfig,
  RowContextMenuConfig,
} from '../../../shared/components/tabulator/interfaces/tabulator-config.interface';
import { ActionMenu } from '../../../shared/components/tabulator/interfaces/action-menu.interface';
import { TabulatorComponent } from '../../../shared/components/tabulator/tabulator.component';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { MatMenuModule } from '@angular/material/menu';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-consolidated-operations',
  templateUrl: './consolidated-operations.component.html',
  styleUrls: ['./consolidated-operations.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    TabulatorComponent,
    MatDialogModule,
    FormsModule,
    NgbDropdownModule,
    MatMenuModule,
    AngularMaterialModule,
  ],
})
export class ConsolidatedOperationsComponent implements OnInit {
  @Input() childDocumentId: string;

  @Output() highlightedBase = new EventEmitter<any>();
  @Output() RefreshEvent = new EventEmitter<boolean>();
  @Output() DataLoaded = new EventEmitter<boolean>();
  @Output() pageNum = new EventEmitter<number>();

  editableSubject = new Subject<boolean>();
  filtersSubject = new Subject<boolean>();

  digiDocName: string;
  userRole: string;

  modalInput: any;
  modalInputApprover: string;

  documentID: any;
  analystComments: string;
  adminComments: string;

  DigiDocList: any;
  insertedRowList = [];

  editableText = false;
  filterable = false;

  commentBtn = {
    analystComments: false,
    approverComments: false,
  };

  DEFAULT_OPTIONS = {
    mode: 'edit', // edit | read
    showToolbar: true,
    showGrid: true,
    showContextmenu: true,
    view: {
      height: () => document.documentElement.clientHeight,
      width: () => document.documentElement.clientWidth,
    },
    row: {
      len: 100,
      height: 25,
    },
    col: {
      len: 26,
      width: 100,
      indexWidth: 60,
      minWidth: 60,
    },
    style: {
      bgcolor: '#000',
      align: 'left',
      valign: 'middle',
      textwrap: false,
      strike: false,
      underline: false,
      color: '#0a0a0a',
      font: {
        name: 'Helvetica',
        size: 10,
        bold: false,
        italic: false,
      },
    },
  };

  dummyData: any = {
    _id: null,
    ParentDocumentID: '',
    ProcessedDocumentType: 'Digitized',
    LOCK: 'read',
    Version: 2,
    JSONData: [
      {
        modified_transactions: [],
        json_obj: [],
        formulae: {},
        coordinateList: [
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.55128', '0.155', '0.66923', '0.16699999999999998']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.75641', '0.168', '0.83333', '0.18100000000000002']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.75641', '0.168', '0.83333', '0.18100000000000002']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.75641', '0.168', '0.83333', '0.18100000000000002']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.49359000000000003', '0.142', '0.66923', '0.154']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.38718', '0.312', '0.52564', '0.325']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [
                [
                  '0.44615000000000005',
                  '0.48200000000000004',
                  '0.53333',
                  '0.495',
                ],
              ],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [
                [
                  '0.44615000000000005',
                  '0.5670000000000001',
                  '0.51667',
                  '0.58',
                ],
              ],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [
                [
                  '0.72821',
                  '0.755',
                  '0.8038500000000001',
                  '0.7659999999999999',
                ],
              ],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.47179000000000004', '0.501', '0.62436', '0.511']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
        ],
        corrected_cells: {},
        uiFormula: {},
        bracketList: {},
        recon_transactions: {},
        transactions: {},
        unprocessed_table: [],
        tab_name: '',
      },
    ],
    LastUpdatedTimestamp: new Date(),
    isDeleted: false,
    LogFilePath: [],
    Counted: false,
    statusParent: 'Original',
    // isSubmit: false,
    // isApproved: false,
    // isReject: false,
    currentStatus: '',
    AnalystComments: [],
    ApproverComments: [],
    isStatsDataAvailable: false,
    superParentId: '',
  };

  testSheetData = {
    name: 'Page1',
    freeze: 'A1',
    styles: [
      {
        // 0
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
      },
      {
        // 1
        font: {
          bold: true,
          size: 40,
        },
      },
      {
        // 2
        format: 'number',
        align: 'right',
      },
      {
        // 3
        format: 'percent',
      },
      {
        // 4
        format: 'percent',
        align: 'right',
      },
      {
        // 5
        align: 'right',
      },
      {
        // 6
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
      },
      {
        // 7
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
        format: 'number',
      },
      {
        // 8
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
        format: 'normal',
      },
      {
        // 9
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
        format: 'percent',
      },
      {
        // 10
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
      },
      {
        // 11
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        format: 'number',
      },
      {
        // 12
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        format: 'normal',
      },
      {
        // 13
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
        format: 'normal',
      },
      {
        // 14
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        format: 'percent',
      },
      {
        // 15
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
        format: 'number',
      },
      {
        // 16 default
        align: 'left',
      },
      {
        // 17 modified
        color: '#1C60FC',
        align: 'left',
      },
      {
        // 18 Highlight low_confidence
        bgcolor: '#FFC0CB',
      },
      {
        // 19 Highlight high_confidence
        bgcolor: '#e9c46a',
      },
      {
        // 20 low confidence and modified
        color: '#1C60FC',
        bgcolor: '#FFC0CB',
      },
      {
        // 21 high confidence and modified
        color: '#1C60FC',
        bgcolor: '#e9c46a',
      },
      {
        // 22 Highlight
        bgcolor: '#FFC0CB',
      },
      {
        // 23 Highlight + modified
        color: '#1C60FC',
        bgcolor: '#FFC0CB',
      },
    ],
    merges: [],
    rows: {},
    cols: {
      '0': {
        width: 293,
      },
      '1': {
        width: 293,
      },
    },
    validations: [],
    autofilter: {},
  };

  sheet2Data = {
    name: 'transactions',
    rows: {},
    cols: {},
    validations: [],
    autofilter: {},
    lockedRows: [{ sheetName: 'transactions', rowNumber: [0] }],
  };

  transactionModification;

  childDocumentDetail: any;
  extractionResultsTabulatorData: any[];
  extractionResultsTabulatorColumns: Column[] = [];
  extractionResultsTabulatorGroupByColumn: string;
  primaryTableRowContextMenuOptions: RowContextMenuConfig = {
    addRowAbove: false,
    addRowBelow: false,
    deleteRow: false,
  };
  childTableRowContextMenuOptions: RowContextMenuConfig = {
    addRowAbove: true,
    addRowBelow: true,
    deleteRow: true,
  };
  primaryTableColumnContextMenuOptions: ColumnContextMenuConfig = {
    insertLeft: false,
    insertRight: false,
    edit: false,
    delete: false,
  };
  childTableColumnContextMenuOptions: ColumnContextMenuConfig = {
    insertLeft: true,
    insertRight: true,
    edit: true,
    delete: true,
  };
  extractionResultsTabulatorActionMenu: ActionMenu = {
    left: [
      {
        label: 'Menu',
        items: [
          {
            label: 'Save',
            action: () => this.extractionResultsTabulator.handleSaveAction(),
          },
          {
            label: 'Edit',
            action: () => this.extractionResultsTabulator.toggleEditMode(),
          },
          {
            label: 'Filter',
            action: () => this.extractionResultsTabulator.toggleFilters(),
          },
          {
            label: 'Export',
          },
        ],
      },
    ],
    right: {
      edit: true,
      filter: true,
    },
  };
  @ViewChild('extractionResultsTabulator', { static: true })
  extractionResultsTabulator: TabulatorComponent;

  constructor(
    private documentService: DocumentService,
    public userService: UserService,
    private roleService: RoleService,
    private router: Router
  ) {}

  async getChildDocumentDetail(childDocumentId: string) {
    try {
      const childDocumentResponse =
        await this.documentService.getChildDocumentById(childDocumentId);
      this.childDocumentDetail = childDocumentResponse.data;
      this.setDataForTabulator(childDocumentResponse.data);
    } catch {
      Swal.fire(
        'Failed',
        'Error while fetching child document detail',
        'error'
      );
    }
  }

  setDataForTabulator(childDocumentData: any) {
    const JSONData = childDocumentData.JSONData;
    this.extractionResultsTabulatorData = JSONData;
    this.extractionResultsTabulatorColumns = [
      {
        title: 'Key',
        field: 'SSOTKey',
        editor: 'input',
      },
      {
        title: 'Value',
        field: 'Value',
        hasTabularData: true,
        editor: 'input',
      },
      {
        title: 'Category',
        field: 'Category',
        editor: 'input',
      },
    ];
  }

  async saveExtractionResultsTabulatorData(updatedData: any[]) {
    try {
      await this.documentService.updateChildDocument(this.childDocumentId, {
        data: updatedData,
      });
      Swal.fire(
        'Success',
        'Extraction results data saved successfully',
        'success'
      );
    } catch {
      Swal.fire('Failed', 'Error while saving child document detail', 'error');
    }
  }

  ngOnInit(): void {
    if (this.childDocumentId) {
      this.getChildDocumentDetail(this.childDocumentId);
    }
    this.userService.getCurrentUser().then((res) => {
      this.userService.getUserDetails(res).then((response) => {
        this.roleService
          .getParentRole(response.roles[0].parentRole)
          .then((role) => {
            this.userRole = role.name;
          });
      });
    });

    this.DigiDocList = window.history.state.data;
    const documentID = document.location.pathname.split('/');

    // let elmWidth = document.querySelector('#testSheet').getBoundingClientRect().width;

    // this.testSheetData.cols[0].width = elmWidth / 2 - 32;
    // this.testSheetData.cols[1].width = elmWidth / 2 - 32;

    this.documentID = documentID[documentID.length - 1];
    this.documentService
      .getDocsByParentID(this.documentID)
      .then((response) => {
        const selectedArticle = response.result[0].digiDocs[0];

        this.dummyData.currentStatus = response.result[0].sourceDoc.Status;

        if (selectedArticle.AnalystComments.length > 0) {
          this.analystComments = selectedArticle.AnalystComments[0].comments;
          this.dummyData.AnalystComments = selectedArticle.AnalystComments;
          this.commentBtn.analystComments = true;
        }

        if (selectedArticle.ApproverComments.length > 0) {
          this.adminComments = selectedArticle.ApproverComments[0].comments;
          this.dummyData.ApproverComments = selectedArticle.ApproverComments;
          this.commentBtn.approverComments = true;
        }

        this.digiDocName = selectedArticle.JSONData[0].tab_name;

        // dummyData
        this.dummyData.length = Object.keys(selectedArticle).length;
        this.dummyData.JSONData[0] = {
          ...selectedArticle.JSONData[0],
          modified: {},
        };

        this.dummyData._id = selectedArticle._id;
        this.dummyData.superParentId = response.result[0].origDoc.SuperParentId;
        this.dummyData.ParentDocumentID = selectedArticle.ParentDocumentID;

        if (response.result[0].digiDocs.length == 2) {
          this.dummyData.statusParent = 'Edited';
        } else {
          this.dummyData.statusParent = 'Original';
        }

        // let val = this.checkCells(selectedArticle.JSONData);
        const val = this.checkValuesAndStore(selectedArticle.JSONData);

        Object.keys(selectedArticle.JSONData[0].json_obj).map((v, i, arr) => {
          this.testSheetData.rows[i] = {
            cells: {
              '0': {
                text: selectedArticle.JSONData[0].json_obj[i][0],
                style: 16,
                editable: false,
              },
              '1': {
                text: selectedArticle.JSONData[0].json_obj[i][1],
                style: val !== null ? val[i] : 16, // val: val[i] ? val[i] : 16
                editable: false,
              },
            },
          };

          this.dummyData.JSONData[0].modified[i] =
            selectedArticle.JSONData[0].modified !== undefined &&
            selectedArticle.JSONData[0].modified[i][1] == 1
              ? {
                  '0': 0,
                  '1': 1,
                }
              : {
                  '0': 0,
                  '1': 0,
                };
        });

        // const s = new Spreadsheet('#testSheet', {
        //   mode: 'edit',
        //   showToolbar: false,
        //   showGrid: true,
        //   showContextmenu: true,
        //   view: {
        //     height: function () {
        //       return 812;
        //     },
        //     width: function () {
        //       return 250;
        //     },
        //   },
        //   row: {
        //     len: Object.keys(this.testSheetData.rows).length,
        //     height: 32,
        //   },
        //   col: {
        //     len: 2,
        //     width: 200,
        //     indexWidth: 60,
        //     minWidth: 60,
        //   },
        // });

        if ('transactions' in selectedArticle.JSONData[0]) {
          const keysTable = [
            'row_no',
            'date',
            'source',
            'deposit',
            'withdrawal',
            'balance',
          ];
          const rows10 = {
            len:
              selectedArticle.JSONData[0].transactions.table_value.length + 1,
          };
          const cols10 = { len: 6 };

          rows10[0] = {
            cells: {
              0: {
                text: keysTable[0],
                editable: false,
              },
              1: {
                text: keysTable[1],
                editable: false,
              },
              2: {
                text: keysTable[2],
                editable: false,
              },
              3: {
                text: keysTable[3],
                editable: false,
              },
              4: {
                text: keysTable[4],
                editable: false,
              },
              5: {
                text: keysTable[5],
                editable: false,
              },
            },
          };

          selectedArticle.JSONData[0].transactions.table_value.map(
            (v, i, arr) => {
              rows10[i + 1] = {
                cells: {
                  0: {
                    text: selectedArticle.JSONData[0].transactions.table_value[
                      i
                    ].row_no.toString(),
                    editable: false,
                  },
                  1: {
                    text: selectedArticle.JSONData[0].transactions.table_value[
                      i
                    ].date,
                    editable: false,
                  },
                  2: {
                    text: selectedArticle.JSONData[0].transactions.table_value[
                      i
                    ].source,
                    editable: false,
                  },
                  3: {
                    text: selectedArticle.JSONData[0].transactions.table_value[
                      i
                    ].deposit,
                    editable: false,
                  },
                  4: {
                    text: selectedArticle.JSONData[0].transactions.table_value[
                      i
                    ].withdrawal.toString(),
                    editable: false,
                  },
                  5: {
                    text: selectedArticle.JSONData[0].transactions.table_value[
                      i
                    ].balance,
                    editable: false,
                  },
                },
              };
            }
          );

          this.sheet2Data.rows = rows10;
          this.sheet2Data.cols = cols10;

          this.dummyData.transactions =
            selectedArticle.JSONData[0].transactions;

          // s.loadData([this.testSheetData, this.sheet2Data]).change((data) => {
          // });
        } else {
          // s.loadData([this.testSheetData]).change((data) => {
          // });
        }

        // s.on('cell-edited', (data: any) => {
        //   // console.log(data)
        //   if (data.name == this.sheet2Data.name) {
        //     this.dummyData.JSONData[0].transactions.table_value = this.convertJsonTransaction(data.rows._)
        //   } else {
        //     this.dummyData.JSONData[0].json_obj[data.selector.ri][data.selector.ci] = data.UpdatedText;
        //     this.dummyData.JSONData[0].modified = {
        //       ...this.dummyData.JSONData[0].modified,
        //       [data.selector.ri]: {
        //         '0': 0,
        //         '1': 1,
        //       },
        //     };
        //   }
        // });

        // s.on('cell-modified', (data) => {
        //   if (data.modifiedType === 'insert-row') {
        //     // console.log(data)
        //     if (data.object.name == this.sheet2Data.name) {
        //       const emptyArray = {
        //         "date": "1-1-2000",
        //         "source": "Text",
        //         "balance": 0,
        //         "withdrawal": 0,
        //         "deposit": 0,
        //         "row_no": 0
        //       }

        //       // this.sheet2Data.rows.(data.object.selector.ri - 1, 0, emptyArray)

        //       this.dummyData.JSONData[0].transactions.table_value.splice(data.object.selector.ri, 0, emptyArray);
        //     } else {
        //       let insertedIndex = data.object.selector.ri + 1;
        //       this.insertedRowList.push(insertedIndex);

        //       this.dummyData.JSONData[0].json_obj.splice(insertedIndex, 0, {
        //         0: '',
        //         1: '',
        //       });
        //       let placeholderObject;

        //       if (selectedArticle.JSONData[0].modified !== undefined) {
        //         placeholderObject = {};

        //         for (let index = 0; index < this.dummyData.JSONData[0].json_obj.length; index++) {
        //           if (index < insertedIndex) {
        //             placeholderObject[index] = selectedArticle.JSONData[0].modified[index];
        //           } else if (insertedIndex == index) {
        //             placeholderObject[index] = {
        //               '0': 0,
        //               '1': 1,
        //             };
        //           } else {
        //             // this.dummyData.JSONData[0].modified[index] = selectedArticle.JSONData[0].modified[index]
        //             placeholderObject[index] =
        //               selectedArticle.JSONData[0].modified[index] !== undefined
        //                 ? selectedArticle.JSONData[0].modified[index]
        //                 : {
        //                   '0': 0,
        //                   '1': 0,
        //                 };
        //             // delete this.dummyData.JSONData[0].modified[index];
        //           }
        //         }

        //         this.dummyData.JSONData[0].modified = placeholderObject;
        //       } else {
        //         if (this.dummyData.JSONData[0].json_obj.length - 1 == insertedIndex) {
        //           this.dummyData.JSONData[0].modified[insertedIndex + 1] = {
        //             '0': 0,
        //             '1': 1,
        //           }
        //         } else {
        //           for (let index = 0; index < this.dummyData.JSONData[0].json_obj.length - 1; index++) {
        //             if (index < insertedIndex) {
        //               this.dummyData.JSONData[0].modified[index] = this.dummyData.JSONData[0].modified[index][1] == 1 ? {
        //                 '0': 0,
        //                 '1': 1,
        //               } : {
        //                 '0': 0,
        //                 '1': 0,
        //               };
        //             } else if (index == insertedIndex) {
        //               this.dummyData.JSONData[0].modified[index] = {
        //                 '0': 0,
        //                 '1': 1,
        //               };
        //             } else if (index > insertedIndex) {
        //               this.dummyData.JSONData[0].modified[index + 1] = this.dummyData.JSONData[0].modified[index][1] == 1
        //                 ? {
        //                   '0': 0,
        //                   '1': 1,
        //                 }
        //                 : {
        //                   '0': 0,
        //                   '1': 0,
        //                 };
        //             }
        //           }
        //         }
        //       }
        //     }
        //   } else if (data.modifiedType === 'delete-row') {
        //     if (data.object.name == this.sheet2Data.name) {
        //       this.dummyData.JSONData[0].transactions.table_value.splice(data.object.selector.ri - 1, 1)
        //     } else {
        //       // Index of deleted row
        //       let deletedIndex = data.object.selector.ri;
        //       // console.log(deletedIndex)

        //       // Delete from InsertedRowList
        //       if (this.insertedRowList.includes(deletedIndex)) {
        //         this.insertedRowList.splice(this.insertedRowList.indexOf(deletedIndex), 1)
        //       }

        //       // Delete from dummyData.json_obj
        //       this.dummyData.JSONData[0].json_obj.splice(deletedIndex, 1)
        //       if ('modified' in this.dummyData.JSONData[0]) {
        //         this.dummyData.JSONData[0].modified = this.deleteAndIndexObjectValue(this.dummyData.JSONData[0].modified, deletedIndex);
        //       }

        //       // console.log(this.deleteAndIndexObjectValue(selectedArticle.JSONData[0].modified, deletedIndex));
        //     }
        //   }
        // });

        // s.on('cell-selected', (cell, ri, ci) => {
        //   if (!this.editableText) {
        //     if (ci === 1) {
        //       let details = {
        //         ParentDocumentID: selectedArticle.ParentDocumentID,
        //         row: ri,
        //         col: ci,
        //       };

        //       this.documentService.getHighlightedLoanDocs(details).then((res) => {
        //         // console.log("Details: ", selectedArticle)
        //         // console.log("Highlighted: ", selectedArticle.JSONData[0].coordinateList[ri])
        //         // console.log("Highlighted: ", selectedArticle.JSONData[0].coordinateList[ri][0][0])
        //         this.highlightedBase.emit(res.highlighted);
        //         this.pageNum.emit(parseInt(selectedArticle.JSONData[0].coordinateList[ri][0][0]));
        //       }).catch((err) => {
        //         console.log(err);
        //       });
        //     }
        //   }
        // });
      })
      .catch(function (err) {
        console.log('err in fetch Processed Document Object function', err);
      });

    this.DataLoaded.emit(true);
  }

  convertJsonTransaction(data) {
    const result = [];
    const rows: any = Object.values(data);

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i].cells;
      const obj: any = {};

      obj.row_no = row[0] !== undefined ? parseInt(row[0].text) : '';
      obj.date = row[1] !== undefined ? row[1].text : '';
      obj.source = row[2] !== undefined ? row[2].text : '';
      obj.deposit = row[3] !== undefined ? parseFloat(row[3].text) : '';
      obj.withdrawal = row[4] !== undefined ? parseFloat(row[4].text) : '';
      obj.balance = row[5] !== undefined ? parseFloat(row[5].text) : '';

      result.push(obj);
    }

    return result;
  }

  deleteAndIndexObjectValue(obj, int) {
    const outputObject = {};
    // delete obj[int];
    let index = 0;

    for (const key in obj) {
      if (key !== int.toString()) {
        const value = obj[key];
        outputObject[index] = value;
        index++;
      }
    }

    return outputObject;
  }

  checkValuesAndStore(JSONData) {
    const result = {};

    // JSONData[0].modified - 17
    // JSONData[0].corrected_cells
    // JSONData[0].corrected_cells.low_confidence - 18
    // JSONData[0].corrected_cells.high_confidence - 19

    // low confidence and modified 20
    // high confidence and modified 21

    // both corrected_cells are true 22
    // both corrected_cells are true and modfied 23

    const { modified, corrected_cells } = JSONData[0];
    const { low_confidence, high_confidence } = corrected_cells || {};

    for (let i = 0; i < Object.keys(JSONData[0].json_obj).length; i++) {
      const isModified = modified && modified[i][1] === 1;
      const isLowConfidence = low_confidence && low_confidence[i][1] === 1;
      const isHighConfidence = high_confidence && high_confidence[i][1] === 1;

      if (isModified) {
        if (isLowConfidence && isHighConfidence) {
          result[i] = 23;
        } else if (isLowConfidence || isHighConfidence) {
          result[i] = isLowConfidence ? 20 : 21;
        } else {
          result[i] = 17;
        }
      } else if (isLowConfidence && isHighConfidence) {
        result[i] = 18;
      } else if (isLowConfidence) {
        result[i] = 18;
      } else if (isHighConfidence) {
        result[i] = 19;
      }
    }

    return Object.keys(result).length > 0 ? result : null;
  }

  backToConsolidated(id) {
    this.router.navigateByUrl(
      'documents/summary/' + this.dummyData.superParentId
    );
  }

  deleteDigitizedDocument() {
    // console.log(this.dummyData);
    if (this.dummyData.statusParent == 'Edited') {
      this.documentService
        .deleteDigitizedDocumentByID(this.dummyData._id)
        .then((res) => {
          this.RefreshEvent.emit(true);
        })
        .catch(function (err) {
          console.log('err in fetch Processed Document Object function', err);
        });
    }
  }

  downloadDigitizeDocumentExcel() {
    this.documentService
      .downloadDigitizedDoc(this.dummyData.ParentDocumentID)
      .then((res) => {
        const file = new Blob([res], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });

        const url = window.URL.createObjectURL(file);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.href = url;
        a.download = `Document ID - ${this.dummyData._id}.xls`;
        a.click();
      })
      .catch(function (err) {
        console.log('err in fetch Processed Document Object function', err);
      });
  }

  downloadDigitizeDocumentJSON() {
    const file = new Blob(
      [JSON.stringify(this.dummyData.JSONData[0].json_obj)],
      {
        type: 'application/json',
      }
    );
    const a = document.createElement('a');
    a.href = URL.createObjectURL(file);
    a.download = `Document ID - ${this.dummyData._id}`;
    a.click();
  }

  saveDigitizedDocumentUpdate() {
    this.documentService
      .cloneDigitizedDocument(this.dummyData)
      .then((res) => {
        if (res.error_code == 0) {
          this.RefreshEvent.emit(true);
        }
      })
      .catch(function (err) {
        console.log('err in fetch Processed Document Object function', err);
      });
  }

  editRowSpreadsheet() {
    if (this.editableText == false) {
      Object.keys(this.testSheetData.rows).map((v, i) => {
        this.testSheetData.rows[i].cells[1].editable = true;
      });

      // console.log(this.dummyData.JSONData[0].transactions)

      for (
        let index = 0;
        index < Object.keys(this.sheet2Data.rows).length;
        index++
      ) {
        if (index !== 0) {
          const cells = this.sheet2Data.rows[index];

          for (let index = 0; index < Object.keys(cells).length; index++) {
            const element = cells;

            element.cells[index].editable = false;
          }
        }
      }

      for (
        let index = 0;
        index < Object.keys(this.sheet2Data.rows).length;
        index++
      ) {
        if (index !== 0) {
          const cells = this.sheet2Data.rows[index];

          for (let index = 0; index < Object.keys(cells).length; index++) {
            const element = cells;

            element.cells[index].editable = true;
          }
        }
      }

      this.editableText = !this.editableText;
    } else if (this.editableText == true) {
      Object.keys(this.testSheetData.rows).map((v, i) => {
        this.testSheetData.rows[i].cells[1].editable = false;
      });

      for (
        let index = 0;
        index < Object.keys(this.sheet2Data.rows).length;
        index++
      ) {
        if (index !== 0) {
          this.sheet2Data.rows[index].cells[0].editable = false;
          this.sheet2Data.rows[index].cells[1].editable = false;
          this.sheet2Data.rows[index].cells[2].editable = false;
          this.sheet2Data.rows[index].cells[3].editable = false;
          this.sheet2Data.rows[index].cells[4].editable = false;
          this.sheet2Data.rows[index].cells[5].editable = false;
        }
      }

      this.editableText = !this.editableText;
    }
    this.editableSubject.next(this.editableText);
  }

  showFilters() {
    if (this.filterable == false) {
      this.filterable = !this.filterable;
    } else if (this.filterable == true) {
      this.filterable = !this.filterable;
    }
    this.filtersSubject.next(this.filterable);
  }

  saveModalInput() {
    this.documentService
      .setComment(
        'Analyst',
        this.dummyData._id,
        this.modalInput,
        'Pending Approval'
      )
      .then((res) => {
        this.RefreshEvent.emit(true);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  saveModalApprover() {
    if (this.modalInputApprover.length !== 0) {
      this.documentService
        .setComment(
          'Approver',
          this.dummyData._id,
          this.modalInputApprover,
          'Approved'
        )
        .then((res) => {
          this.RefreshEvent.emit(true);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  rejectModalApprover() {
    if (this.modalInputApprover.length !== 0) {
      this.documentService
        .setComment(
          'Approver',
          this.dummyData._id,
          this.modalInputApprover,
          'Rejected'
        )
        .then((res) => {
          this.RefreshEvent.emit(true);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }
}
