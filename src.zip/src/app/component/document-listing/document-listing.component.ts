import { Component, OnInit } from '@angular/core';
import { DocumentService } from '../../services/document.service';
import { NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs';
import { ListingHompageDataService } from '../../services/listinghompagedata.service';
import Swal from 'sweetalert2';
import { FileSaverService } from 'ngx-filesaver';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import { APP_PERMISSIONS } from '../../shared/constants/app-permissions.constant';
import { DATE_FORMATS } from '../../shared/constants/date.constant';
import { UserService } from 'src/app/services/user.service';
import { param } from 'jquery';
import { ChipOption } from 'src/app/shared/components/chip-options/interfaces/chip-option.interface';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { NgxPaginationModule } from 'ngx-pagination';
import { AngularMaterialModule } from 'src/app/material.module';
import { InternationalizationModule } from 'src/app/core/internationalization/internationlisation.module';
import { ShowIfAuthorizedDirective } from 'src/app/shared/directives/show-if-authorized.directive';
import { ChipOptionsComponent } from 'src/app/shared/components/chip-options/chip-options.component';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import {
  ActionConditionEvent,
  ActionEnum,
  Column,
  ColumnStyle,
  DataType,
  PipeType,
  SelectRowItem,
  TableActionItem,
  TableConfiguration,
} from 'src/app//shared/components/data-table/interfaces/table-config.interface';
import { DataTableComponent } from 'src/app/shared/components/data-table/data-table.component';

@Component({
  selector: 'app-document-listing',
  templateUrl: './document-listing.component.html',
  styleUrls: ['./document-listing.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE],
    },
    { provide: MAT_DATE_FORMATS, useValue: DATE_FORMATS.MAT_DATE_FORMAT },
    DatePipe,
  ],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    NgxSkeletonLoaderModule,
    AngularMaterialModule,
    ChipOptionsComponent,
    NgxPaginationModule,
    InternationalizationModule,
    ShowIfAuthorizedDirective,
    DataTableComponent,
  ],
})
export class DocumentListingComponent implements OnInit {
  slectedData: any;
  selectedFilterData: any;
  get appPermissions() {
    return APP_PERMISSIONS;
  }
  isDeleteFilesButtonDisabled = true;
  showdots = true;
  isSortedDocument = false;
  fromDate: Date = null;
  toDate: Date = null;
  savedOptions: any;
  filterdata: any = {}; // TODO: Check
  homepagefilter: any = {}; // TODO: Check
  searchCopy = ''; // TODO: Check
  deleteCheckbox = {
    // TODO: Check
    value: false,
  };
  search = ''; // TODO: Check
  isIndividualDocPage = false; // TODO: Check
  isFetchDeletedFiles = false;
  isAdvanceSearch = false; // TODO: Check
  allDocumentStatuses = {};
  totalPageItems: number;
  currentPage: any;
  selectedFileIndexes: boolean[] = [];
  fileProcessChecker: any[];
  localExpand: any;
  reverse = {
    DocumentName: true,
    Status: true,
    LastUpdated: true,
  };
  isSelectAllFiles = false;
  documentStats = {}; // TODO: Check
  documentCount = 0;
  isSearched = false;
  options = {};
  deleteCheckbo = false;
  documentListDictionary: Record<string, ChipOption>;
  searchCategoriesInitializer = {
    Status: [],
    'File Name': '',
    Client: [],
    'Document Type': [],
    'Uploaded By': '',
  };
  selectedClientTitles = [];
  selectedStatuses = [];
  selectedDocumentTypes = [];
  UploadedBy = '';
  DocumentName = '';
  isLoadingDocumentList = false;
  pagedFiles = [];
  expand = [];
  isGetDocByPage = false;
  PDFsrc: Uint8Array;
  searchCategories = JSON.parse(
    JSON.stringify(this.searchCategoriesInitializer)
  );
  itemsPerPage = 10;
  page = 1;

  dataTableColumn: Column[] = [
    {
      title: 'Status',
      field: 'Status',
      customStyle: true,
      className: 'statuschipblock',
    },
    {
      title: 'DocumentName',
      field: 'DocumentName',
      clickable: true,
      className: 'document-name',
    },
    {
      title: 'Client Name',
      field: 'ClientName',
      orderable: false,
    },
    {
      title: 'Summary',
      field: 'ChildDocStats',
      orderable: false,
      dataType: DataType.array,
      subColumns: ['key', 'count'],
    },
    {
      title: 'Last Updated',
      field: [
        {
          title: 'LastUpdatedBy',
          field: 'LastUpdatedBy',
        },
        {
          title: 'LastUpdatedTimestamp',
          field: 'LastUpdatedTimestamp',
          pipeType: PipeType.date,
          pipeFormat: 'short',
        },
      ],
    },
  ];
  tableConfiguration: TableConfiguration = {
    rowActions: [
      {
        icon: 'fas fa-eye',
        action: ActionEnum.view,
        tooltip: 'documents.redigitize file',
        permission: this.appPermissions.VIEW_DOCUMENTS,
      },
      {
        icon: 'fas fa-sync-alt',
        action: ActionEnum.refresh,
        tooltip: 'documents.redigitize file',
        permission: this.appPermissions.REDIGITIZE_DOCUMENT,
      },
      {
        icon: 'fa fa-download',
        action: ActionEnum.download,
        tooltip: 'documents.download',
        permission: this.appPermissions.DOWNLOAD_DIGITIZED,
      },
      {
        icon: 'fas fa-trash',
        action: ActionEnum.delete,
        tooltip: 'documents.delete',
        permission: this.appPermissions.DELETE_DOCUMENTS,
      },
      {
        icon: 'fa fa-recycle',
        action: ActionEnum.restore,
        tooltip: 'restore',
        permission: this.appPermissions.RESTORE_DOCUMENTS,
      },
      {
        icon: 'fa fa-minus-circle',
        action: ActionEnum.forcedelete,
        tooltip: 'force delete',
        permission: this.appPermissions.DELETE_DOCUMENTS,
      },
    ],
    tableActions: [
      {
        label: 'DELETE FILES',
        icon: 'fas fa-ban',
        disabled: true,
        class: 'btn deletebutton',
        permission: this.appPermissions.DELETE_DOCUMENTS,
        action: () =>
          this.confirmAndDeleteMultipleFiles(this.selectedFileIndexes),
      },
    ],
    selectable: true,
    pagination: true,
    borders: {
      bottom: true,
      top: true,
    },
    searching: false,
  };
  constructor(
    public calendar: NgbCalendar,
    public documentService: DocumentService,
    private route: ActivatedRoute,
    private router: Router,
    private fileSaverService: FileSaverService,
    private listingHomePageDataService: ListingHompageDataService,
    private userService: UserService,
    private localStorageService: LocalStorageService,
    private pipeInstance: DatePipe
  ) {}

  ngOnInit() {
    this.searchCategories =
      this.localStorageService.getItem('searchCategories');
    if (this.searchCategories) {
      this.selectedFilterData = this.searchCategories;
    }
    this.isLoadingDocumentList = true;
    this.getConfigListingParams();
    this.getDocumentStatusList();
    this.currentPage = 1;
    this.initilizeFiltersAndGetDocumentList();
    this.localStorageService.setItem('searchCategories', this.searchCategories);
  }

  getDocumentStatusList(): void {
    this.documentService.getStatusList().then((statusListResponse) => {
      const listofStatus = statusListResponse?.data ?? [];
      for (
        let documentStatusIndex = 0;
        documentStatusIndex < listofStatus.length;
        documentStatusIndex++
      ) {
        if (!this.allDocumentStatuses[listofStatus[documentStatusIndex].name]) {
          this.allDocumentStatuses[listofStatus[documentStatusIndex].name] = {
            color: listofStatus[documentStatusIndex].statuscolor,
            background: listofStatus[documentStatusIndex].background,
          };
        }
      }
    });
  }

  getConfigListingParams(): void {
    this.documentService.getConfigListingParams().then((response) => {
      if (response?.data) {
        this.documentListDictionary = response.data;
      }
    });
  }

  initilizeFiltersAndGetDocumentList(): void {
    this.listingHomePageDataService.currentfilters.subscribe(
      (filters) => (this.homepagefilter = filters)
    );
    if (this.homepagefilter['Type'] !== 'none') {
      this.fromDate = this.homepagefilter['fromDate'];
      this.toDate = this.homepagefilter['toDate'];
      this.selectedClientTitles.push(this.homepagefilter['Client']);
      this.selectedDocumentTypes.push(this.homepagefilter['Type']);
      this.selectedStatuses.push(this.homepagefilter['Status']);
      this.options['searchCategories'] = JSON.stringify({
        Status: this.selectedStatuses,
        'File Name': '',
        Client: this.selectedClientTitles,
        'Document Type': [],
        'Uploaded By': this.UploadedBy,
      });
      this.options['page'] = 1;
      this.options['limit'] = 10;
      this.options['fromDate'] = this.fromDate;
      this.options['toDate'] = this.toDate;
      this.options['isDeleted'] = false;
      this.options['search'] = '';
      this.homepagefilter['Type'] = 'none';

      if (this.selectedStatuses[0] === 'Digitization Failed') {
        this.showDashboardDocs(this.homepagefilter['ParentId']);
      } else {
        this.updateSearchCriteria('');
      }
    } else {
      this.route.params.subscribe(() => {
        if (
          this.localStorageService.getItem('fromDate') &&
          this.localStorageService.getItem('toDate') &&
          this.localStorageService.getItem('DocsAPIOptions')
        ) {
          this.savedOptions = JSON.parse(
            this.localStorageService.getItem('DocsAPIOptions')
          );
          this.fromDate = new Date(
            this.localStorageService.getItem('fromDate')
          );
          this.toDate = new Date(this.localStorageService.getItem('toDate'));
          // this.savedOptions["SearchCategories"]=JSON.stringify(localStorage.SearchCategories)
          const searchCategories = JSON.parse(
            this.savedOptions['searchCategories']
          );
          this.selectedClientTitles = searchCategories['Client'];
          this.selectedDocumentTypes = searchCategories['Document Type'];
          this.selectedStatuses = searchCategories['Status'];
          this.options = this.savedOptions;
          this.updateSearchCriteria('');
        } else {
          const today = new Date();
          this.fromDate = new Date(today.getTime() - 180 * 24 * 60 * 60 * 1000);
          this.toDate = new Date();
          this.search = '';
          this.localStorageService.setItem('search', '');
          this.localStorageService.setItem('fromDate', this.fromDate);
          this.localStorageService.setItem('toDate', this.toDate);
          this.updateSearchCriteria('');
        }
      });
    }
  }

  updateSearchCriteria(isReset: unknown): void {
    this.currentPage = 1;
    if (isReset === true) {
      this.search = '';
      this.isSearched = false;
      this.deleteCheckbox.value = false;
      this.clearSearch();
    } else if (isReset == 'navigateBack') {
      // Check: This if seems unused
      this.isIndividualDocPage = false;
      window.location.href = '/index/document/listing';
    } else {
      this.isSearched = true;
    }
    this.fetchPaginatedDocumentList(this.itemsPerPage);
  }

  selectTablePageSize(itemsPerPage: number) {
    this.currentPage = 1;
    this.fetchPaginatedDocumentList(itemsPerPage);
  }

  fetchPaginatedDocumentList(itemsPerPage: number) {
    this.itemsPerPage = itemsPerPage;
    this.route.params.subscribe((params) => {
      if (
        Object.prototype.hasOwnProperty.call(param, 'id') &&
        params['id'] !== undefined
      ) {
        this.isIndividualDocPage = true;
      }
    });
    this.isLoadingDocumentList = true;
    const options = {
      page: this.currentPage,
      limit: itemsPerPage,
      searchCategories: JSON.stringify({
        Status: this.filterdata['status'],
        DocumentName: this.filterdata['fileName'] || this.DocumentName,
        Client: this.selectedClientTitles,
        'Document Type': this.filterdata['documentType'],
        UploadedBy: this.UploadedBy || this.filterdata['uploadedBy'],
      }),
      search: this.isAdvanceSearch === false ? this.search : undefined,
      fromDate: this.fromDate,
      toDate: this.toDate,
      isDeleted: this.isFetchDeletedFiles,
      isAdvanceSearch: this.isAdvanceSearch,
    };
    options.isAdvanceSearch = true;
    if (options['search'].length > 0) {
      options.isAdvanceSearch = false;
      this.selectedStatuses = [];
      this.DocumentName = '';
      this.selectedClientTitles = [];
      this.selectedDocumentTypes = [];
      this.UploadedBy = '';
    }

    this.localStorageService.setItem(
      'searchCategories',
      options.searchCategories
    );
    this.localStorageService.setItem('isDeleted', this.deleteCheckbox.value);
    this.localStorageService.setItem('fromDate', new Date(this.fromDate));
    this.localStorageService.setItem('toDate', new Date(this.toDate));
    this.localStorageService.setItem('isSearched', this.isSearched);
    if (this.isAdvanceSearch) {
      this.localStorageService.setItem('search', this.searchCopy);
    } else {
      this.localStorageService.setItem('search', this.search);
    }
    this.validateDueDatesAndFetchDocumentList(options);
  }

  validateDueDatesAndFetchDocumentList(options) {
    if (new Date(this.fromDate).getTime() > new Date(this.toDate).getTime()) {
      Swal.fire({
        title: 'From Date > To Date',
        text: 'Please pick To Date > From Date ',
        icon: 'warning',
        showCancelButton: false,
        confirmButtonColor: '#2196F3',
        confirmButtonText: 'OK',
      });
      return;
    }
    this.getDocumentsByPage(options);
  }

  getDocumentsByPage(options) {
    this.documentService
      .getDocumentsByPage(options)
      .then((response) => {
        this.isLoadingDocumentList = false;
        if (response) {
          this.pagedFiles = response.data.docs || [];
          this.documentCount = response.data.docs?.length;
          this.expand = [];
          if (this.isGetDocByPage) {
            this.localStorageService.getItem('expand')?.split(',');
          }
          if (this.pagedFiles) {
            for (let i = 0; i < this.pagedFiles.length; i++) {
              this.pagedFiles[i]['ChildDocStats'] = this.getChildDocumentCount(
                this.pagedFiles[i]
              );
              if (this.isGetDocByPage) {
                this.expand[i] = this.localExpand[i] === 'true';
              } else {
                this.expand[i] = false;
              }
            }
          }
          this.isGetDocByPage = false;
          this.localStorageService.setItem('expand', undefined);
          this.localStorageService.setItem(
            'DocsAPIOptions',
            JSON.stringify(options)
          );
          this.totalPageItems =
            response.data.total === undefined ? 0 : response.data.total || 0;
          this.currentPage = response.page ?? this.currentPage;
          this.selectedFileIndexes =
            this.pagedFiles !== undefined
              ? new Array(this.pagedFiles.length)
              : undefined;
          this.fileProcessChecker =
            this.pagedFiles !== undefined
              ? new Array(this.pagedFiles.length)
              : undefined;
          if (this.selectedFileIndexes !== undefined)
            this.selectedFileIndexes.fill(false);
          if (this.fileProcessChecker !== undefined)
            this.fileProcessChecker.fill(false);
          this.search = this.localStorageService.getItem('search');
          this.resetDocumentStats();
          /* START - Right now response does not have statistics */
          for (let i = 0; i < response.statistics?.length; i++) {
            this.documentStats[response.statistics[i]._id] =
              response.statistics[i].count;
            this.documentStats[response.statistics[i]._id] =
              response.statistics[i].count;
          }
          this.documentStats['Total'] = response.count;
          /* END - Right now response does not have statistics */
        }
      })
      .catch(() => (this.isLoadingDocumentList = false));
  }

  resetDocumentStats(): void {
    this.documentStats = {
      Total: 0,
      Failed: 0,
      'In Process': 0,
      'In Queue': 0,
      Approved: 0,
      'Pending Approval': 0,
      'Pending Validation': 0,
      'Extraction Failed': 0,
      'Digitization Failed': 0,
      Digitized: 0,
      Rejected: 0,
      Found: 0,
      New: 0,
      TBD: 0,
    };
  }

  confirmAndDeleteMultipleFiles(selectedFileIndexes: boolean[]): void {
    let selectedFileIds: string[] = [];
    for (let i = 0; i < selectedFileIndexes.length; i++) {
      if (selectedFileIndexes[i]) {
        selectedFileIds = [...selectedFileIds, this.pagedFiles[i]._id];
      }
    }
    Swal.fire({
      title: 'Confirm Delete',
      text: `Are you sure you want to delete file ${selectedFileIds.length} file(s) ?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Delete',
    })
      .then((isConfirm) => {
        if (Object.prototype.hasOwnProperty.call(isConfirm, 'dismiss')) {
          Swal.fire('Cancelled', 'Files are safe :) ', 'error');
        } else {
          this.deleteMultipleDocuments(selectedFileIds);
        }
      })
      .catch(() => {
        Swal.fire('Error', 'Please try again');
      });
  }

  deleteMultipleDocuments(documentIds: string[]) {
    this.documentService
      .deleteDocumentByIDs(documentIds)
      .then(() => {
        Swal.fire({
          icon: 'success',
          title: 'Deleted!',
          timer: 1500,
          showConfirmButton: false,
        });
        this.fetchPaginatedDocumentList(this.itemsPerPage);
      })
      .catch(() => {
        Swal.fire('Failed to Delete Files', 'Please try again');
      });
  }

  viewProcessedDocument(
    url: string,
    documentId: string,
    documentName: string
  ): void {
    this.searchCategories =
      this.localStorageService.getItem('searchCategories');
    this.localStorageService.setItem('superParentDocumentName', documentName);
    const documentUrl = `${url}/${documentId}`;
    this.router.navigateByUrl(documentUrl, {
      state: {
        parentDocumentId: documentId,
        documentName: documentName,
        itemsPerPage: this.itemsPerPage === undefined ? 10 : this.itemsPerPage,
        currentPage: this.currentPage,
        searchCategories: this.searchCategories,
        basicSearch: this.isAdvanceSearch === false ? this.search : undefined,
        isAdvanceSearch: this.isAdvanceSearch,
        originalDocumentName: documentName,
      },
    });
  }

  onPageChange(event: Event) {
    this.isDeleteFilesButtonDisabled = true;
    this.options['page'] = event;
    this.currentPage = event;
    this.fetchPaginatedDocumentList(this.itemsPerPage);
    this.selectedFileIndexes = new Array(this.pagedFiles.length);
    this.selectedFileIndexes.fill(false);
  }

  sortTableByColumnName(columnName: string) {
    this.reverse[columnName] = !this.reverse[columnName];
    if (!this.isSortedDocument) {
      this.pagedFiles.sort((a, b) =>
        a[columnName]?.localeCompare(b[columnName])
      );
      this.isSortedDocument = true;
    } else {
      this.pagedFiles
        .sort((a, b) => a[columnName]?.localeCompare(b[columnName]))
        .reverse();
      this.isSortedDocument = false;
    }
  }

  clearSearch(): void {
    this.search = '';
    this.searchCopy = '';
    this.isAdvanceSearch = false;
    this.deleteCheckbox.value = false;
    this.selectedClientTitles = [];
    this.selectedStatuses = [];
    this.selectedDocumentTypes = [];
    this.toDate = new Date();
    const searchKeys = Object.keys(this.searchCategories);
    for (let indexSearch = 0; indexSearch < searchKeys.length; indexSearch++) {
      this.clearSearchHelper(searchKeys[indexSearch]);
    }
  }

  clearSearchHelper(category: string): void {
    if (category === 'DocumentName' || category === 'UploadedBy') {
      this.searchCategories[category] = '';
    } else if (
      category === 'Status' ||
      category === 'ClientTitle' ||
      category === 'Type'
    ) {
      this.searchCategories[category] = [];
    } else {
      this.searchCategories[category] = {
        from: '',
        to: '',
      };
    }
  }

  getChildDocumentCount(document) {
    let childDocKeys = [];
    const details = document.ChildDocDetails;
    for (const key in details) {
      for (const secondKey in details[key]) {
        for (const thirdKey in details[key][secondKey]) {
          childDocKeys = [
            ...childDocKeys,
            {
              key: thirdKey,
              count: details[key][secondKey][thirdKey]['count'],
            },
          ];
        }
      }
    }
    return childDocKeys;
  }

  downloadDigitizedDocument(file) {
    // Placeholder method for below 2 methods
  }

  /* Below functions prepares data for excel generation, all logic can be shifted to API and return document to download
  downloadDigitizedDocument(file) {
    const finalExcelData = [];
    this.documentService.getDocsByParentID(file._id).then((response) => {
      if (response.result && response.result.length > 0) {
        const tableData = [];
        const formulaList = [];
        const sheetNames = [];
        const typeList = [];
        for (let i = 0; i < response.result.length; i++) {
          const digitizedDocument = response.result[i]['digiDocs'][0];
          const document = digitizedDocument.JSONData;
          document.forEach(function (page) {
            tableData.push(page.json_obj);
            formulaList.push(page.formulae);
            sheetNames.push({
              title: response.result[i]['origDoc']['DocumentName'],
            });
            typeList.push('Mortgage Loan Document');
          });
          if (
            response.result[i]['origDoc']['DocumentName'].indexOf('Bank') !==
              -1 &&
            Object.keys(digitizedDocument.JSONData[0].transactions).length > 0
          ) {
            if (
              digitizedDocument.JSONData[0].transactions !== undefined &&
              digitizedDocument.JSONData[0].transactions.table_value !==
                undefined &&
              digitizedDocument.JSONData[0].transactions.table_value.length >
                0 &&
              digitizedDocument.JSONData[0].transactions.table_value !== null
            ) {
              const sheetNumber =
                response.result[i]['origDoc']['DocumentName'].split('_')[1];
              if (sheetNumber !== undefined) {
                sheetNames.push({
                  title: 'Transaction Statements' + '_' + sheetNumber,
                });
              } else {
                sheetNames.push({ title: 'Transaction Statements' });
              }
              const rows = [];
              const headers = [
                'Page No',
                'Account No',
                'Date',
                'Source',
                'Deposit',
                'Withdrawal',
                'Balance',
              ];
              const transactions =
                digitizedDocument.JSONData[0].transactions.table_value;
              for (let j = 0; j < transactions.length; j++) {
                rows.splice(j, 0, [
                  transactions[j].page_n !== undefined
                    ? String(transactions[j].page_n)
                    : '',
                  transactions[j].acct_num !== undefined
                    ? String(transactions[j].acct_num)
                    : '',
                  transactions[j].date,
                  transactions[j].source,
                  transactions[j].deposit !== undefined
                    ? transactions[j].deposit
                    : '',
                  transactions[j].withdrawal !== undefined
                    ? transactions[j].withdrawal
                    : '',
                  transactions[j].balance,
                ]);
              }
              rows.splice(0, 0, headers);
              tableData.push(rows);
            }
          }
        }
        for (let i = 0; i < tableData.length; i++) {
          (function (index, tableDataLength, callback) {
            const jsonToExport = [];
            tableData[index].map(function (element) {
              const eachElement = [];
              for (const elementProp in element) {
                if (
                  Object.prototype.hasOwnProperty.call(element, elementProp) &&
                  elementProp !== '$$hashKey' &&
                  elementProp !== '-1'
                ) {
                  const str = element[elementProp];
                  eachElement.push(str);
                }
              }
              jsonToExport.push(eachElement);
            });
            finalExcelData[i] = jsonToExport;
            if (i === tableDataLength - 1) {
              return callback(finalExcelData);
            }
          })(i, tableData.length, function (finalExcelData) {
            if (file.Type === 'Forms') {
              const tableInfo = document[0]['table_information'];
              const headerList = [];
              const newExcel = [];
              for (let i = 0; i < tableInfo.length; i++) {
                headerList.push(tableInfo[i].header);
              }
              newExcel.push(headerList);
              for (let i = 0; i < finalExcelData[0].length; i++) {
                newExcel.push(finalExcelData[0][i]);
              }
              finalExcelData[0] = newExcel;
            }

            // console.log(finalExcelData)
            //var filePath = file.DocumentName.substring(0, file.DocumentName.lastIndexOf('.'));
            // this.documentService.convertToExcel(finalExcelData, filePath, formulaList,typeList, sheetNames).success(function (excel) {
            //     // saveAs(excel, filePath + '.xlsx', function (response) {
            //     //     compareService.deleteIntermediateFile("document.xlsx");
            //     // });
            //     this.fileSaverService.save(response, file.DocumentName.slice(0,-4)+".xlsx");
            // });
          });
        }
        const filePath = file.DocumentName.substring(
          0,
          file.DocumentName.lastIndexOf('.')
        );
        this.downloadDigitized1(
          finalExcelData,
          filePath,
          formulaList,
          typeList,
          sheetNames,
          response,
          file
        );
      }
    });

    // let Docs:any;

    // // this.documentService.getDocumentParentById(_id)
    // // .then((response) => {
    // //   Docs = response.doc;
    // // })
    // console.log(file.ChildIds)
    // file.ChildIds.forEach((child)=>
    // {
    //   console.log(child)
    //  this.documentService.downloadDigitizedDoc(child).then((response)=>{
    //    this.fileSaverService.save(response, file.DocumentName.slice(0,-4)+".xlsx");
    //  })
    // })
  }

  async downloadDigitized1(
    finalExcelData,
    filePath,
    formulaList,
    typeList,
    sheetNames,
    response,
    file
  ) {
    const excel = await this.documentService.convertToExcel(
      finalExcelData,
      filePath,
      formulaList,
      typeList,
      sheetNames
    ); //.success(function (excel) {
    // saveAs(excel, filePath + '.xlsx', function (response) {
    //     compareService.deleteIntermediateFile("document.xlsx");
    // });
    this.fileSaverService.save(excel, file.DocumentName.slice(0, -4) + '.xlsx');
    //});
  }
  */

  confirmAndRedigitizeDocument(file: unknown): void {
    Swal.fire({
      title: 'Confirm Redigitize',
      text: 'Are you sure you want to Redigitize this file?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Redigitize',
    })
      .then((isConfirm) => {
        if (Object.prototype.hasOwnProperty.call(isConfirm, 'dismiss')) {
          Swal.fire('Cancelled', 'File is safe :) ', 'error');
        } else {
          // this.redigitizeDocument(file);
        }
      })
      .catch(() => {
        Swal.fire('Error', 'Please try again');
      });
  }

  /* APIs used below are throwing error
  redigitizeDocument(file) {
    if (file.Status === 'Digitization Failed' || file.Status == 'New') {
      this.documentService.processDocumentByID(file._id, file.Type).then(
        function () {
          // location.reload()
        },
        function () {
          // sweetAlertAutoClose("Process file failed", "File " + name + " is not processed", "error");
        }
      );
    } else {
      const files = [file];
      this.documentService.RedigitizeFile(files).then(() => {
        // Check: No code present here
      });
    }
    location.reload();
  }
  */

  confirmAndForceDeleteDocument(file) {
    Swal.fire({
      title: 'Confirm Permanent Delete',
      text: 'Are you sure you want to permanently delete this file?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Delete',
    })
      .then((isConfirm) => {
        if (Object.prototype.hasOwnProperty.call(isConfirm, 'dismiss')) {
          Swal.fire('Cancelled', 'File is safe :) ', 'error');
        } else {
          this.forceDeleteDocument(file);
        }
      })
      .catch(() => {
        Swal.fire('Error', 'Please try again');
      });
  }

  forceDeleteDocument(file) {
    this.documentService
      .forceDeleteDocument(file._id)
      .then(() => {
        Swal.fire({
          icon: 'success',
          title: 'Permanently Deleted',
          showConfirmButton: false,
          timer: 2000,
        }).then(() => {
          this.fetchPaginatedDocumentList(this.itemsPerPage);
        });
      })
      .catch(() => {
        Swal.fire('Failed to Delete Files', 'Please try again');
      });
  }

  confirmAndRestoreDeletedDocument(file) {
    Swal.fire({
      title: 'Confirm Restore',
      text: 'Are you sure you want to Restore this file?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Restore',
    })
      .then((isConfirm) => {
        if (Object.prototype.hasOwnProperty.call(isConfirm, 'dismiss')) {
          Swal.fire('Cancelled', 'File is safe :) ', 'error');
        } else {
          this.restoreDocument(file);
        }
      })
      .catch(() => {
        Swal.fire('Error', 'Please try again');
      });
  }

  restoreDocument(file) {
    this.documentService
      .restoreDocumentByID(file._id)
      .then(() => {
        Swal.fire({
          icon: 'success',
          title: 'Restored',
          showConfirmButton: false,
          timer: 2000,
        }).then(() => {
          this.fetchPaginatedDocumentList(this.itemsPerPage);
        });
      })
      .catch(() => {
        Swal.fire('Failed to Restore Files', 'Please try again');
      });
  }

  confirmAndDeleteDocument(file) {
    Swal.fire({
      title: 'Confirm Delete',
      text: 'Are you sure you want to delete this file?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Delete',
    })
      .then((isConfirm) => {
        if (Object.prototype.hasOwnProperty.call(isConfirm, 'dismiss')) {
          Swal.fire('Cancelled', 'File is safe :) ', 'error');
        } else {
          this.deleteDocument(file._id);
        }
      })
      .catch(() => {
        Swal.fire('Error', 'Please try again');
      });
  }

  deleteDocument(documentId: string) {
    this.documentService
      .deleteDocumentByID(documentId)
      .then(() => {
        Swal.fire({
          icon: 'success',
          title: 'Deleted!',
          showConfirmButton: false,
          timer: 2000,
        }).then(() => {
          this.fetchPaginatedDocumentList(this.itemsPerPage);
        });
      })
      .catch(() => {
        Swal.fire('Failed to Delete Files', 'Please try again');
      });
  }

  documentFilterEventHandler(event: Event) {
    this.filterdata = event;
    if (event['Date']?.length === 2) {
      this.fromDate = event['Date'][0];
      this.toDate = event['Date'][1];
    }
    this.updateSearchCriteria('');
  }

  handleDateFilterSelectEvent(event: Event) {
    if (event['from'] !== undefined) {
      this.fromDate = event['from'];
    }
    if (event['to'] !== undefined) {
      this.toDate = event['to'];
    }
  }

  removeTile(filter, type) {
    if (type == 'Client') {
      this.selectedClientTitles = this.selectedClientTitles.filter(
        (item) => item != filter
      );
    }
    if (type == 'Status') {
      this.selectedStatuses = this.selectedStatuses.filter(
        (item) => item != filter
      );
    }
    if (type == 'Type') {
      this.selectedDocumentTypes = this.selectedDocumentTypes.filter(
        (item) => item != filter
      );
    }
    if (type == 'UploadedBy') {
      this.UploadedBy = '';
    }
    if (type == 'FileName') {
      this.DocumentName = '';
      //this.DocumentNameInput=""
    }
    //this.sendData();
  }

  clearAll() {
    this.selectedClientTitles = [];
    this.selectedStatuses = [];
    this.selectedDocumentTypes = [];
    this.DocumentName = '';
    this.UploadedBy = '';
    //this.DocumentNameInput=""
  }

  showDashboardDocs(parentId: string) {
    const ParentIds = [parentId];
    for (let i = 0; i < ParentIds.length; i++) {
      this.documentService.getDocumentByID(ParentIds[i]).then((response) => {
        this.documentCount = ParentIds.length;
        this.pagedFiles.push(response);
      });
    }
    if (this.pagedFiles) {
      for (let i = 0; i < this.pagedFiles.length; i++) {
        this.pagedFiles[i]['ChildDocStats'] = this.getChildDocumentCount(
          this.pagedFiles[i]
        );
        if (this.isGetDocByPage) {
          this.expand[i] = this.localExpand[i] === 'true';
        } else {
          this.expand[i] = false;
        }
      }
    }
    this.localStorageService.setItem('expand', undefined);
    this.selectedFileIndexes =
      this.pagedFiles !== undefined
        ? new Array(this.pagedFiles.length)
        : undefined;
    this.fileProcessChecker =
      this.pagedFiles !== undefined
        ? new Array(this.pagedFiles.length)
        : undefined;
    if (this.selectedFileIndexes !== undefined)
      this.selectedFileIndexes.fill(false);
    if (this.fileProcessChecker !== undefined)
      this.fileProcessChecker.fill(false);
    this.search = this.localStorageService.getItem('search');
    this.resetDocumentStats();
    this.isGetDocByPage = false;
  }

  async openFile(file: ColumnStyle) {
    try {
      const field = file?.column;
      if (field == 'DocumentName') {
        const pdfDataResponse = await this.documentService.getDocumentPdfbyId(
          file?.data?._id
        );
        const pdfurl = pdfDataResponse.data;
        const pdfWindow = window.open('');
        pdfWindow.document.write(
          `<iframe width='100%' height='100%' src='data:application/pdf;base64,
        ${encodeURI(pdfurl)}
        '></iframe>`
        );
      }
    } catch {
      Swal.fire('Failed', 'Error while opening PDF document', 'error');
    }
  }

  getFileStatusBackgroundColor = (file: ColumnStyle): void => {
    const column = file?.column;
    if (column == 'Status') {
      const statusData = this.allDocumentStatuses[file?.data?.Status];
      if (statusData) {
        return statusData.background;
      }
    }
  };

  getFileStatusColor = (file: ColumnStyle): void => {
    const column = file?.column;
    if (column == 'Status') {
      const statusData = this.allDocumentStatuses[file?.data?.Status];
      if (statusData) {
        return statusData.color;
      }
    }
  };

  getFileClassDeleted = (file: ColumnStyle) => {
    const column = file?.column;
    if (column == 'DocumentName') {
      return file?.data?.isDeleted ? 'deletedFiles' : 'cell-click';
    }
  };

  onActionButtonHideShow = (args: ActionConditionEvent) => {
    switch (args?.action) {
      case ActionEnum.view:
        return (
          args.data.Status != 'Digitization Failed' &&
          args.data.Status != 'In Process' &&
          args.data.Status != 'In Queue' &&
          args.data.Status != 'New'
        );
      case ActionEnum.delete:
        return (
          this.userService.checkValidComponent('delete-documents') &&
          !args.data.isDeleted
        );
      case ActionEnum.restore:
        return (
          this.userService.checkValidComponent('restore-documents') &&
          args.data.isDeleted
        );
      case ActionEnum.forcedelete:
        return (
          this.userService.checkValidComponent('delete-documents') &&
          args.data.isDeleted
        );
      case ActionEnum.download:
        return (
          this.userService.checkValidComponent('download-digitized') &&
          args.data.Status !== 'New' &&
          args.data.Status !== 'In Queue' &&
          args.data.Status !== 'Digitization Failed' &&
          args.data.Status !== 'In Process'
        );
      default:
        return true;
    }
  };
  actionEvent(event: TableActionItem) {
    switch (event.action) {
      case ActionEnum.view: {
        this.viewProcessedDocument(
          'documents/summary',
          event.row._id,
          event.row.DocumentName
        );
        break;
      }
      case ActionEnum.refresh: {
        this.confirmAndRedigitizeDocument(event.row);
        break;
      }
      case ActionEnum.download: {
        this.downloadDigitizedDocument(event.row);
        break;
      }
      case ActionEnum.delete: {
        this.confirmAndDeleteDocument(event.row);
        break;
      }
      case ActionEnum.restore: {
        this.confirmAndRestoreDeletedDocument(event.row);
        break;
      }
      case ActionEnum.forcedelete: {
        this.confirmAndForceDeleteDocument(event.row);
        break;
      }
    }
  }

  selectedRowIndexEvent(event: SelectRowItem) {
    this.selectedFileIndexes = event.selectedRowIndexes;
    this.isDeleteFilesButtonDisabled =
      this.selectedFileIndexes.indexOf(true) === -1;
    this.isSelectAllFiles = event.selectedAllRows;
  }
}
