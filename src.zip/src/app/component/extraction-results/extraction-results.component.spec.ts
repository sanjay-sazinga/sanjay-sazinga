import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtractionResultsComponent } from './extraction-results.component';

describe('ExtractionResultsComponent', () => {
  let component: ExtractionResultsComponent;
  let fixture: ComponentFixture<ExtractionResultsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExtractionResultsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExtractionResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
