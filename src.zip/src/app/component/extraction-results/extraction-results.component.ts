import { CommonModule } from '@angular/common';
import {
  Component,
  ComponentRef,
  Injectable,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatInputModule } from '@angular/material/input';
import { GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Subject, Subscription } from 'rxjs';
import { AngularMaterialModule } from 'src/app/material.module';
import { DocumentService } from 'src/app/services/document.service';

@Component({
  selector: 'app-extraction-results',
  templateUrl: './extraction-results.component.html',
  styleUrls: ['./extraction-results.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,ReactiveFormsModule,AngularMaterialModule,MatExpansionModule,
    MatInputModule]
})
export class ExtractionResultsComponent implements OnInit {
  @Input() editable: Subject<boolean>;

  handleClick() {
    console.log('clicked');
  }

  private gridApi;
  isEditable = null;
  editableSubscription: Subscription;
  table_data;
  allSecondaryTables = {};
  allPinnedRows = {};
  secondaryTableRows = [];
  secondaryTableCols = [];
  currentPrimaryTableRowIndex = null;
  currentPrimaryTableColId = null;
  showPrimaryTable = true;
  showSecondaryTable = false;
  secondaryTableOpened = false;
  showBlockContent = false;
  textKey = null;
  textValue = null;
  enableEdit = false;
  currentRowNode = null;
  previousText = null;
  addColumn = false;
  addRow = false;
  secondaryTableKey = null;
  dockeyRow = {};
  gridContexts = {};
  activeTab = 'extraction-results';
  columnOptions = ['vendor_name', 'vendor_address', 'invoice_no', 'amount'];
  gridOptions: GridOptions = {
    // flex: 1,
    // minHeight: '100%',
    onCellClicked: (e) => this.handleCellClicked(e),
  };
  columnDefs: any = [
    {
      field: 'key',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      flex: 1,
      minWidth: 150,
      rowDrag: true,
      pinned: 'left',
      cellStyle: {
        // 'font-weight': 'bold',
        color: '#ff7300',
        // 'background-color': '#8f8e93',
        // opacity: 0.5,
      },
    },
    {
      field: 'doc key',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      flex: 2,
      minWidth: 200,
    },
    {
      field: 'value',
      editable: (params) => {
        if (this.isEditable) {
          if (params.data.type === 'table') return false;
          return true;
        }
        return false;
      },
      resizable: true,
      minWidth: 150,
      flex: 2,
    },
    {
      field: 'type',
      editable: (params) => {
        return this.isEditable;
      },
      resizable: true,
      minWidth: 150,
      flex: 1,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: ['entity', 'block', 'image', 'table'],
      },
    },
    {
      field: 'actions',
      editable: false,
      resizable: false,
      // cellRenderer: `<div>
      //   <p>Urjit</p>
      //   <p>Desai</p>
      // </div>`,
      cellRenderer: CustomCellRenderer,
      cellRendererParams: {
        gridOptions: this.gridOptions,
      },
    },
    // {
    //   field: 'raw value',
    //   editable: (params) => {
    //     return this.isEditable;
    //   },
    //   resizable: true,
    //   minWidth: 150,
    //   flex: 1,
    // },
  ];
  rowData = [];

  secondaryGridOptions = {
    flex: 1,
    minHeight: '100%',
    onCellClicked: (e) => this.handleCellClicked(e),
    getRowStyle: (params) => {
      if (params.node.rowPinned) {
        return { background: '#f8f8f8', fontWeight: 'bold' };
      }
    },
  };
  ///////////////////////////////////////////////////////////////////

  allTables = {};
  allSubTablesDataMap = new Map();
  data = null;
  categoriesDataMap = new Map();
  ////////////////////////////////////////////////////////////////////

  onGridReady(params: GridReadyEvent, tableId) {
    console.log('ongridready= ', params);
    this.gridApi = params.api;
    // this.gridOptions = params.
    var primaryTableEl: any = document.querySelector(`#${tableId}`);
    // Listen for click events on body
    document.body.addEventListener('click', function (event) {
      if (primaryTableEl.contains(event.target)) {
        console.log('clicked inside');
      } else {
        console.log('clicked outside');
        params.api.stopEditing();
      }
    });
  }
  onGridReady2(params: GridReadyEvent, tableId) {
    console.log('ongridready2= ', params, tableId);
    this.gridApi = params.api;
    this.gridContexts[tableId] = params;
    this.dockeyRow = this.allPinnedRows[tableId];
    console.log('dockeyrow=', this.dockeyRow);

    this.gridApi.setPinnedTopRowData([this.dockeyRow]);
    var secondaryTableEl: any = document.querySelector(`#${tableId}`);
    document.body.addEventListener('click', function (event) {
      if (secondaryTableEl.contains(event.target)) {
        console.log('clicked inside');
      } else {
        console.log('clicked outside');
        params.api.stopEditing();
      }
    });
  }

  addRowClicked(key) {
    console.log('addRowClicked', key);
    let currentGrid = this.gridContexts[key];
    console.log('currentGrid=', currentGrid);
    // this.gridApi=currentGrid.gridApi

    this.addRow = true;
    const newRowNode = {};
    // this.columnDefs.forEach((columnData) => {
    //   newRowNode[columnData['field']] = '';
    // });

    console.log('current grid cols= ', currentGrid.columnApi.getColumns());

    currentGrid.columnApi.getColumns().forEach((columnData) => {
      newRowNode[columnData['field']] = '';
    });

    currentGrid.api.applyTransaction({ add: [newRowNode] });
    const lastRowIndex = currentGrid.api.getLastDisplayedRow();
    // currentGrid.api.getDisplayedRowAtIndex(lastRowIndex).setSelected(true);
    currentGrid.api.ensureIndexVisible(lastRowIndex);
    // setInterval(() => {
    //   if (this.gridApi) {
    //     this.gridApi.getDisplayedRowAtIndex(lastRowIndex).setSelected(false);
    //   }
    // }, 100);
  }

  addColumnClicked() {
    console.log('add column clicked');

    this.addColumn = true;
  }

  onCellValueChanged(params) {
    if (params.oldValue !== params.newValue) {
      console.log('newValue= ', params.newValue);

      var column = params.column.colDef.field;
      params.column.colDef.cellStyle = { color: 'blue' };
      params.api.refreshCells({
        force: true,
        columns: [column],
        rowNodes: [params.node],
      });
    }
  }

  enableTextEdit() {
    this.enableEdit = !this.enableEdit;
    this.previousText = this.textValue;
  }
  cancelEdit() {
    this.enableEdit = false;
    this.textValue = this.previousText;
  }
  saveTextEdit() {
    console.log('data to save after editing= ', this.textValue);
    this.currentRowNode.data.value = this.textValue;
    console.log('current node in savetext edit= ', this.currentRowNode);

    this.gridApi.applyTransaction({ update: [this.currentRowNode.data] });
    this.showBlockContent = false;
    this.showPrimaryTable = true;
    this.enableEdit = false;
  }
  openPrimaryTable() {
    this.activeTab = 'extraction-results';
    this.showSecondaryTable = false;
    this.showPrimaryTable = true;
    this.gridApi.setFocusedCell(
      this.currentPrimaryTableRowIndex,
      this.currentPrimaryTableColId
    );
  }

  openSecondaryTable() {
    // if (this.showPrimaryTable) {
    //   this.showPrimaryTable = false;
    // }
    // this.showSecondaryTable = !this.showSecondaryTable;
    // if (this.showSecondaryTable) {
    //   this.activeTab = 'table';
    // }
    this.activeTab = 'table';
    this.showSecondaryTable = true;
    this.showPrimaryTable = false;
  }

  closeTextWindow() {
    this.showBlockContent = false;
    this.textKey = '';
    this.textValue = '';
    this.showPrimaryTable = true;
    this.enableEdit = false;
  }

  cancelAddColumn(form) {
    this.addColumn = false;
    form.reset();
  }

  addColumnToTable(form) {
    console.log('column form= ', form.value);
    const columnObj = {
      field: form.value.ssotkey,
      editable: true,
      resizable: true,
      flex: 1,
      minWidth: 150,
    };

    if (this.showPrimaryTable) {
      this.columnDefs = [...this.columnDefs, columnObj];
    } else if (this.showSecondaryTable) {
      this.secondaryTableCols = [...this.secondaryTableCols, columnObj];
      const currentPinnedRow = this.allPinnedRows[this.secondaryTableKey];
      currentPinnedRow[form.value.ssotkey] = form.value.columnName;
      this.allPinnedRows[this.secondaryTableKey] = currentPinnedRow;
      // this.allPinnedRows={...this.allPinnedRows, [this.secondaryTableKey]: {

      // } };
    }

    form.reset();
    this.addColumn = false;
  }

  handleCellClicked(e) {
    console.log('cell clicked=', e);
    if (e.column.colId === 'key') return;
    if (e.column.colId === 'value' && e.data.type === 'block') {
      this.showPrimaryTable = false;
      this.showBlockContent = true;
      this.textKey = e.data.key;
      this.textValue = e.data.value;
      // this.textValue = loremipsum;
      const rowIndex = e.rowIndex;
      this.currentRowNode = this.gridApi.getRowNode(rowIndex);
      console.log('currentRowNode= ', this.currentRowNode);
      this.gridApi.applyTransaction({ remove: [this.currentRowNode] });

      // console.log(this.currentRowNode.setDataValue('value', this.textValue));
    }

    if (
      e.column.colId === 'value' &&
      (e.data.type === 'Table' || e.data.type === 'table')
    ) {
      console.log('here');
      this.activeTab = 'table';
      this.showPrimaryTable = false;
      this.currentPrimaryTableRowIndex = e.rowIndex;
      this.currentPrimaryTableColId = e.column.colId;
      this.secondaryTableCols = this.allSecondaryTables[e.data.key]['cols'];
      console.log('secondaryTableCols=', this.secondaryTableCols);
      console.log('dockey row to pin= ', this.dockeyRow);
      this.secondaryTableKey = e.data.key;
      this.dockeyRow = this.allPinnedRows[e.data.key];
      this.secondaryTableRows =
        this.allSecondaryTables[e.data.key]['rows'].slice(1);
      this.showSecondaryTable = true;
      this.secondaryTableOpened = true;
    }
  }

  constructor(private documentService: DocumentService) {
    console.log('editable inside constructor= ', this.editable);
  }

  ngOnInit(): void {
    // get the dummy data from a file.
    // needs to be replaced by actual API call
    console.log('ng on init called');

    const editableSubscription = this.editable.subscribe((value) => {
      console.log('HERE');
      this.isEditable = value;
      console.log('value of isEditable= ', this.isEditable);
    });

    this.table_data = this.documentService.getDummyData();
    console.log('dummy_data=', this.table_data);

    this.getTablesByCategory();
    this.prepareTables();
    // this.table_data.forEach((entry) => {
    //   const key = entry['SSOTKey'];
    //   let value = entry['Value'];
    //   const type = entry['ValueType'];
    //   const rawValue = entry['RawValue'];
    //   const docKey = entry['DocKey'];
    //   // if type is a table then make a new ag-grid table and open in a new tab
    //   if (type === 'table') {
    //     const tableData = entry['Value'];
    //     const columnNames = new Set();
    //     const tableColDefs = [];
    //     const tableRows = [];
    //     const firstRow = {};
    //     tableData.forEach((row) => {
    //       const tableRowData = {};
    //       row.forEach((colData) => {
    //         if (!columnNames.has(colData['ColumnSSOT'])) {
    //           columnNames.add(colData['ColumnSSOT']);
    //           firstRow[colData['ColumnSSOT']] = colData['DocKey'];
    //           // this.dockeyRow[colData['ColumnSSOT']] = colData['DocKey'];
    //           tableColDefs.push({
    //             field: colData['ColumnSSOT'],
    //             resizable: true,
    //             flex: 1,
    //             editable: (params) => {
    //               return this.isEditable;
    //             },
    //           });
    //         }
    //         tableRowData[colData['ColumnSSOT']] = colData['Value'];
    //       });
    //       console.log('dockey row= ', this.dockeyRow);

    //       tableRows.push(tableRowData);
    //     });

    //     console.log('tableColDefs= ', tableColDefs);
    //     console.log('tableRows= ', tableRows);
    //     value = 'Table';
    //     this.allPinnedRows[key] = firstRow;
    //     this.allSecondaryTables[key] = {
    //       rows: [firstRow, ...tableRows],
    //       cols: tableColDefs,
    //     };
    //   }

    //   this.rowData.push({
    //     key: key,
    //     value: value,
    //     type: type,
    //     'raw value': rawValue,
    //     'doc key': docKey,
    //   });
    //   // console.log('allSecondaryTables= ', this.allSecondaryTables);
    // });
  }

  getTablesByCategory() {
    this.data = this.documentService.getDummyData();

    this.data.forEach((entry) => {
      if (entry['ValueType'] != 'table') {
        if ('Category' in entry) {
          if (this.categoriesDataMap.has(entry['Category'])) {
            this.categoriesDataMap.set(entry['Category'], [
              ...this.categoriesDataMap.get(entry['Category']),
              entry,
            ]);
          } else {
            this.categoriesDataMap.set(entry['Category'], [entry]);
          }
        }
      } else {
        this.allSubTablesDataMap.set(entry['SSOTKey'], entry);
      }
    });

    console.log('categoriesDataMap= ', this.categoriesDataMap);
    console.log('allsubtablesmap= ', this.allSubTablesDataMap);
  }

  prepareTables() {
    this.categoriesDataMap.forEach((value, key) => {
      console.log('key=', key);
      console.log('value=', value);

      const rows = [];
      value.forEach((entry) => {
        rows.push({
          key: entry['SSOTKey'],
          value: entry['Value'],
          type: entry['ValueType'],
          'doc key': entry['DocKey'],
        });
      });
      this.allTables[key] = {
        rows: rows,
        cols: [...this.columnDefs],
      };
      // this.allTables[key]['rows'] = rows;
      // this.allTables[key]['cols'] = [...this.columnDefs];
    });

    // preapring ag grid for subtables
    this.allSubTablesDataMap.forEach((entry, key) => {
      let value = entry['Value'];
      const type = entry['ValueType'];
      const rawValue = entry['RawValue'];
      const docKey = entry['DocKey'];
      const tableData = entry['Value'];
      const columnNames = new Set();
      const tableColDefs = [];
      const tableRows = [];
      const firstRow = {};
      tableColDefs.push({
        headerName: 'SSOT Key',
        valueGetter: (params) => {
          if (params.node.rowPinned) {
            return 'Doc Key';
          }
          return params.node.rowIndex + 1;
        },
      });
      tableData.forEach((row) => {
        const tableRowData = {};
        row.forEach((colData) => {
          if (!columnNames.has(colData['ColumnSSOT'])) {
            columnNames.add(colData['ColumnSSOT']);
            firstRow[colData['ColumnSSOT']] = colData['DocKey'];
            // this.dockeyRow[colData['ColumnSSOT']] = colData['DocKey'];

            tableColDefs.push({
              field: colData['ColumnSSOT'],
              resizable: true,
              flex: 1,
              editable: (params) => {
                return this.isEditable;
              },
              headerComponent: CustomHeader,
            });
          }
          tableRowData[colData['ColumnSSOT']] = colData['Value'];
        });
        console.log('dockey row= ', this.dockeyRow);

        tableRows.push(tableRowData);
      });

      console.log('tableColDefs= ', tableColDefs);
      console.log('tableRows= ', tableRows);
      value = 'Table';
      this.allPinnedRows[key] = firstRow;
      this.allSecondaryTables[key] = {
        rows: tableRows,
        cols: tableColDefs,
      };
    });

    console.log('prepared ag grid main table= ', this.allTables);
    console.log('prepared ag grid subtables= ', this.allSecondaryTables);
    console.log('all pinned rows= ', this.allPinnedRows);
  }
}

class CustomCellRenderer {
  // init method gets the details of the cell to be renderer

  eGui = null;
  init(params) {
    this.eGui = document.createElement('span');
    this.eGui.innerHTML = `
    <div>
    <button class='addRow'>
    <i class="feather icon-plus"></i>
    </button>
    <button class="deleteRow">
    <i class="feather icon-trash"></i>
    </button>
    </div>
    `;

    const addRowEl = this.eGui.querySelector('.addRow');
    addRowEl.addEventListener('click', () => {
      const selectedRow = params.api.getFocusedCell();
      console.log(' getFocusedCell selected row=', selectedRow);
      const index = selectedRow.rowIndex + 1;
      params.gridOptions.rowData.splice(index, 0, {});
      params.api.setRowData(params.gridOptions.rowData);
    });

    const deleteRowEl = this.eGui.querySelector('.deleteRow');
    deleteRowEl.addEventListener('click', () => {
      const selectedRow = params.api.getFocusedCell();
      console.log(' getFocusedCell selected row=', selectedRow);

      const id = selectedRow.rowIndex;
      console.log('before delete= ', params.gridOptions.rowData);
      params.gridOptions.rowData.splice(id, 1);
      params.api.setRowData(params.gridOptions.rowData);
    });
  }

  getGui() {
    return this.eGui;
  }

  refresh(params) {
    return false;
  }
}
@Injectable()
class CustomHeader {
  // @ViewChild(ExtractionResultsComponent, { static: false })
  // targetComponentRef: ComponentRef<ExtractionResultsComponent>;
  eGui = null;
  init(params) {
    this.eGui = document.createElement('span');
    this.eGui.innerHTML = `
    <div>
    <span>${params.displayName}</span>
    <button class='addColumn'>
    <i class="feather icon-plus"></i>
    </button>
    <button class="deleteColumn">
    <i class="feather icon-trash"></i>
    </button>
    <div>
     <input type="text"/>
    </div>
    </div>
    `;

    const addColumnEl = this.eGui.querySelector('.addColumn');
    addColumnEl.addEventListener('click', () => {
      console.log('params indide column header= ', params);
      const currentColId = params.column.colId;
      console.log('current column ID= ', currentColId);

      const currentCols = params.api.getColumnDefs();
      console.log('current cols= ', currentCols);
      let index;

      for (let i = 0; i < currentCols.length; i++) {
        if (currentCols[i]['colId'] === currentColId) {
          index = i;
          break;
        }
      }

      // const extractionObj = new ExtractionResultsComponent();
      // this.targetComponentRef.instance.addColumnClicked();
      const newColumn = {
        field: 'dummy column',
        editable: true,
        resizable: true,
        flex: 1,
        minWidth: 150,
        headerComponent: CustomHeader,
      };

      currentCols.splice(index + 1, 0, newColumn);
      params.api.setColumnDefs(currentCols);
    });

    const deleteColumnEl = this.eGui.querySelector('.deleteColumn');
    deleteColumnEl.addEventListener('click', () => {
      const currentColId = params.column.colId;
      console.log('current column ID= ', currentColId);

      const currentCols = params.api.getColumnDefs();
      console.log('current cols= ', currentCols);
      let index;

      for (let i = 0; i < currentCols.length; i++) {
        if (currentCols[i]['colId'] === currentColId) {
          index = i;
          break;
        }
      }

      currentCols.splice(index, 1);
      params.api.setColumnDefs(currentCols);
    });
  }

  getGui() {
    return this.eGui;
  }

  refresh(params) {
    return false;
  }
}
