import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
//import { IOption } from "ng-select";
import { DocumentService } from '../../services/document.service';
import { LoaderService } from '../../services/loader.service';
import { FormControl, FormsModule } from '@angular/forms';
import { ListingHompageDataService } from '../../services/listinghompagedata.service';
import { FileSaverService } from 'ngx-filesaver';
import { takeUntil, distinctUntilChanged, debounceTime } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { MatSortModule } from '@angular/material/sort';
import { Sort } from '@angular/material/sort';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
//import { MAT_DATE_FORMATS } from '@angular/material/core';
//import { MAT_DATE_FORMATS } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import {
  IDropdownSettings,
  NgMultiSelectDropDownModule
} from 'ng-multiselect-dropdown';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { HomepageGraphsComponent } from './homepage-graphs/homepage-graphs.component';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material/core';
import { Subject, Subscription } from 'rxjs';
import { stringToKeyValue } from '@angular/flex-layout/extended/style/style-transforms';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { DatefilterComponent } from 'src/app/shared/components/datefilter/datefilter.component';
import { NGX_ECHARTS_CONFIG, NgxEchartsModule } from 'ngx-echarts';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
//import { templateJitUrl } from '@angular/compiler';
//import { MatProgressBarModule } from '@angular/material/progress-bar';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL'
  },
  display: {
    dateInput: 'MMM DD YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};
@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    {
      provide: NGX_ECHARTS_CONFIG,
      useFactory: () => ({ echarts: () => import('echarts') })
    }
  ],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    NgMultiSelectDropDownModule,
    HomepageGraphsComponent,
    DatefilterComponent,
    HomepageGraphsComponent,
    NgxEchartsModule,
    NgbPaginationModule,
  ]
})
export class HomePageComponent implements OnInit {
  configs: any = {};
  fromDate = new Date();
  toDate = new Date();

  basicDisabledFilter = {
    value: '-1',
    label: 'Select clients below . . .',
    disabled: true
  };
  // clientFilterData: Array<IOption> = [];
  // date1=new Date();
  // date2 =new Date();
  graphclients: any[] = [];
  selectedClients: any[] = [];
  statusTypes: any[] = [];
  dashboardSummary: any = {};
  itemsInPage: number = 10;
  alldata: any = {};
  StatusArray = [];
  dashboardData: any = {};
  RealdashboardData: any = {};
  openTable: string = '';
  searchInProcess: boolean = false;
  graphData: any = {};
  statusColor = [];
  datafound: boolean = true;
  totalDocuments: number = 0;
  listingfilter: any = {};
  statusColours: any = [];
  isSortedCount: any = false;
  isSortedDocument: any = false;
  openDetailTable: boolean = false;
  currentStatus: string = '';
  pageNumber: number = 1;
  //pageNumbertable1: number=;
  clientTypeData: any = {};
  detailTable: any = [];
  documentType: string = '';
  clientdropdownList = [];
  selectedDropdown: any[] = [];
  selectedStatusDropdown: any[] = [];
  table2: any = {};
  table1: any = {};
  parentfilterdata: any[] = [];
  allClients: any[] = [];
  currdate = new Date();
  statusDropdown: any[] = [];

  statusDropdownList = [];
  currentStatusDropdown: string = 'Filter Status';
  clientdropdownSettings: IDropdownSettings = {};
  statusdropdownSettings: IDropdownSettings = {};
  sortedCollection: any[];
  toUnsubscribe = new Array<Subscription>();
  citiesTypeahead = new EventEmitter<string>();

  constructor(
    private documentService: DocumentService,
    private ListinghompagedataService: ListingHompageDataService,
    private fileSaver: FileSaverService,
    private loaderService: LoaderService,
    private router: Router,
    public userService: UserService
  ) {}

  // showTable(status) {
  //   this.openDetailTable = false;
  //   this.detailTable = [];
  //   this.openTable = status;
  // }
  timedifference(DateUploaded) {
    // console.log("Uploaded DAte")
    // console.log(typeof DateUploaded)
    // console.log(typeof this.currdate)
    let newdate = new Date(DateUploaded);
    return this.currdate.getTime() - newdate.getTime();
  }

  // showDocsFilters(status, client, type) {
  //   this.detailTable = [];
  //   this.documentType = type;
  //   this.clientTypeData[status][client][type].forEach((doc) => {
  //     this.detailTable.push(doc)
  //   });
  //   this.openDetailTable = true;
  // };

  checkDate() {
    // console.log("dates   ss s s s ")
    // console.log(typeof this.fromDate)
    //  console.log(this.fromDate.value['_d'])
    if (this.fromDate && this.fromDate > this.toDate) {
      // Swal.fire({
      //   title: 'Date range Error!',
      //   text: 'Start Date should be lower than End Date.',
      //   type: 'error',
      //   timer: 2500,
      //   showConfirmButton: false
      // });
      return false;
    } else if (!this.toDate || !this.fromDate) {
      // Swal.fire({
      //   title: 'Date Error!',
      //   text: 'Please Enter Valid Dates.',
      //   type: 'error',
      //   timer: 2500,
      //   showConfirmButton: false
      // });
      return false;
    }
    return true;
  }

  search() {
    if (this.checkDate()) {
      //console.log("chal gya")
      localStorage.toDate = new Date(this.toDate);
      localStorage.fromDate = new Date(this.fromDate);
      // console.log(this.selectedDropdown);
      this.selectedClients = this.selectedDropdown.map(
        (item) => item['item_text']
      );

      //console.log("mkmkmkkmkmkm");
      //console.log(this.selectedClients);

      this.applyFilters();
    }
  }

  // ShowMoreResults() {
  //   localStorage.status = JSON.stringify([this.openTable]);
  //   localStorage.clients = JSON.stringify(this.selectedClients);
  //   localStorage.toDate = new Date(this.toDate);
  //   localStorage.fromDate = new Date(this.fromDate);
  //   localStorage.type = JSON.stringify([this.documentType]);
  //   this.router.navigate(['documents']);
  // }

  downloadReport() {
    if (this.checkDate() || true) {
      this.loaderService.show();
      let fd = this.fromDate;
      let td = this.toDate;
      //  console.log("Download Date")
      //  console.log(fd)
      // console.log(td)
      this.documentService
        .downloadReport({
          startDate: new Date(
            fd.getFullYear(),
            fd.getMonth(),
            fd.getDate(),
            0,
            0,
            0
          ),
          endDate: td ? td : new Date(),
          clients: this.selectedClients
        })
        .then((extractData) => {
          // console.log("Function report called")
          this.loaderService.hide();
          this.fileSaver.save(
            extractData,
            'Report_' +
              fd.getFullYear() +
              '-' +
              (fd.getMonth() + 1) +
              '-' +
              fd.getDate() +
              '_'
          );
          //td.getFullYear() + "-" + (td.getMonth() + 1) + "-" + td.getDate() + ".xlsx");
        });
    }
  }
  tabletype() {
    if (
      this.currentStatus == 'Digitization Failed' ||
      this.currentStatus == 'In Queue'
    ) {
      return false;
    } else {
      return true;
    }
  }
  isInQueue() {
    if (this.currentStatus == 'In Queue') {
      return true;
    } else {
      return false;
    }
  }
  setcurrentStatus(status) {
    this.currentStatus = status;
    this.currentStatusDropdown = status;
    this.pageNumber = 1;
    this.selectedStatusDropdown = [];
    this.statusDropdownList.forEach(function (statusDropdown) {
      if (status == statusDropdown.name) {
        //  console.log("qwertyuioo")
        let statusObject = { id: statusDropdown.id, name: status };
        this.selectedStatusDropdown.push(statusObject);
      }
    });
  }
  statuspercentage(statusCount) {
    let totalDocuments = 0;
    for (let i = 0; i < this.statusTypes.length; i++) {
      totalDocuments =
        totalDocuments +
        this.dashboardSummary[this.statusTypes[i]].documentCount;
    }
    let percent = Math.ceil((statusCount / totalDocuments) * 100);

    let slot = Math.ceil(percent / 10) * 10;

    let progressbarClass = 'filter-line-' + slot;
    return progressbarClass;
  }
  eventHandler1(event: Object) {
    if (event['from'] != undefined) {
      this.fromDate = event['from'];
    }

    if (event['to'] != undefined) {
      this.toDate = event['to'];
    }
  }

  async applyFilters() {
    //  console.log("Test date ")
    //  console.log(this.fromDate)

    let date1 = this.fromDate;
    let date2 = this.toDate;
    if (date1 == undefined) {
      date1 = this.fromDate;
      date2 = this.toDate;
    }
    this.graphclients = this.selectedClients;

    //   console.log(date1)
    this.dashboardSummary = {};
    if (this.currentStatusDropdown != 'Filter Status') {
      this.currentStatus = this.currentStatusDropdown;
    } else {
      this.currentStatus = '';
    }

    //console.log(this.selectedClients);
    // console.log(this.clientTypeData)
    this.statusTypes.forEach((item) => {
      this.dashboardData[item] = {};
      this.clientTypeData[item] = {};
      this.RealdashboardData[item] = {};
      this.table2[item] = [];
      // this.table1[item]=[];
      this.alldata[item] = [];
      this.dashboardSummary[item] = {
        documentCount: 0
      };
    });
    this.searchInProcess = true;
    //   console.log("Newest date check")
    localStorage.fromDate = date1;
    localStorage.toDate = date2;
    //   console.log(date1)
    //   console.log(date2)

    // console.log("jhdjqwdui2dhhudhduqd");

    //console.log(this.RealdashboardData);

    await this.documentService
      .getAllDocumentsFilters({
        startDate: new Date(
          date1.getFullYear(),
          date1.getMonth(),
          date1.getDate(),
          0,
          0,
          0
        ),
        endDate: date2 ? date2 : new Date(),
        clients: this.selectedClients
      })
      .then((extractDetails) => {
        //    console.log(extractDetails)
        if (extractDetails.count == 0) {
          this.datafound = false;
        } else {
          this.datafound = true;
        }

        //    console.log(this.datafound)
        this.searchInProcess = false;
        //console.log(extractDetails['docs']['ChildDocDetails'])
        // console.log(extractDetails['docs'][1]['SuperParentId']== undefined)
        this.graphData = extractDetails;
        let DocumentsType = this.configs.documentTypes;
        //console.log(extractDetails)
        extractDetails['docs'].forEach((document) => {
          //console.log("madadkdwdiwdid")

          // console.log(this.selectedClients)
          // console.log(document.ClientTitle)

          //    console.log(document)

          let documentChildDocDetails = document.ChildDocDetails;
          //  console.log( documentChildDocDetails);

          let documentStatus = document.Status;
          // console.log(documentStatus);
          let documentClient = document.ClientTitle;
          let documentType = document.Type;

          if (
            documentStatus == 'Digitization Failed' ||
            documentStatus == 'In Queue'
          ) {
            this.table2[documentStatus].push(document);
          }

          if (documentChildDocDetails == undefined) {
            return;
          }

          //this.alldata[documentStatus].push(document);

          if (DocumentsType[documentType] === false) {
            document.Type = 'Others';
          }

          //console.log(documentChildDocDetails)
          //console.log(document)
          if (!(documentStatus in this.dashboardData)) {
            this.dashboardData[documentStatus] = {};
            this.clientTypeData[documentStatus] = {};
            this.dashboardSummary[documentStatus] = {
              documentCount: 0
            };
          }
          if (!this.dashboardData[documentStatus][documentClient]) {
            this.dashboardData[documentStatus][documentClient] = {};
            this.clientTypeData[documentStatus][documentClient] = {};
          }
          if (
            !this.dashboardData[documentStatus][documentClient][documentType]
          ) {
            this.dashboardData[documentStatus][documentClient][documentType] = {
              documentCount: 0,
              processedPages: 0
            };
            this.clientTypeData[documentStatus][documentClient][documentType] =
              [];
          }
          //console.log(documentChildDocDetails)
          Object.keys(documentChildDocDetails).forEach((key) => {
            Object.keys(documentChildDocDetails[key]).forEach((key1) => {
              //let keycopy: any;
              Object.keys(documentChildDocDetails[key][key1]).forEach(
                (key2) => {
                  // console.log(documentChildDocDetails[key][key1][key2])
                  // console.log(key)
                  let newkey = key2;
                  if (key == 'forms') {
                    // console.log("keys")
                    // console.log(key1)
                    // console.log(key2)
                    if (key1 != key2) {
                      newkey = key1 + ' ' + key2;
                    }
                  }
                  if (!(documentStatus in this.RealdashboardData)) {
                    this.RealdashboardData[documentStatus] = {};
                  }
                  if (!this.RealdashboardData[documentStatus][documentClient]) {
                    this.RealdashboardData[documentStatus][documentClient] = {};
                  }
                  if (
                    !this.RealdashboardData[documentStatus][documentClient][
                      newkey
                    ]
                  ) {
                    this.RealdashboardData[documentStatus][documentClient][
                      newkey
                    ] = {
                      Count: 0,
                      ParentId: []
                    };
                  }

                  this.RealdashboardData[documentStatus][documentClient][
                    newkey
                  ].Count += documentChildDocDetails[key][key1][key2]['count'];
                  this.RealdashboardData[documentStatus][documentClient][
                    newkey
                  ].ParentId.push(document._id);
                }
              );
            });
          });

          // //this.RealdashboardData[documentStatus][documentClient]=[]
          // console.log(this.RealdashboardData)

          this.dashboardData[documentStatus][documentClient][
            documentType
          ].documentCount += 1;
          if (document.Pages) {
            this.dashboardData[documentStatus][documentClient][
              documentType
            ].processedPages += document.Pages;
            this.dashboardSummary[documentStatus].processedPages +=
              document.Pages;
          }
          if (
            this.clientTypeData[documentStatus][documentClient][documentType]
              .length < 5
          ) {
            this.clientTypeData[documentStatus][documentClient][
              documentType
            ].push(document);
          }
        });
        //    console.log(extractDetails)
        extractDetails['statistics'].forEach((docs) => {
          this.dashboardSummary[docs['_id']] = { documentCount: docs['count'] };
        });
      })
      .catch((err) => {
        console.error(err);
      });

    //    console.log("Table data to be shown")
    //console.log(this.alldata);
    //console.log(this.table2);
    // console.log()

    // console.log(this.RealdashboardData);
    // console.log(this.table2);
    this.createTable1(this.RealdashboardData);
    //this.totalDocuments=this.dashboardSummary[this.statusTypes[0]].documentCount+this.dashboardSummary[this.statusTypes[1]].documentCount+this.dashboardSummary[this.statusTypes[2]].documentCount;
    // this.dashboardSummary.forEach((statuscount)=>
    // {
    //   console.log(statuscount)
    //  // this.totalDocuments=this.totalDocuments+statuscount.documentCount
    // })
    //  for(let i=0;i<7;i++)
    //  {
    // //   console.log("bolololololol")
    //     console.log(this.dashboardSummary["Approved"])
    //    console.log(this.dashboardSummary[this.statusTypes[i]])
    // //   console.log(this.dashboardSummary)
    //    console.log(this.statusTypes[i])
    // //   this.totalDocuments=this.totalDocuments+this.dashboardSummary[this.statusTypes[i]].documentCount;
    // }
  }
  createTable1(data) {
    // console.log(data)
    Object.keys(data).forEach((status) => {
      this.table1[status] = [];
    });

    Object.keys(data).forEach((status) => {
      //console.log(status)
      let statusdata = data[status];
      //console.log(statusdata)
      Object.keys(statusdata).forEach((client) => {
        Object.keys(statusdata[client]).forEach((document) => {
          let TableDetails = {
            Document: document,
            Client: client,
            Count: statusdata[client][document]['Count'],
            ParentId: statusdata[client][document]['ParentId']
          };
          this.table1[status].push(TableDetails);

          //console.log(statusdata[client][documemt]['Count'])
        });
      });
      //let keycopy: any;
    });
    // console.log("Table 1 to be printed")
    // console.log(this.table1)
  }
  sortTablebyCount(status) {
    if (!this.isSortedCount) {
      // console.log("Sorting")
      this.table1[status].sort((a, b) => a.Count - b.Count);
      this.isSortedCount = true;
    } else {
      this.table1[status].sort((a, b) => a.Count - b.Count).reverse();
      this.isSortedCount = false;
    }
  }
  capitalize(input) {
    var words = input.split(' ');
    var CapitalizedWords = [];
    words.forEach((element) => {
      CapitalizedWords.push(
        element[0].toUpperCase() + element.slice(1, element.length)
      );
    });
    return CapitalizedWords.join(' ');
  }
  sortTablebyDocumentName(status) {
    if (!this.isSortedDocument) {
      //console.log("Sorting")
      this.table1[status].sort((a, b) => a.Document.localeCompare(b.Document));
      this.isSortedDocument = true;
    } else {
      this.table1[status]
        .sort((a, b) => a.Document.localeCompare(b.Document))
        .reverse();
      this.isSortedDocument = false;
    }
  }
  ListingPage(Type, Client, ParentId) {
    //  console.log(ParentId)
    Type = this.capitalize(Type);
    // console.log(Type)
    this.listingfilter['fromDate'] = this.fromDate;
    this.listingfilter['toDate'] = this.toDate;
    this.listingfilter['Type'] = Type;
    this.listingfilter['Client'] = Client;
    this.listingfilter['Status'] = this.currentStatusDropdown;
    this.listingfilter['ParentId'] = ParentId;
    // console.log(this.listingfilter)
    this.ListinghompagedataService.updateFilters(this.listingfilter);
    this.router.navigateByUrl('/documents');
  }
  IntializeDropdowns() {}

  ngOnInit(): void {
    this.documentService.getStatusList().then((res) => {
      for (
        var indexDocStatus = 0;
        indexDocStatus < res.listofStatus.length;
        indexDocStatus++
      ) {
        if (!this.StatusArray[res.listofStatus[indexDocStatus].name]) {
          //console.log(res.listofStatus[indexDocStatus].name)
          //console.log(res.listofStatus[indexDocStatus].color)

          this.StatusArray[res.listofStatus[indexDocStatus].name] =
            res.listofStatus[indexDocStatus].statuscolor;
          // console.log(this.StatusArray)
        }

        // this.AllStatus.push( res.listofStatus[indexDocStatus].name)
      }
    });

    //var y = document.getElementsByClassName('pink');
    // var aNode = y[0];
    // aNode.style.width=

    //document.getElementById(".pink").style.width = "300px";
    //document.querySelector<HTMLElement>("filter-line").style.width="80px";

    //console.log("status colors coming from config")
    //console.log(this.StatusArray)

    this.documentService
      .getAllClients()
      .then((response) => {
        //  console.log("Clients of User")
        //   console.log(response)

        // this.clientFilterData = [this.basicDisabledFilter];

        this.selectedDropdown = [];
        response.forEach((item) => {
          this.allClients.push(item.name);

          // this.clientFilterData.push({
          //   label: item.name,
          //   value: item.name
          // });
        });
      })
      .then(() => {
        this.documentService.getConfigs().then((response) => {
          //  console.log("all clients")
          //   console.log(response)
          if (response) this.statusTypes = Object.keys(response.status);

          this.statusDropdown = Object.keys(response.status);
          this.statusDropdown.push('Filter Status');

          this.configs = response;
          // this.currentStatus=this.statusTypes[0];
          //this.allClients=Object.keys(response.clients)
          // console.log("Status Types of status")

          //  console.log(this.statusTypes);
          // console.log("kllklkobjbjbjb");

          // this.clientdropdownSettings = {
          //   idField: 'item_id',
          //   textField: 'item_text',
          //   allowSearchFilter: true
          // };
          this.clientdropdownList = [{ item_id: 0, item_text: 'abc' }];
          this.statusDropdownList = [{ id: 0, name: 'abc' }];
          for (let i = 0; i < this.statusTypes.length; i++) {
            this.statusDropdownList.push({
              id: i + 1,
              name: this.statusTypes[i]
            });
            this.statusColor.push(this.StatusArray[this.statusTypes[i]]);
          }

          for (let i = 0; i < this.allClients.length; i++) {
            this.clientdropdownList.push({
              item_id: i + 1,
              item_text: this.allClients[i]
            });
          }
          this.clientdropdownList.shift();
          this.statusDropdownList.shift();
          // console.log(this.statusDropdownList)
          this.clientdropdownSettings = {
            idField: 'item_id',
            textField: 'item_text',
            allowSearchFilter: true,
            itemsShowLimit: 0
          };
          this.statusdropdownSettings = {
            idField: 'id',
            textField: 'name',
            allowSearchFilter: true,
            itemsShowLimit: 0,
            limitSelection: 1
          };
          //  console.log("Local storage date")
          //  console.log(localStorage.fromDate)

          if (localStorage.fromDate && localStorage.toDate) {
            //  console.log("date from local ")

            this.fromDate = new Date(localStorage.fromDate);
            this.toDate = new Date(localStorage.toDate);
          } else {
            let today = new Date();
            this.fromDate = new Date(
              today.getTime() - 180 * 24 * 60 * 60 * 1000
            );
          }

          // console.log(Object.keys(response.clients))
          this.applyFilters();
        });
      });
  }

  removeClientTile(item: any) {
    //console.log('onItemSelect', item);
    //this.selectedDropdown = this.selectedDropdown.filter((item) => item.id !== item["item_id"]);

    //   console.log(this.selectedDropdown);
    let temp = this.selectedDropdown;
    temp.splice(
      temp.findIndex((a) => a['item_id'] === item['item_id']),
      1
    );
    //this.selectedDropdown.splice( this.selectedDropdown.findIndex(a => a["item_id"] === item["item_id"]) , 1);
    // console.log()
    this.selectedDropdown = [];
    for (let i = 0; i < temp.length; i++) {
      this.selectedDropdown.push(temp[i]);
    }

    //this.onItemDeSelect(item)
    //  console.log(this.selectedDropdown);
  }
  removeStatusTile() {
    this.currentStatusDropdown = 'Filter Status';
    this.selectedStatusDropdown = [];
    //console.log(this.selectedDropdown);
  }
  clearAll() {
    this.currentStatusDropdown = 'Filter Status';
    this.selectedDropdown = [];
    this.selectedStatusDropdown = [];
    this.search();
  }

  onItemSelect(item: any) {
    // console.log('onItemSelect', item);
    if ('name' in item) {
      this.currentStatusDropdown = item['name'];
    }
    //  console.log(this.selectedDropdown);
  }
  onItemDeSelect(item: any) {
    //  console.log('onItemDeSelect', item);
    //  console.log(this.selectedDropdown);
  }
  onSelectAll(items: any) {
    //  console.log('onSelectAll', items);
    //  console.log(this.selectedDropdown);
  }
  onUnSelectAll() {
    //   console.log('onUnSelectAll fires');
  }
}
