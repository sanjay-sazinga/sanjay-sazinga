import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomepageGraphsComponent } from './homepage-graphs.component';

describe('HomepageGraphsComponent', () => {
  let component: HomepageGraphsComponent;
  let fixture: ComponentFixture<HomepageGraphsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomepageGraphsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HomepageGraphsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
