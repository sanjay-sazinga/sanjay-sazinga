import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbAccordion } from '@ng-bootstrap/ng-bootstrap';
import { DocumentService } from "../../../services/document.service";
import { Router } from '@angular/router';
import { FileSaverService } from 'ngx-filesaver';
import { LoaderService } from '../../../services/loader.service';
import { IDropdownSettings, } from 'ng-multiselect-dropdown';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { NgxEchartsModule } from 'ngx-echarts';
@Component({
  selector: 'app-homepage-graphs',
  templateUrl: './homepage-graphs.component.html',
  styleUrls: ['./homepage-graphs.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,NgxSkeletonLoaderModule,NgxEchartsModule]
})
export class HomepageGraphsComponent implements OnInit,OnChanges {
  graph2specs: any={};
  graph1specs: any={};
  @Input() extractDetails: any;


  //  @Input() from:any;
  //  @Input() to:any;
  //  @Input() selectedClients:any;


  fetchedClients: any[] = [];
  graph1Rendered: boolean=false;
  graph2Rendered: boolean=false;
  graph3Rendered: boolean=false;
  //graph2Rendered: boolean=false;
  //graph3Rendered: boolean=false;

  docdetails: any[]=[];
  ClientCount :any[] =[];
 @Input() statusTypes: any[]=[];
 @Input() colours: any[]=[];
  graph3specs: any={};
  filterdata: any[]=[];
  filterClients : any[]=[];
  graph3Interval: string="Daily";
  graphIntervalList=[];
  selectedInterval=[];
  graphIntervaldropdownSettings:IDropdownSettings={};




  constructor(private documentService: DocumentService, private fileSaver: FileSaverService, private loaderService: LoaderService,
    private router: Router) {

  }
  ngOnChanges(changes: SimpleChanges)
  {

    this.ngOnInit();

  }

  ngOnInit() {
    this.graphIntervalList=[
      {id:0,name:"Daily"},
      {id:1,name:"Weekly"},
      {id:2,name:"Monthly"}
     ]
     this.graphIntervaldropdownSettings = {
      idField: 'id',
       textField: 'name',


       limitSelection: 1

     };
     this.selectedInterval.push({id:0,name:"Daily"});



  this.data();


  this.graph1();
  this.graph2();
  this.graph3();







  }
  onItemSelect(item: any) {
   // console.log('onItemSelect', item);
    if('name' in item)
    {
      this.graph3Interval=item["name"];
    }
    this.graph3();
   // console.log(this.graph3Interval);

}
onItemDeSelect(item: any) {
  //  console.log('onItemDeSelect', item);
    //console.log(this.selectedDropdown);
}
onSelectAll(items: any) {
//    console.log('onSelectAll', items);
 //   console.log(this.selectedDropdown);
}
onUnSelectAll() {
  //  console.log('onUnSelectAll fires');
}



  graph1()
  {
  //  console.log("Status colors")
   // console.log(this.colours)
    this.graph1Rendered=false
    let clientStatusCount: any[]=[];
    let xaxis: any[]=[];
    let yaxis: any[]=[];
    xaxis = this.ClientCount.map(a => a['client']);
    xaxis.forEach((item) =>
   {

    let status: any={};
    for(let i=0; i< this.statusTypes.length; i++)
    {
      status[this.statusTypes[i]]=0;


    }
    clientStatusCount[item]=status;



   });

    this.docdetails?.forEach((document) => {

      let documentStatus = document.Status;
      let documentClient = document.ClientTitle;
      clientStatusCount[documentClient][documentStatus]+=1;



    });

   // console.log(clientStatusCount);

    let graph1data: any[]=[];
    for(let i=0; i< this.statusTypes.length; i++)
    {
      let statusspecs :any={};
      statusspecs['name']=this.statusTypes[i];
      statusspecs['type']='bar';
      statusspecs['stack']='status';
      statusspecs['barWidth']='20%';
      statusspecs['emphasis']= { focus: 'series' };
      let statuscount: any[]=[];

    for(let j=0;j<xaxis.length;j++)
      {
        statuscount.push(clientStatusCount[xaxis[j]][this.statusTypes[i]]);

      }
      statusspecs['data']=statuscount;
      graph1data.push(statusspecs);



    }
   // console.log(graph1data);


    this.graph1specs = {



      title: {
        text: 'Client Status',
        textStyle: {
          fontSize: 18,
          fontFamily: 'Poppins',
          color: '#000',
          fontWeight: '500'

        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        type: 'scroll',

        right: 10,
        top: 20,
        bottom: 20,


      },
      color:  this.colours,

      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        roundEdges: true,
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: xaxis,
          axisLabel: {
            interval: 0,
            rotate: 25 //If the label names are too long you can manage this by rotating the label.
          }
        }
      ],
      yAxis: {
        type: 'value',
        name: 'Count',
        nameLocation: 'middle',
        nameTextStyle:{
          align: 'left',
          fontSize: 14.3


        },
        nameGap:40
      },
      series: graph1data
    };
    this.graph1Rendered=true;



  }
  graph2()
  {

    this.graph2Rendered=false;

    let xaxis: any[]=[];
    let yaxis: any[]=[];

      xaxis = this.ClientCount.map(a => a['client']);
      yaxis = this.ClientCount.map(a => a['count']);



   this.graph2specs = {
    barPadding:1,

    title: {
      text: 'Clients',
      textStyle: {
        fontSize: 18,
        fontFamily: 'Poppins',
        color: '#000',
        fontWeight: '500'

      }
    },
     xAxis: {
       type: 'category',
       data: xaxis,
       axisLabel: {
        interval: 0,
        rotate: 24 //If the label names are too long you can manage this by rotating the label.
      }
     },
     yAxis: {
      type: 'value',
      name: 'Count',
      nameLocation: 'middle',
      nameTextStyle:{
        align: 'left',
        fontSize: 15


      },
      nameGap:45
    },
     series: [
       {
         data: yaxis,
         type: 'bar',
         barWidth: '20%',

         showBackground: true,
         backgroundStyle: {
           color: 'rgba(180, 180, 180, 0.2)'
         }
       }
     ]
   };
   this.graph2Rendered=true;

  }
  graph3()
  {



   // console.log(this.graph3Interval)
    let interval=this.graph3Interval;
    //console.log(interval)
    let xaxis: any[]=[];
    let yaxis: any[]=[];
    let daily: any={};
    let monthly: any={};
    let weekly: any={};
    let clientline: any ={};
    let clients: any[]=[];
    clients= this.ClientCount.map(a => a['client']);
    let revdocdetails= this.docdetails?.reverse();


   revdocdetails?.forEach((item)=>
   {

    let dateUploaded=new Date(item["DateUploaded"])
    //console.log(typeof dateUploaded )
    //console.log(dateUploaded);
    if(dateUploaded==undefined)
    {
    //  console.log("nhi")
    //  console.log(item)
    }

    daily[item["DateUploaded"].slice(0,10)]=0;
    monthly[dateUploaded.toLocaleString('default', { month: 'short' })]=0;
    dateUploaded.setDate(dateUploaded.getDate() - (dateUploaded.getDay() + 6) % 7);
    weekly[dateUploaded.toString().slice(4,15)]=0;





   })
   // console.log(weekly)

   if(interval=="Daily")
   {

   xaxis=Object.keys(daily);
   }
   if(interval=="Monthly")
   {
    xaxis=Object.keys(monthly);

   }
   if(interval=="Weekly")
   {
    xaxis=Object.keys(weekly);
   }
   // console.log(xaxis);
   for(let i=0;i<clients.length;i++)
   {

      let datecount :any={};
      for(let j=0;j<xaxis.length;j++)
      {
        if(xaxis[j]==undefined)
        {
        //  console.log(j)
        }
        datecount[xaxis[j]]=0;
      }
   //   console.log(datecount)


      clientline[clients[i]]=datecount;

   }
 //  console.log("monthly")
  // console.log(clientline);
   revdocdetails?.forEach((item)=>
   {
    let dateUploaded: any;
    if(interval=="Daily")
    {
      dateUploaded=item["DateUploaded"].slice(0,10)
    }
    if(interval=="Monthly")
    {
      dateUploaded=(new Date(item["DateUploaded"])).toLocaleString('default', { month: 'short' });

    }
    if(interval=="Weekly")
    {
      let date=(new Date(item["DateUploaded"]))
      date.setDate(date.getDate() - (date.getDay() + 6) % 7);
      dateUploaded=date.toString().slice(4,15);

    }
   // console.log(dateUploaded)
    let clientName=item["ClientTitle"]
    clientline[clientName][dateUploaded]+=1;


   })
   let graph3data: any[]=[];

    for(let i=0; i< clients.length; i++)
    {



      let clientspecs :any={};
      clientspecs['name']=clients[i];
      clientspecs['type']='line';


      let statuscount: any[]=[];


     clientspecs['data']=Object.values(clientline[clients[i]]);
      graph3data.push(clientspecs);




    }
   //console.log(clientline)
  //console.log(xaxis)
   //console.log(graph3data)

   this.graph3specs = {
    title: {
      text: 'Documents Uploaded',
      textStyle: {
        fontSize: 18,
        fontFamily: 'Poppins',
        color: '#000',
        fontWeight: '500'

      }
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: clients,

        type: 'scroll',

        right: 30,
        top: 35,
        bottom: 20,


    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    toolbox: {

    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: xaxis,

    },
    yAxis: {
      type: 'value',
      name: 'Count',
      nameLocation: 'middle',
      nameTextStyle:{
        align: 'left',
        fontSize: 15


      },
      nameGap: 40
    },
    series: graph3data
  };


  this.graph3Rendered=true;


  }
  getPreviousMonday(date = new Date()) {
    const previousMonday = new Date();
   // currentDateObj.setDate(currentDateObj.getDate() - (currentDateObj.getDay() + 6) % 7);

    previousMonday.setDate(date.getDate() - ((date.getDay() + 6) % 7));

    return previousMonday;
  }
  data()
  {

  // this.from.setDate(this.to.getDate()-48);
  // console.log(this.from)
  // console.log(this.to)







      // this.documentService.getAllDocumentsFilters({
      //   startDate:this.from,
      //   endDate:  this.to,
      //   clients: this.selectedClients,
      // }).then((extractDetails) => {

//       console.log( this.extractDetails);
       this.docdetails=this.extractDetails['docs']
       //this.statusTypes=this.extractDetails['statistics'].map( item => item['_id']);
       //console.log(this.statusTypes)
       this.fetchedClients = this.docdetails?.map( item => item['ClientTitle'])
      //console.log(this.fetchedClients)
      this.ClientCount = Array.from(new Set(this.fetchedClients)).map(a =>
     ({client:a, count: this.fetchedClients.filter(f => f === a).length}));













   }











  }



