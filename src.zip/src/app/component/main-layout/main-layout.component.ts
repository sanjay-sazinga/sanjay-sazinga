import { Component, NgZone, OnInit } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { GradientConfig } from '../../app-config';
import { ConfigurationComponent } from '../../core/themes/layout/admin/configuration/configuration.component';
import { RouterModule } from '@angular/router';
import { NavBarComponent } from '../../core/navbars/nav-bar/nav-bar.component';
import { NavigationComponent } from '../../core/navbars/navigation/navigation.component';
import { TranslocoService } from '@ngneat/transloco';
import { NavItemComponent } from '../../core/navbars/navigation/nav-content/nav-item/nav-item.component';
import { NavLeftComponent } from '../../core/navbars/nav-bar/nav-left/nav-left.component';
import { NavSearchComponent } from '../../core/navbars/nav-bar/nav-left/nav-search/nav-search.component';
import { NavRightComponent } from '../../core/navbars/nav-bar/nav-right/nav-right.component';
import { NavContentComponent } from '../../core/navbars/navigation/nav-content/nav-content.component';
import { NavGroupComponent } from '../../core/navbars/navigation/nav-content/nav-group/nav-group.component';
import { NavCollapseComponent } from '../../core/navbars/navigation/nav-content/nav-collapse/nav-collapse.component';
import { AdminComponent } from '../../core/themes/layout/admin/admin.component';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { InternationalizationModule } from 'src/app/core/internationalization/internationlisation.module';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { provideAnimations } from '@angular/platform-browser/animations';
import { CookieService } from 'ngx-cookie-service';
import { ClientService } from 'src/app/services/client.service';
import { CommonDataService } from 'src/app/services/common-data.service';
import { DocumentService } from 'src/app/services/document.service';
import { ScreeningService } from 'src/app/services/screening.service';
import { UserService } from 'src/app/services/user.service';
import { RoleService } from '../admin/role/role.service';
import { BreadcrumbService } from 'src/app/services/breadcumb.service';
// import { provideToastr } from 'ngx-toastr';
@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss'],
  standalone: true,
  providers: [
    TranslocoService,
    ToastrService,
    DocumentService,
    ClientService,
    RoleService,
    CommonDataService,
    UserService,
    ScreeningService,
    CookieService,
    { provide: ToastrService, useValue: ToastrService },
  ],
  imports: [
    CommonModule,
    ConfigurationComponent,
    RouterModule,
    NavBarComponent,
    NavigationComponent,
    NavItemComponent,
    NavBarComponent,
    NavLeftComponent,
    NavSearchComponent,
    NavRightComponent,
    NavContentComponent,
    NavGroupComponent,
    NavCollapseComponent,
    InternationalizationModule,
    FileUploadModule,
    ToastrModule,
  ],
})
export class MainLayoutComponent implements OnInit {
  public gradientConfig: any;
  public navCollapsed: boolean;
  public navCollapsedMob: boolean;
  public windowWidth: number;
  public navigationHover = false;

  constructor(
    private zone: NgZone,
    private location: Location,
    private braedcumbService: BreadcrumbService
  ) {
    this.gradientConfig = GradientConfig.config;
    let currentURL = this.location.path();
    const baseHerf = this.location['_baseHref'];
    if (baseHerf) {
      currentURL = baseHerf + this.location.path();
    }

    this.windowWidth = window.innerWidth;
    // console.log(this.windowWidth)

    if (this.windowWidth >= 992 && this.windowWidth <= 1024) {
      this.gradientConfig.collapseMenu = true;
    } else {
      this.navCollapsed =
        this.windowWidth >= 1024 ? this.gradientConfig.collapseMenu : false;
    }

    // this.navCollapsed = true;
    // this.navCollapsedMob = false
  }

  ngOnInit() {
    this.braedcumbService.getNavSubMenu().subscribe((res) => {
      const navCollapsed = res;
      if (navCollapsed == 'Admin') {
        this.navigationHover = true;
        this.navCollapsed = false;
      }
    });
    if (this.windowWidth < 992) {
      this.gradientConfig.layout = 'vertical';
      setTimeout(() => {
        document
          .querySelector('.pcoded-navbar')
          .classList.add('menupos-static');
        (
          document.querySelector('#nav-ps-gradient-able') as HTMLElement
        ).style.maxHeight = '100%'; // 100% amit
      }, 500);
    }
  }

  onNavMouseEnter() {
    // console.log('oof')
    this.navigationHover = true;
  }

  onNavMouseLeave() {
    // console.log('double oof');
    this.navigationHover = false;
  }

  navMobClick() {
    if (this.windowWidth < 992) {
      if (
        this.navCollapsedMob &&
        !document
          .querySelector('app-navigation.pcoded-navbar')
          .classList.contains('mob-open')
      ) {
        this.navCollapsedMob = !this.navCollapsedMob;
        setTimeout(() => {
          this.navCollapsedMob = !this.navCollapsedMob;
        }, 100);
      } else {
        this.navCollapsedMob = !this.navCollapsedMob;
      }
    }
  }
}
