import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { OcrtextComponent } from './ocrtext.component';

describe('OcrtextComponent', () => {
  let component: OcrtextComponent;
  let fixture: ComponentFixture<OcrtextComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ OcrtextComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OcrtextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
