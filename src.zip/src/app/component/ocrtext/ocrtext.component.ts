import { CommonModule } from '@angular/common';
import { Component, OnInit, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ocrtext',
  templateUrl: './ocrtext.component.html',
  styleUrls: ['./ocrtext.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,]
})
export class OcrtextComponent implements OnInit {

  constructor() { }

  @Input() ocrText
  ngOnInit(): void {

  }



}
