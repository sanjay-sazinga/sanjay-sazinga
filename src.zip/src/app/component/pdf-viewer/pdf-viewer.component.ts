import { CommonModule } from '@angular/common';
import {
  Component,
  OnChanges,
  Input,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { PdfJsViewerModule } from 'ng2-pdfjs-viewer';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { DocumentService } from 'src/app/services/document.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.scss'],
  standalone:true,
  imports:[CommonModule,PdfJsViewerModule,NgxSkeletonLoaderModule]
})
export class PdfViewerComponent implements OnChanges {
  constructor(private documentService: DocumentService) {}

  @ViewChild('pdfViewer') pdfViewer: any;

  @Input() highlightedBase64: string;
  @Input() pageNumber: number;
  @Input() summaryPDFDocument;
  @Input() ConsolidatedPDFDocument;
  @Input() documentId: string;

  isDocumentLoaded = false;
  PDFsrc;

  /*
  TODO: Unused code, to be removed if not needed.
  convertDataURIToBinary(dataURI) {
    var base64 = dataURI;
    var raw = window.atob(base64);
    var rawLength = raw.length;
    var array = new Uint8Array(new ArrayBuffer(rawLength));

    for (var i = 0; i < rawLength; i++) {
      array[i] = raw.charCodeAt(i);
    }
    return array;
  }
  */

  async ngOnChanges(changes: SimpleChanges) {
    await this.getPdfDocument();
    if ('pageNumber' in changes) {
      const checkNaN = isNaN(changes.pageNumber.currentValue);
      if (changes.pageNumber.currentValue !== undefined && checkNaN === false) {
        this.pdfViewer.page = changes.pageNumber.currentValue;
        this.pdfViewer.refresh();
      }
    }

    /*
    if ('highlightedBase64' in changes) {
      let base64RegexCheck = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
      if (base64RegexCheck.test(changes.highlightedBase64.currentValue)) {
        this.PLoaded = true;
        // this.PDFsrc = this.convertDataURIToBinary(changes.highlightedBase64.currentValue);

        this.pdfViewer.pdfSrc = this.base64toBlob(changes.highlightedBase64.currentValue, 'application/pdf'); // pdfSrc can be Blob or Uint8Array
        this.pdfViewer.refresh(); // Ask pdf viewer to load/refresh pdf
      }
    }

    if ('summaryPDFDocument' in changes) {
      if (changes.summaryPDFDocument.currentValue !== undefined) {
        this.PLoaded = true;
        this.fetchUrl(changes.summaryPDFDocument.currentValue.ParentDoc)
      }
    }

    if ('ConsolidatedPDFDocument' in changes) {
      if (changes.ConsolidatedPDFDocument.currentValue !== undefined) {
        this.PLoaded = true;
        this.fetchUrl(changes.ConsolidatedPDFDocument.currentValue)
      }
    }
    */
  }

  // pageInitialized(e: CustomEvent) {
  //   console.log('(page-initialized)', e);
  //   // this.pageNumber = 5;
  // }

  // pageChange(e: number) {
  //   console.log('(page-change)', e);
  // }

  async getPdfDocument() {
    try {
      const pdfDataResponse = await this.documentService.getDocumentPdfbyId(
        this.documentId
      );
      this.isDocumentLoaded = true;
      this.pdfViewer.pdfSrc = this.base64toBlob(
        pdfDataResponse.data,
        'application/pdf'
      );
      this.pdfViewer.refresh();
    } catch {
      Swal.fire('Failed', 'Error while opening PDF document', 'error');
    }
  }

  base64toBlob(base64Data: string, contentType: string): Blob {
    contentType = contentType || '';
    const sliceSize = 1024;
    const byteCharacters = atob(base64Data);
    const bytesLength = byteCharacters.length;
    const slicesCount = Math.ceil(bytesLength / sliceSize);
    const byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      const begin = sliceIndex * sliceSize;
      const end = Math.min(begin + sliceSize, bytesLength);
      const bytes = new Array(end - begin);
      for (let offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }
}
