import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ScreeningService } from "../../services/screening.service";
import { FormBuilder, FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { Subject } from 'rxjs';
import { UtilityService } from "../../services/utility.service";
import { FileUploadControl, FileUploadValidators } from '@iplab/ngx-file-upload';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { LoaderService } from '../../services/loader.service';
import { FileSaverService } from 'ngx-filesaver';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from 'src/app/material.module';
import { LoaderComponent } from 'src/app/shared/components/loader/loader.component';
import { DataTablesModule } from 'angular-datatables';
import { NgSelectModule } from '@ng-select/ng-select';
import { LocalStorageService } from 'src/app/services/local-storage.service';

@Component({
  selector: 'app-screening',
  templateUrl: './screening.component.html',
  styleUrls: ['./screening.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,AngularMaterialModule,LoaderComponent,NgSelectModule,
    DataTablesModule]
})
export class ScreeningComponent implements OnInit, OnDestroy {
  objectKeys = Object.keys;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  selectedOption: string;
  uploaded: boolean = false;
  checkTypes: any[] = [];
  basicDisabledFilter = { value: '-1', label: 'Select From Lists below . . .', disabled: true };
  inputFields: FormGroup;
  fileUploadLimit: number = 1;
  optionsList = {};
  fromDate = new FormControl(new Date());
  toDate = new FormControl(new Date());
  downloadSelected: Array<any> = [];
  listOptions: Array<any> = [];
  nameControl = new FormControl("", [Validators.required]);
  addressControl = new FormControl("");
  countryControl = new FormControl("");
  listControl = new FormControl([]);
  uploadedFiles: Array<File> = [];
  selectedType: String = "";
  error: boolean = false;
  tableData: any = [];
  typeFilterList: Array<any> = [];
  userType: String = "";
  dlData: any = [];
  extractedData: any = [];
  fileData: SafeResourceUrl = "";
  dataEmpty: Boolean = false;
  public fileUploadControl = new FileUploadControl(null, FileUploadValidators.filesLimit(this.fileUploadLimit));

  constructor(private screeningService: ScreeningService, private fb: FormBuilder, private utilty: UtilityService, private chRef: ChangeDetectorRef,
    private sanitizer: DomSanitizer, private loaderService: LoaderService, private fileSaver: FileSaverService, private localStorageService:LocalStorageService) {
    this.inputFields = fb.group({
      name: this.nameControl,
      address: this.addressControl,
      country: this.countryControl,
      searchList: this.listControl
    });
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  ngOnInit(): void {
    this.fromDate.setValue(new Date(this.fromDate.value.setMonth(new Date().getMonth() - 3)));
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 5,
      dom: 'Bfrtip'
    };
    this.loaderService.show();
    this.userType = this.localStorageService.getItem("user");
    this.screeningService.getScreeningOptions().then((resp) => {
      for (var i = 0; i < resp.length; i++) {
        this.checkTypes.push({ "name": resp[i], "id": i.toString(), "checked": false });
      }
      this.typeFilterList = [this.basicDisabledFilter];
      this.checkTypes.forEach((item) => {
        this.typeFilterList.push({
          label: item.name,
          value: item.name
        })
      });
      this.checkTypes[0].checked = true;
      this.selectedType = this.checkTypes[0].name;
      this.screeningService.getScreeningList().then((response) => {
        this.optionsList = response;
        this.listOptions = [this.basicDisabledFilter]
        this.optionsList[this.checkTypes[0]["id"]].forEach((item) => {
          this.listOptions.push({
            label: item,
            value: item
          })
        })
        this.loaderService.hide();
      });
    }).catch((error) => {
      this.utilty.log(this.constructor.name, "Error Getting Screening Options: ", error);
      this.loaderService.hide();
    })
  };

  selectionChanged(option) {
    this.tableData = [];
    this.fileData = "";
    this.extractedData = [];
    this.dtTrigger = new Subject<any>()
    this.uploaded = false;
    this.checkTypes.forEach((item) => {
      if (item.name == option.name) {
        item.checked = true;
      }
      else {
        item.checked = false;
      }
    })
    this.selectedType = option.name;
  }

  onFormSubmit() {
    if (this.nameControl.invalid) {
      Swal.fire({
        title: 'Name Missing!',
        text: 'Please Enter The Name to be Searched.',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false
      })
    } else {
      this.loaderService.show();
      this.screeningService.getScreeingResults(this.nameControl.value, this.countryControl.value, this.addressControl.value, this.selectedType, this.listControl.value).then(resp => {
        if (resp["SearchResult"] > 0) {
          this.tableData = resp["SearchResult"];
        } else {
          this.dataEmpty = true;
        }
        this.chRef.detectChanges();
        this.dtTrigger.next();
        this.loaderService.hide();
      }).catch((err) => {
        this.utilty.log(this.constructor.name, "Error Getting Screening Results: ", err);
        this.loaderService.hide();
      });
    }
  };


  checkDate(from, to) {
    if (from && from.getTime() > to.getTime()) {
      Swal.fire({
        title: 'Date range Error!',
        text: 'Start Date should be lower than End Date.',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false
      });
      return false;
    } else if (!to || !from) {
      Swal.fire({
        title: 'Date Error!',
        text: 'Please Enter Valid Dates.',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false
      });
      return false;
    }
    return true;
  };

  downloadReport() {
    if (this.checkDate(this.fromDate.value, this.toDate.value)) {
      this.loaderService.show();
      this.screeningService.downloadReport(
        new Date(this.fromDate.value.getFullYear(), this.fromDate.value.getMonth(), this.fromDate.value.getDate(), 0, 0, 0),
        this.toDate.value ? this.toDate.value : new Date(),
        this.downloadSelected
      ).then((extractData) => {
        this.loaderService.hide();
        this.fileSaver.save(extractData, "ScreeningReport_" + this.fromDate.value.getFullYear() + "-" + (this.fromDate.value.getMonth() + 1) + "-" + this.fromDate.value.getDate() + "_" +
          this.toDate.value.getFullYear() + "-" + (this.toDate.value.getMonth() + 1) + "-" + this.toDate.value.getDate() + ".xlsx");
      }).catch((err)=> {
        this.utilty.log(this.constructor.name, "Error Getting Report Downloaded: ", err);
        this.loaderService.hide();
      })
    }
  }

  switchToUpload() {
    this.tableData = [];
    this.fileData = "";
    this.extractedData = [];
    this.dtTrigger = new Subject<any>()
    this.uploaded = false;
    this.uploadedFiles = [];
  }

  uploadFile() {
    if (this.fileUploadControl.getError().length > 0) {
      this.error = true;
      Swal.fire({
        title: 'File Upload Limit Reached!',
        text: 'Please upload only ' + this.fileUploadLimit + ' documents at a time',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false
      });
    }
    else if (this.uploadedFiles.length == 0) {
      this.error = true;
      Swal.fire({
        title: 'File Not uploaded!',
        text: 'Please upload atleast One file to proceed',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false
      });
    } else {
      this.loaderService.show();
      this.uploaded = true;
      const formData = new FormData();
      this.uploadedFiles.forEach((file) => {
        formData.append("file", file, file.name);
      });
      formData.append("docType", "drivers_license");
      this.screeningService.getScreeningResultsFromDL(formData).then((resp) => {
        this.extractedData = resp["data"]["SearchResult"];
        for (var key in this.extractedData[0]) {
          if (key != "PepSanction Check List" && key != "IsPepSanction") {
            this.dlData[key] = this.extractedData[0][key];
          }
        }
        const blob = new Blob([new Uint8Array(atob(resp["base64_encoded_pdf_string"]).split('').map(char => char.charCodeAt(0)))], {type: 'application/pdf'});
        var fileURL = window.URL.createObjectURL(blob);
        this.fileData = this.sanitizer.bypassSecurityTrustResourceUrl(fileURL);
        if (this.extractedData[0]["IsPepSanction"] == "Yes") {
          this.tableData = this.extractedData[0]["PepSanction Check List"];
          this.chRef.detectChanges();
          this.dtTrigger.next();
          this.loaderService.hide();
        }else{
          this.dataEmpty = true;
          this.loaderService.hide();
        }
      }).catch((err) => {
        this.utilty.log(this.constructor.name, "Error while getting DL Data Extracted: ", err);
        this.loaderService.hide();
      });
    }
  }

}
