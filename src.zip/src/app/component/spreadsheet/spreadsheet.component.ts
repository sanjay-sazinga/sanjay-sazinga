import { Component, OnInit, Output, EventEmitter, OnChanges, NgZone } from '@angular/core';
import { DocumentService } from 'src/app/services/document.service';
import { UserService } from 'src/app/services/user.service';
import { RoleService } from 'src/app/services/role.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/material.module';
// import Spreadsheet from 'x-data-spreadsheet';

@Component({
  selector: 'app-spreadsheet',
  templateUrl: './spreadsheet.component.html',
  styleUrls: ['./spreadsheet.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,ReactiveFormsModule,AngularMaterialModule]
})
export class SpreadsheetComponent implements OnInit, OnChanges {

  @Output() highlightedBase = new EventEmitter<any>();
  @Output() RefreshEvent = new EventEmitter<Boolean>();
  @Output() DataLoaded = new EventEmitter<Boolean>();

  digiDocName: string;
  userRole: string;

  showTextWindow: boolean= false;
  textWindowData: {key: string, value: string};

  modalInput: any;
  modalInputApprover: string;

  documentID: any;
  analystComments: string;
  adminComments: string;

  DigiDocList: any;
  insertedRowList = [];

  editableText: Boolean = false;

  commentBtn = {
    analystComments: false,
    approverComments: false
  }

  DEFAULT_OPTIONS = {
    mode: 'edit', // edit | read
    showToolbar: true,
    showGrid: true,
    showContextmenu: true,
    view: {
      height: () => document.documentElement.clientHeight,
      width: () => document.documentElement.clientWidth,
    },
    row: {
      len: 100,
      height: 50,
    },
    col: {
      len: 26,
      width: 100,
      indexWidth: 60,
      minWidth: 60,
    },
    style: {
      bgcolor: '#000',
      align: 'left',
      valign: 'middle',
      textwrap: false,
      strike: false,
      underline: false,
      color: '#0a0a0a',
      height: 100,
      font: {
        name: 'Helvetica',
        size: 10,
        bold: false,
        italic: false,
      },
    },
  };

  dummyData: any = {
    _id: null,
    ParentDocumentID: '',
    ProcessedDocumentType: 'Digitized',
    LOCK: 'read',
    Version: 2,
    JSONData: [
      {
        modified_transactions: [],
        json_obj: [],
        formulae: {},
        coordinateList: [
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.55128', '0.155', '0.66923', '0.16699999999999998']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.75641', '0.168', '0.83333', '0.18100000000000002']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.75641', '0.168', '0.83333', '0.18100000000000002']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.75641', '0.168', '0.83333', '0.18100000000000002']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.49359000000000003', '0.142', '0.66923', '0.154']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.38718', '0.312', '0.52564', '0.325']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [
                [
                  '0.44615000000000005',
                  '0.48200000000000004',
                  '0.53333',
                  '0.495',
                ],
              ],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [
                [
                  '0.44615000000000005',
                  '0.5670000000000001',
                  '0.51667',
                  '0.58',
                ],
              ],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [
                [
                  '0.72821',
                  '0.755',
                  '0.8038500000000001',
                  '0.7659999999999999',
                ],
              ],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '1',
              '1': [['', '', '', '']],
            },
            {
              '0': '1',
              '1': [['0.47179000000000004', '0.501', '0.62436', '0.511']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
          [
            {
              '0': '',
              '1': [['', '', '', '']],
            },
            {
              '0': '',
              '1': [['', '', '', '']],
            },
          ],
        ],
        corrected_cells: {},
        uiFormula: {},
        bracketList: {},
        recon_transactions: {},
        transactions: {},
        unprocessed_table: [],
        tab_name: '',
      },
    ],
    LastUpdatedTimestamp: new Date(),
    isDeleted: false,
    LogFilePath: [],
    Counted: false,
    statusParent: 'Original',
    // isSubmit: false,
    // isApproved: false,
    // isReject: false,
    currentStatus: '',
    AnalystComments: [],
    ApproverComments: [],
    isStatsDataAvailable: false,
    superParentId: '',
  };

  testSheetData = {
    name: 'Page1',
    freeze: 'A1',
    styles: [
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
      },
      {
        format: 'number',
      },
      {
        format: 'number',
        align: 'right',
      },
      {
        format: 'percent',
      },
      {
        format: 'percent',
        align: 'right',
      },
      {
        align: 'right',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
        format: 'number',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
        format: 'normal',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'right',
        format: 'percent',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        format: 'number',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        format: 'normal',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
        format: 'normal',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        format: 'percent',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
        format: 'number',
      },
      {
        align: 'left',
      },
      {
        color: '#1C60FC',
        align: 'left',
      },
      {
        // Highlight
        bgcolor: '#FFC0CB',
      },
      {
        // Highlight and blue color
        color: '#1C60FC',
        bgcolor: '#FFC0CB',
        align: 'right',
      },
      {
        format: 'normal',
        align: 'center',
      },
      {
        font: {
          bold: true,
          size: 12,
        },
        textwrap: true,
        bgcolor: '#fff2cd',
        align: 'center',
        format: 'percent',
      },
      {
        font: {
          bold: true
        },
        textwrap: true,
        bgcolor: "red"
      }
    ],
    merges: [],
    rows: {},
    cols: {
      '0': {
        width: 293,
      },
      '1': {
        width: 293,
      },
    },
    validations: [],
    autofilter: {},
  };

  constructor(private documentService: DocumentService, private userService: UserService, private roleService: RoleService, private router: Router) { }

  ngOnChanges(){
    console.log("on changes called");
    
  }

  ngOnInit(): void {
    this.showTextWindow=false;
    this.userService.getCurrentUser().then((res) => {
      this.userService.getUserDetails(res).then((response) => {

        this.roleService.getParentRole(response.roles[0].parentRole).then(role => {
          this.userRole = role.name;
        })
      })
    })

    this.DigiDocList = window.history.state.data;
    let documentID = document.location.pathname.split('/');

    let elmWidth = document.querySelector('#customSheet').getBoundingClientRect().width;
    console.log("elmWidth= ",elmWidth);
    
    this.testSheetData.cols[0].width = elmWidth / 2 - 32;
    this.testSheetData.cols[1].width = elmWidth / 2 - 32;

    this.documentID = documentID[documentID.length - 1];
    this.documentService.getDocsByParentID(this.documentID).then((response) => {

      let selectedArticle = response.result[0].digiDocs[0];

      this.dummyData.currentStatus = response.result[0].sourceDoc.Status;

      if (selectedArticle.AnalystComments.length > 0) {
        this.analystComments = selectedArticle.AnalystComments[0].comments;
        this.dummyData.AnalystComments = selectedArticle.AnalystComments;
        this.commentBtn.analystComments = true;
      }

      if (selectedArticle.ApproverComments.length > 0) {
        this.adminComments = selectedArticle.ApproverComments[0].comments;
        this.dummyData.ApproverComments = selectedArticle.ApproverComments;
        this.commentBtn.approverComments = true;
      }

      
      this.digiDocName = selectedArticle.JSONData[0].tab_name;

      // dummyData
      this.dummyData.length = Object.keys(selectedArticle).length;
      this.dummyData.JSONData[0] = {
        ...selectedArticle.JSONData[0],
        modified: {},
      };

      this.dummyData._id = selectedArticle._id;
      this.dummyData.superParentId = response.result[0].origDoc.SuperParentId;
      this.dummyData.ParentDocumentID = selectedArticle.ParentDocumentID;

      if (response.result[0].digiDocs.length == 2) {
        this.dummyData.statusParent = 'Edited';
      } else {
        this.dummyData.statusParent = 'Original';
      }

      // let val = this.checkCells(selectedArticle.JSONData);
      let val = this.checkValuesAndStore(selectedArticle.JSONData);
      console.log("DATA FROM BACKEND= ",selectedArticle);
      
      Object.keys(selectedArticle.JSONData[0].json_obj).map((v, i, arr) => {
        this.testSheetData.rows[i] = {
          cells: {
            '0': {
              text: selectedArticle.JSONData[0].json_obj[i][0],
              style: 16,
              editable: false,
            },
            '1': {
              text: selectedArticle.JSONData[0].json_obj[i][1],
              style: val !== null ? val[i] : 16, // val: val[i] ? val[i] : 16
              editable: false,
            },
          },
        };

        this.dummyData.JSONData[0].modified[i] =
          selectedArticle.JSONData[0].modified !== undefined &&
            selectedArticle.JSONData[0].modified[i][1] == 1
            ? {
              '0': 0,
              '1': 1,
            }
            : {
              '0': 0,
              '1': 0,
            };
      });

      // const ss= new x_spreadsheet()
      const s = new Spreadsheet('#customSheet', {
        mode: 'edit',
        showToolbar: false,
        showGrid: true,
        showContextmenu: true,
        view: {
          height: function () {
            return 812;
          },
          width: function () {
            // return elmWidth + 12;
            return elmWidth
          },
        },
        row: {
          len: Object.keys(this.testSheetData.rows).length,
          height: 42,
        },
        col: {
          len: 2,
          width: 200,
          indexWidth: 60,
          minWidth: 60,
        },
      });

      s.loadData([this.testSheetData, this.testSheetData]).change((data) => {
        console.log("loadData-> change called",data);
        
        // console.log(data)
        // if (
        //   Object.keys(selectedArticle.JSONData[0].json_obj).length !==
        //   data.rows.len
        //   ) {
        //     let object;
        //   Object.keys(data.rows).map((v, i) => {
        //     selectedArticle.length = data.rows.len;
        //     if (data.rows[i] !== undefined) {
        //       // object = {
        //       //   ...object,
        //       //   [i]: {
        //       //     0: data.rows[i].cells[0].text,
        //       //     1: data.rows[i].cells[1].text,
        //       //   },
        //       // };
        //       console.log(
        //         data.rows[i].cells === null ||
        //           data.rows[i].cells === 'undefined' ||
        //           data.rows[i].cells === undefined
        //       );
        //     }
        //   });
        //   selectedArticle.JSONData[0].json_obj = object;
        // }
      });

      // this.DataLoaded.emit(true);

      s.on('cell-edited', (data) => {
        console.log("cell-edited= ",data);
        
        this.dummyData.JSONData[0].json_obj[data.selector.ri][
          data.selector.ci
        ] = data.UpdatedText;
        this.dummyData.JSONData[0].modified = {
          ...this.dummyData.JSONData[0].modified,
          [data.selector.ri]: {
            '0': 0,
            '1': 1,
          },
        };
      });

      s.on('cell-modified', (data) => {
        console.log("data= ",data);
        
        if (data.modifiedType === 'insert-row') {

          let insertedIndex = data.object.selector.ri;
          this.insertedRowList.push(insertedIndex);

          this.dummyData.JSONData[0].json_obj.splice(insertedIndex, 0, {
            0: '',
            1: '',
          });
          let placeholderObject;

          if (selectedArticle.JSONData[0].modified !== undefined) {
            placeholderObject = {};

            for (let index = 0; index < this.dummyData.JSONData[0].json_obj.length; index++) {
              if (index < insertedIndex) {
                placeholderObject[index] = selectedArticle.JSONData[0].modified[index];
              } else if (insertedIndex == index) {
                placeholderObject[index] = {
                  '0': 0,
                  '1': 1,
                };
              } else {
                // this.dummyData.JSONData[0].modified[index] = selectedArticle.JSONData[0].modified[index]
                placeholderObject[index + 1] =
                  selectedArticle.JSONData[0].modified[index] !== undefined
                    ? selectedArticle.JSONData[0].modified[index]
                    : {
                      '0': 0,
                      '1': 0,
                    };
                // delete this.dummyData.JSONData[0].modified[index];
              }
            }

            this.dummyData.JSONData[0].modified = placeholderObject;
          } else {
            for (let index = 0; index < this.dummyData.JSONData[0].json_obj.length - 1; index++) {
              if (index < insertedIndex) {
                this.dummyData.JSONData[0].modified[index] = this.dummyData.JSONData[0].modified[index][1] == 1 ? {
                  '0': 0,
                  '1': 1,
                } : {
                  '0': 0,
                  '1': 0,
                };
              } else if (index == insertedIndex) {
                this.dummyData.JSONData[0].modified[index] = {
                  '0': 0,
                  '1': 1,
                };
              } else if (index > insertedIndex) {
                this.dummyData.JSONData[0].modified[index + 1] = this.dummyData.JSONData[0].modified[index][1] == 1
                  ? {
                    '0': 0,
                    '1': 1,
                  }
                  : {
                    '0': 0,
                    '1': 0,
                  };
                // delete this.dummyData.JSONData[0].modified[index];
              }
            }
          }
        } else if (data.modifiedType === 'delete-row') {
          // Original modified Object

          // Index of deleted row
          let deletedIndex = data.object.selector.ri;

          // Delete from InsertedRowList
          if (this.insertedRowList.includes(deletedIndex)) {
            this.insertedRowList.splice(this.insertedRowList.indexOf(deletedIndex), 1)
          }

          // Delete from dummyData.json_obj
          this.dummyData.JSONData[0].json_obj.splice(deletedIndex, 1)
          this.dummyData.JSONData[0].modified = this.deleteAndIndexObjectValue(selectedArticle.JSONData[0].modified, deletedIndex);

          // console.log(this.deleteAndIndexObjectValue(selectedArticle.JSONData[0].modified, deletedIndex));
        }
      });

      s.on('cell-selected', (cell, ri, ci) => {
        // console.log("cell selected= ",cell, ri,ci);
        // console.log(s.cell(ri,ci,0));
        console.log("cell-selected");
        
        console.log("spreadsheet object=",s);
        const newData = {
          name: 'Page-New',
          freeze: 'A1',
          styles: [
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
            },
            {
              format: 'number',
            },
            {
              format: 'number',
              align: 'right',
            },
            {
              format: 'percent',
            },
            {
              format: 'percent',
              align: 'right',
            },
            {
              align: 'right',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'right',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'right',
              format: 'number',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'right',
              format: 'normal',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'right',
              format: 'percent',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'center',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              format: 'number',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              format: 'normal',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'center',
              format: 'normal',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              format: 'percent',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'center',
              format: 'number',
            },
            {
              align: 'left',
            },
            {
              color: '#1C60FC',
              align: 'left',
            },
            {
              // Highlight
              bgcolor: '#FFC0CB',
            },
            {
              // Highlight and blue color
              color: '#1C60FC',
              bgcolor: '#FFC0CB',
              align: 'right',
            },
            {
              format: 'normal',
              align: 'center',
            },
            {
              font: {
                bold: true,
                size: 12,
              },
              textwrap: true,
              bgcolor: '#fff2cd',
              align: 'center',
              format: 'percent',
            },
            {
              font: {
                bold: true
              },
              textwrap: true,
              bgcolor: "red"
            }
          ],
          merges: [],
          rows: {},
          cols: {
            '0': {
              width: 293,
            },
            '1': {
              width: 293,
            },
          },
          validations: [],
          autofilter: {},
        };
        // s.addSheet("abcd",true)
        // console.log("s.datas= ",s.datas[s.datas.length-1]);
        // s.datas[s.datas.length-1].setData({...this.testSheetData, name: "Urjit"})
        // // s.sheet.reload()
        // s.reRender()
        // s.change((data)=>{
        //   console.log("data change");
          
        // })
        
        // // s.change((newData)=>{
        // //   console.log("inside change");
          
        // //   s.loadData(newData)
        // // })
        // console.log("getData= ", s.getData());
        // console.log("sheet= ",s.sheet);
        
        // console.log("getRect= ",s.sheet.getRect());
        // // console.log("testSheetData=", this.testSheetData);
        // if(ci!=0){
        //   this.textWindowData={
        //     key: s.cell(ri,0,0)["text"],
        //     value: s.cell(ri,ci,0)["text"]  
        //   }
        //   this.showTextWindow=true;
        //   console.log("getTableOffset= ", s.sheet.getTableOffset());
          
        //   document.getElementById("textWindowContainer").style.height=s.sheet.getTableOffset().height+"px";
        //   document.getElementById("textWindowContainer").style.width=s.sheet.getTableOffset().width+"px";
        //   document.getElementById("textWindowContainer").style.top=s.sheet.getTableOffset().top+"px";
        //   document.getElementById("textWindowContainer").style.left=s.sheet.getTableOffset().left+"px";
        // }
                     
        // if (!this.editableText) {
        //   if (ci === 1) {
        //     let details = {
        //       ParentDocumentID: selectedArticle.ParentDocumentID,
        //       row: ri,
        //       col: ci,
        //     };

        //     this.documentService.getHighlightedLoanDocs(details).then((res) => {
        //       this.highlightedBase.emit(res.highlighted);
        //     }).catch((err) => {
        //       console.log(err);
        //     });
        //   }
        // }
      });
    }).catch(function (err) {
      console.log('err in fetch Processed Document Object function', err);
    });

    
  }

  handletextWindow(){
    if(this.showTextWindow){
      document.getElementById("textWindowContainer").style.height="0px";
      document.getElementById("textWindowContainer").style.width="0px";
    }
    this.showTextWindow= !this.showTextWindow
  }

  deleteAndIndexObjectValue(obj, int) {
    delete obj[int];
    let keys = Object.keys(obj).map(Number).sort((a, b) => a - b);

    for (let i = keys.indexOf(int + 1); i < keys.length; i++) {
      obj[keys[i] - 1] = obj[keys[i]];
      delete obj[keys[i]];
    }
    return obj;
  }

  checkValuesAndStore(JSONData) {
    let result = {};
    if (
      JSONData[0].modified !== undefined &&
      JSONData[0].corrected_cells !== undefined
    ) {
      for (let i = 0; i < JSONData[0].json_obj.length; i++) {
        if (JSONData[0].modified[i][1] === 1) {
          if (
            typeof JSONData[0].corrected_cells.high_confidence !== undefined ||
            typeof JSONData[0].corrected_cells.low_confidence !== undefined
          ) {
            if (
              JSONData[0].modified[i][1] === 1 &&
              (JSONData[0].corrected_cells.high_confidence[i][1] === 1 ||
                JSONData[0].corrected_cells.low_confidence[i][1] === 1)
            ) {
              result[i] = 19;
            } else {
              result[i] = 17;
            }
          }
        } else if (
          typeof JSONData[0].corrected_cells.high_confidence !== undefined ||
          typeof JSONData[0].corrected_cells.low_confidence !== undefined
        ) {
          if (
            JSONData[0].corrected_cells.high_confidence[i][1] === 1 ||
            JSONData[0].corrected_cells.low_confidence[i][1] === 1
          ) {
            result[i] = 18;
          }
        }
      }
    } else if (JSONData[0].modified !== undefined) {
      for (let i = 0; i < JSONData[0].json_obj.length; i++) {
        // console.log(JSONData[0].modified)
        if (JSONData[0].modified[i][1] === 1) {
          result[i] = 17;
        }
      }
    } else if (JSONData[0].corrected_cells !== undefined) {
      for (let i = 0; i < JSONData[0].json_obj.length; i++) {
        if (
          JSONData[0].corrected_cells.high_confidence[i][1] === 1 ||
          JSONData[0].corrected_cells.low_confidence[i][1] === 1
        ) {
          result[i] = 18;
        }
      }
    }

    return Object.keys(result).length > 0 ? result : null;
  }

  // reloadCurrentRoute() {
  //   let currentUrl = this.router.url;
  //   this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
  //     this.router.navigate([currentUrl]);
  //   });
  // }

  backToConsolidated(id) {
    this.router.navigateByUrl('documents/summary/' + this.dummyData.superParentId);
  }

  deleteDigitizedDocument() {
    // console.log(this.dummyData);
    if (this.dummyData.statusParent == 'Edited') {
      this.documentService
        .deleteDigitizedDocumentByID(this.dummyData._id)
        .then((res) => {
          this.RefreshEvent.emit(true);
        })
        .catch(function (err) {
          console.log('err in fetch Processed Document Object function', err);
        });
    }
  }


  downloadDigitizeDocumentExcel() {
    this.documentService.downloadDigitizedDoc(this.dummyData.ParentDocumentID).then((res) => {
        let file = new Blob([res], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });

        let url = window.URL.createObjectURL(file);
        let a = document.createElement('a');
        document.body.appendChild(a);
        a.href = url;
        a.download = `Document ID - ${this.dummyData._id}.xls`;
        a.click();
      })
      .catch(function (err) {
        console.log('err in fetch Processed Document Object function', err);
      });
  }

  downloadDigitizeDocumentJSON() {
    let file = new Blob([JSON.stringify(this.dummyData.JSONData[0].json_obj)], {
      type: 'application/json',
    });
    let a = document.createElement('a');
    a.href = URL.createObjectURL(file);
    a.download = `Document ID - ${this.dummyData._id}`;
    a.click();
  }

  saveDigitizedDocumentUpdate() {

    this.documentService.cloneDigitizedDocument(this.dummyData).then((res) => {
      if (res.error_code == 0) {
        this.RefreshEvent.emit(true);
      }
    }).catch(function (err) {
      console.log('err in fetch Processed Document Object function', err);
    });
  }

  editRowSpreadsheet() {
    if (this.editableText == false) {
      Object.keys(this.testSheetData.rows).map((v, i) => {
        this.testSheetData.rows[i].cells[1].editable = true;
      });

      this.editableText = !this.editableText;
    } else if (this.editableText == true) {
      Object.keys(this.testSheetData.rows).map((v, i) => {
        this.testSheetData.rows[i].cells[1].editable = false;
      });

      this.editableText = !this.editableText;
    }
  }

  saveModalInput() {
    this.documentService.setComment('Analyst', this.dummyData._id, this.modalInput, null).then((res) => {
        this.RefreshEvent.emit(true);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  saveModalApprover() {
    if (this.modalInputApprover.length !== 0) {
      this.documentService.setComment('Approver', this.dummyData._id, this.modalInputApprover, 'Approved').then((res) => {
        
          this.RefreshEvent.emit(true);
        

      }).catch((err) => {
          console.log(err);
        });
    }
  }

  rejectModalApprover() {
    if (this.modalInputApprover.length !== 0) {
      this.documentService.setComment('Approver', this.dummyData._id, this.modalInputApprover, 'Rejected').then((res) => {

        this.RefreshEvent.emit(true);
      }).catch((err) => {
          console.log(err);
        });
    }
  }
}
