import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatedPageComponent } from './consolidated-page.component';

describe('ConsolidatedPageComponent', () => {
  let component: ConsolidatedPageComponent;
  let fixture: ComponentFixture<ConsolidatedPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidatedPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsolidatedPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
