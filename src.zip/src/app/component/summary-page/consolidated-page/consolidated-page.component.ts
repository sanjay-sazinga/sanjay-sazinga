import {
  Component,
  OnInit,
  AfterViewInit,
  Input,
  ChangeDetectorRef,
} from '@angular/core';
import { DocumentService } from 'src/app/services/document.service';
import { PdfViewerComponent } from 'ng2-pdf-viewer';
import { CommonModule } from '@angular/common';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';

@Component({
  selector: 'app-consolidated-page',
  templateUrl: './consolidated-page.component.html',
  styleUrls: ['./consolidated-page.component.scss'],
  standalone: true,
  imports: [CommonModule, NgxSkeletonLoaderModule],
})
export class ConsolidatedPageComponent implements OnInit, AfterViewInit {
  constructor(
    private documentService: DocumentService,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  skeletonVisibility = false;
  toggleChildComponent = true;
  dataLoaded = false;

  ConsolidatedPDFDocument;
  highlightedBase;
  digiStatement: object;
  userType: any;
  documentID;

  ocrText;

  documentName;
  clientName;

  statusStyle = {
    background: '',
    name: '',
    statuscolor: '',
  };
  statusVisibility = false;

  ocrTextBool: boolean;
  OrigTextBool = true;

  DigiDocList: any;
  currDocument;

  // Bool for determining whether at first or last page
  pagePosition = {
    pageFirst: false,
    pageLast: false,
  };

  pageNumber = {
    pageStart: '',
    pageEnd: '',
  };

  @Input() digiDocID;
  ngOnInit(): void {
    this.DigiDocList = window.history.state.data;
    const documentID = document.location.pathname.split('/');
    this.documentID = documentID[documentID.length - 1];

    this.documentService.getDocumentParentById(this.documentID).then((res) => {
      this.DigiDocList = res.doc;

      this.currDocument = this.findID(this.documentID);

      this.pagePosition.pageFirst =
        this.currDocument?.index === 0 ? true : false;
      this.pagePosition.pageLast =
        this.currDocument?.index === this.DigiDocList.length - 1 ? true : false;
    });

    this.iniData(this.documentID);

    // Toggle 'pdfToggle'
    const pdfToggle = document.getElementById('pdfToggle') as HTMLInputElement;
    pdfToggle.checked = true;

    // Toggle on OCR
    const ocrInput = document.getElementById('ocrCheckBox') as HTMLInputElement;
    ocrInput.checked = true;
    this.ocrTextBool = true;

    const x = document.querySelector('x-spreadsheet-item');
    this.dataLoaded = true;
  }

  iniData(id) {
    this.documentService.getDocsByParentID(id).then((response) => {
      this.ConsolidatedPDFDocument = {
        document: response.result[0].sourceDoc,
        source: 'Processed',
      };

      this.pageNumber.pageStart = response.result[0].origDoc.PageStart;
      this.pageNumber.pageEnd = response.result[0].origDoc.PageEnd;

      // OCR Text output
      this.ocrText = response.result[0].sourceDoc.OCR_Output;
      const key = Object.keys(this.ocrText)[0];
      this.ocrText = this.ocrText[key];

      this.documentName = response.result[0].sourceDoc.DocumentName;
      this.clientName = response.result[0].sourceDoc.ClientTitle;

      this.documentService.getStatusList().then((res) => {
        const status = res.listofStatus.find(
          (elm) => elm.name == response.result[0].sourceDoc.Status
        );

        if (status !== undefined) {
          this.statusStyle = status;
          this.statusVisibility = true;
        } else {
          this.statusVisibility = false;
        }
      });
    });
  }

  ngAfterViewInit() {}

  OPbool() {
    const pdfToggle = document.getElementById('pdfToggle') as HTMLInputElement;

    if (this.OrigTextBool) {
      const tempHolder = {
        ...this.ConsolidatedPDFDocument,
      };

      tempHolder.source = 'Original';
      this.ConsolidatedPDFDocument = { ...tempHolder };
      this.OrigTextBool = false;
    } else {
      const tempHolder = {
        ...this.ConsolidatedPDFDocument,
      };

      tempHolder.source = 'Processed';
      this.ConsolidatedPDFDocument = { ...tempHolder };
      this.OrigTextBool = true;
    }
  }

  toggleOCR() {
    const ocrInput = document.getElementById('ocrCheckBox') as HTMLInputElement;
    const pdfPreview = document.querySelector(
      '.consolidated-pdf-loader'
    ) as any;

    if (!this.ocrTextBool) {
      this.ocrTextBool = true;
      ocrInput.checked = true;
      pdfPreview.style.height = '480px';
    } else {
      this.ocrTextBool = false;
      ocrInput.checked = false;

      pdfPreview.style.height = '800px';
    }
  }

  findID(id) {
    for (let i = 0; i < this.DigiDocList.length; i++)
      if (this.DigiDocList[i]._id == id)
        return { status: true, object: this.DigiDocList[i], index: i };
    return null;
  }

  Next() {
    let ID: any = document.location.pathname.split('/');
    ID = ID[ID.length - 1];

    if (this.currDocument.index !== this.DigiDocList.length - 1) {
      // this.router.navigateByUrl('/documents/summary/Screening/' + this.DigiDocList[this.currDocument.index + 1]._id);
      location.href =
        '/documents/summary/Screening/' +
        this.DigiDocList[this.currDocument.index + 1]._id;
    }
  }

  Previous() {
    let ID: any = document.location.pathname.split('/');
    ID = ID[ID.length - 1];

    if (this.currDocument.index !== 0) {
      // this.router.navigateByUrl('/documents/summary/Screening/' + this.DigiDocList[this.currDocument.index + 1]._id);
      location.href =
        '/documents/summary/Screening/' +
        this.DigiDocList[this.currDocument.index - 1]._id;
    }
  }

  onBase64Passed(resp) {
    this.highlightedBase = resp;
  }

  onComponentToggle(state) {
    this.toggleChildComponent = false;
    this.skeletonVisibility = true;
    this.changeDetectorRef.detectChanges();
    this.toggleChildComponent = true;
    this.changeDetectorRef.detectChanges();
    this.iniData(this.documentID);
  }

  onDataLoaded(state) {
    this.skeletonVisibility = false;
  }
}
