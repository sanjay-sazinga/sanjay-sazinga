import { CommonModule } from '@angular/common';
import { Component, OnInit, OnChanges, Input, SimpleChanges } from '@angular/core';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PdfJsViewerModule } from 'ng2-pdfjs-viewer';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { DocumentService } from 'src/app/services/document.service';

@Component({
  selector: 'app-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.scss'],
  standalone:true,
  imports:[CommonModule,PdfJsViewerModule,NgxSkeletonLoaderModule]
})
export class PdfViewerComponent implements OnInit, OnChanges {
  constructor(private documentService: DocumentService) { }

  @Input() highlightedBase64: string;
  @Input() summaryPDFDocument;
  @Input() ConsolidatedPDFDocument;

  PLoaded: Boolean = false
  PDFsrc;

  ngOnInit(): void {
  }

  convertDataURIToBinary(dataURI) {
    var base64 = dataURI;
    var raw = window.atob(base64);
    var rawLength = raw.length;
    var array = new Uint8Array(new ArrayBuffer(rawLength));

    for (var i = 0; i < rawLength; i++) {
      array[i] = raw.charCodeAt(i);
    }
    return array;
  }

  ngOnChanges(changes: SimpleChanges) {

    if ('highlightedBase64' in changes) {
      let base64RegexCheck = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
      if (base64RegexCheck.test(changes.highlightedBase64.currentValue)) {
        this.PDFsrc = this.convertDataURIToBinary(changes.highlightedBase64.currentValue);
      }
    }

    if ('summaryPDFDocument' in changes) {
      if (changes.summaryPDFDocument.currentValue !== undefined) {
        this.fetchUrl(changes.summaryPDFDocument.currentValue.ParentDoc)
      }
    }

    if ('ConsolidatedPDFDocument' in changes) {
      if (changes.ConsolidatedPDFDocument.currentValue !== undefined) {
        this.fetchUrl(changes.ConsolidatedPDFDocument.currentValue)
      }
    }
  }

  fetchUrl(document) {
    console.log("Getting the pdf")
    console.log(document)
    this.documentService.getDocumentPdfbyId(document).then((res) => {
      this.PDFsrc = this.convertDataURIToBinary(res.pdfUrl);
      this.PLoaded = true
      // console.log(this.PDFsrc);
    });
  }
}
