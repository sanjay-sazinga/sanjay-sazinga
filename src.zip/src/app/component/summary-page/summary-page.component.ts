import { CommonModule } from '@angular/common';
import { ConstantPool } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PdfJsViewerModule } from 'ng2-pdfjs-viewer';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { DocumentService } from 'src/app/services/document.service';
import { SummaryTableViewComponent } from './summary-table-view/summary-table-view.component';
import { PdfViewerComponent } from '../pdf-viewer/pdf-viewer.component';
import { LocalStorageService } from 'src/app/services/local-storage.service';

@Component({
  selector: 'app-summary-page',
  templateUrl: './summary-page.component.html',
  styleUrls: ['./summary-page.component.scss'],
  standalone: true,
  imports: [CommonModule,
    FormsModule,
    RouterModule,
    PdfViewerModule,
    PdfJsViewerModule,
    NgxSkeletonLoaderModule,
    PdfViewerComponent,
    SummaryTableViewComponent
  ],
})
export class SummaryPageComponent implements OnInit {
  constructor(
    private activatedRoute: ActivatedRoute,
    private documentService: DocumentService,
    private localStorageService:LocalStorageService
  ) { }
  documentTableConsolidated: boolean = false;

  statusProperties;
  parentDocDetails = {
    documentAuthor: '',
    documentName: '',
    documentStatus: '',
    color: '',
    bgColor: ''
  };

  summaryPDFDocument;

  docList: any;
  docOptions: any;

  // Bool for determining whether at first or last page
  pagePosition = {
    first: false,
    last: false
  };

  documentID: string;
  digiStatement: object;
  ocrText: string = '';
  dataLoaded: boolean = false;

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params) => {
      if (params.hasOwnProperty('id') && params['id'] !== undefined) {
        this.documentID = params['id'];
        // this.fetchProcessedDocumentObject(this.documentID)
      }
    });

    let crrDocID = this.documentID;
    this.docOptions = JSON.parse(this.localStorageService.getItem("DocsAPIOptions"));

    this.documentService.getDocumentsByPage(this.docOptions).then((res) => {
      this.docList = res.data;

      // DocList with digitization failed filtered out
      let filteredList = this.filterDocList(this.docList);
      let filteredCrrIndex = filteredList.findIndex(
        (doc) => doc._id == crrDocID
      );

      this.pagePosition.first =
        filteredCrrIndex == 0 && this.docList.page === 1 ? true : false;
      this.pagePosition.last =
        filteredCrrIndex == filteredList.length - 1 &&
        this.docList.page === this.docList.pages
          ? true
          : false;
    });
  }

  moveToSummary() {
    this.documentTableConsolidated = false;
  }

  digiDocHandler(val) {
    if (val?.data?.ParentDoc?.DocumentName.length > 24) {
      this.parentDocDetails.documentName =
        val?.data?.ParentDoc?.DocumentName?.substring(0, 24) + '...';
    } else {
      this.parentDocDetails.documentName = val?.data?.ParentDoc?.DocumentName;
    }

    this.summaryPDFDocument = val.data;

    // this.parentDocDetails.documentName = val.ParentDoc.DocumentName;
    this.parentDocDetails.documentAuthor = val?.data?.ParentDoc?.ClientTitle;
    this.parentDocDetails.documentStatus = val?.data?.ParentDoc?.Status;

    this.parentDocDetails.color = val?.styling?.statuscolor;
    this.parentDocDetails.bgColor = val?.styling?.background;

    this.dataLoaded = true;
  }

  findDocByID(id) {
    for (var i = 0; i < this.docList.docs.length; i++)
      if (this.docList.docs[i]._id == id)
        return { status: true, object: this.docList.docs[i] };
    return null;
  }

  filterDocList(docList) {
    let list = [];

    for (let index = 0; index < docList.docs.length; index++) {
      if (docList.docs[index].Status !== 'Digitization Failed') {
        list.push(docList.docs[index]);
      }
    }

    return list.length > 0 ? list : null;
  }

  Next() {
    // Index and ID from digiDocList
    let crrDocID = this.documentID;
    // let crrIndex = this.docList.docs.findIndex((doc) => doc._id == crrDocID);

    // DocList with digitization failed filtered out
    let filteredList = this.filterDocList(this.docList);
    let filteredCrrIndex = filteredList.findIndex((doc) => doc._id == crrDocID);

    if (
      this.docList.page === this.docList.pages &&
      filteredList[filteredCrrIndex + 1] === undefined
    ) {
      return null;
    } else {
      if (
        filteredList[filteredCrrIndex + 1] === undefined ||
        this.findDocByID(filteredList[filteredCrrIndex + 1]._id == null)
      ) {
        this.docOptions.page = this.docOptions.page + 1;

        this.documentService
          .getDocumentsByPage(this.docOptions)
          .then((response) => {
            let filteredResponse = this.filterDocList(response.data);

          this.docList = {
            count: response.count,
            docs: [...filteredList, ...filteredResponse],
            limit: response.limit,
            page: response.page,
            statistics: response.statistics,
          };
          this.localStorageService.setItem('DocsAPIOptions',JSON.stringify(this.docOptions));
          this.localStorageService.setItem('DocByPageResp',JSON.stringify(this.docList))

            location.href = 'documents/summary/' + filteredResponse[0]._id;
          });
      } else {
        location.href =
          'documents/summary/' + filteredList[filteredCrrIndex + 1]._id;
      }
    }
  }

  Previous() {
    // Index and ID from digiDocList
    let crrDocID = this.documentID;
    // let crrIndex = this.docList.docs.findIndex((doc) => doc._id == crrDocID);

    // DocList with digitization failed filtered out
    let filteredList = this.filterDocList(this.docList);
    let filteredCrrIndex = filteredList.findIndex((doc) => doc._id == crrDocID);

    if (
      this.docList.page === 1 &&
      filteredList[filteredCrrIndex - 1] === undefined
    ) {
      return null;
    } else {
      if (
        filteredList[filteredCrrIndex - 1] === undefined ||
        this.findDocByID(filteredList[filteredCrrIndex - 1]._id == null)
      ) {
        this.docOptions.page = this.docOptions.page - 1;

        this.documentService
          .getDocumentsByPage(this.docOptions)
          .then((response) => {
            let filteredResponse = this.filterDocList(response);

            this.docList = {
              count: response.count,
              docs: [...filteredResponse, ...filteredList],
              limit: response.limit,
              page: response.page,
              statistics: response.statistics
            };

          this.localStorageService.setItem('DocsAPIOptions',JSON.stringify(this.docOptions));
          this.localStorageService.setItem('DocByPageResp',JSON.stringify(this.docList))

            location.href =
              'documents/summary/' +
              filteredResponse[filteredResponse.length - 1]._id;
          });
      } else {
        location.href =
          'documents/summary/' + filteredList[filteredCrrIndex - 1]._id;
      }
    }
  }

  // fetchProcessedDocumentObject(parentDocumentId) {
  //   var temp = localStorage.getItem('superParentDocumentName');
  //   localStorage.setItem('originalDocumentName', temp);

  //   this.documentService.getDigitizedDocById(parentDocumentId).then((response) => {
  //     this.digiStatement = response["JSONData"][0]["json_obj"]
  //     this.ocrText=JSON.stringify(response["OCR_Output"])
  //     //console.log(this.digiStatement,this.ocrText,'ssssssss')
  //   }).catch(function (err) {
  //     console.log('err in fetch Processed Document Object function', err);
  //   });
  //   getDocumentsByPage();
  // };
}
