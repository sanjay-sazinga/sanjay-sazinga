import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryTableViewComponent } from './summary-table-view.component';

describe('SummaryTableViewComponent', () => {
  let component: SummaryTableViewComponent;
  let fixture: ComponentFixture<SummaryTableViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SummaryTableViewComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SummaryTableViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
