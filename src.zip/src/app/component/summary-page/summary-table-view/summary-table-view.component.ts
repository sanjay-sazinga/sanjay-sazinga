import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DocumentService } from 'src/app/services/document.service';
import { FileSaverService } from 'ngx-filesaver';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { NgxPaginationModule, PaginationInstance } from 'ngx-pagination';
import { Router } from '@angular/router';
import { UserService } from '../../../services/user.service';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { LocalStorageService } from 'src/app/services/local-storage.service';

@Component({
  selector: 'app-summary-table-view',
  templateUrl: './summary-table-view.component.html',
  styleUrls: ['./summary-table-view.component.scss'],
  standalone:true,
  imports:[NgxSkeletonLoaderModule,CommonModule,NgxPaginationModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SummaryTableViewComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private documentService: DocumentService,
    private fileSaverService: FileSaverService,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef,
    public userService: UserService,
    private localStorageService:LocalStorageService
  ) {}

  StatusResponse;
  statusProperties;

  statusEditOptions = [];
  selectedStatus: String;

  allData;
  Docs: any;
  TrimmedDoc: any;
  selectedDocID: any;
  editToggle: boolean = false;
  DigiDocVis: boolean = false;
  checkedDocuments: Array<any> = [];
  sorted: boolean = false;
  dataLoaded: boolean = false;
  page: number = 1;
  pageVisibility: boolean = false;
  labels: any = {
    prev: 'prev',
    next: 'next',
  };

  bgColor: String;
  color: String;

  public config: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 8,
    currentPage: 1,
  };

  @Output() DocumentDetails: EventEmitter<object> = new EventEmitter();

  @Input() docID;
  digitData: object;

  ngOnInit(): void {
    this.fetchExtracted(this.docID);
  }

  getHighlightClasses(status) {
    if (status == 'Pending Validation') {
      return {
        'background-color': '#fcf8ed',
        color: '#ff7300',
      };
    } else if (status == 'Pending Approval') {
      return {
        'background-color': 'rgb(39, 156, 10,0.2)',
        color: '#279c0a',
      };
    } else if (status == 'Approved') {
      return {
        'background-color': '#9cf7b0',
        color: '#039623',
      };
    } else if (status == 'Found') {
      return {
        'background-color': '#b2dba1',
        color: '#6acf3e',
      };
    } else if (status == 'Extraction Failed') {
      return {
        'background-color': 'rgb(192, 0, 64,0.2)',
        color: '#c00040',
      };
    } else if (status == 'In Queue') {
      return {
        'background-color': 'lightsteelblue',
        color: '#0063c0',
      };
    } else if (status == 'Digitization Failed') {
      return {
        'background-color': 'rgb(192, 0, 64,0.2)',
        color: '#c00040',
      };
    } else if (status == 'New') {
      return {
        'background-color': 'rgba(255, 255, 255, 0.973)',
        color: 'rgb(109, 108, 108)',
      };
    } else if (status == 'Digitized') {
      return {
        'background-color': '#bcd7f5',
        color: '#017aff',
      };
    } else if (status == 'TBD') {
      return {
        'background-color': '#bcd7f5',
        color: '#017aff',
      };
    }
  }

  iconEvent(iconType: string, id: string, title: string): void {
    if (iconType === 'VIEW') {
      this.router.navigateByUrl(
        `/documents/summary/${this.docID}/Screening/${id}`
      );
    }
    if (iconType === 'EDIT') {
      this.modifyStatusOptions(this.statusProperties);
      this.editToggle = true;
    }
    if (iconType === 'SAVE') {
      const pageSt = (<HTMLInputElement>document.getElementById('pageStart'))
        .value;
      const pageEd = (<HTMLInputElement>document.getElementById('pageEnd'))
        .value;

      const payload = {
        status: this.selectedStatus,
        SuperParentId: this.allData.ParentDoc._id,
        childIDs: this.allData.ParentDoc.ChildIds,
        pageStart: pageSt,
        pageEnd: pageEd,
      };

      this.documentService
        .documentSummaryOperations(id, iconType, payload)
        .then(() => {
          this.fetchExtracted(id);
        })
        .catch((err) => {
          console.log(err);
        });

      this.editToggle = false;
    }

    if (iconType === 'DOWNLOAD') {
      this.documentService.downloadDigitizedDoc(id).then((res) => {
        this.fileSaverService.save(res, title.slice(0, -4) + '.xlsx');
      });
    }

    if (iconType === 'DELETE') {
      // this.swal.fire();
      this.documentService
        .documentSummaryOperations(id, iconType, null)
        .then(() => {
          window.location.reload();
        })
        .catch((err) => {
          console.log(err);
        });
    }

    if (iconType === 'CANCEL') {
      this.editToggle = false;
    }
  }

  modifyStatusOptions(crrStatus) {
    if (crrStatus.name == 'Pending Validation') {
      this.statusEditOptions = [crrStatus.name, 'Not Supported'];
      this.selectedStatus = crrStatus.name;
    }

    if (crrStatus.name == 'Pending Approval') {
      this.statusEditOptions = [
        crrStatus.name,
        'Pending Validation',
        'Not Supported',
      ];
      this.selectedStatus = crrStatus.name;
    }
  }

  sortPageNumber() {
    // console.log(this.Docs);

    if (this.sorted) {
      this.Docs.sort(function (a, b) {
        return (
          parseInt(a.PageStart.split(',')[0]) -
          parseInt(b.PageStart.split(',')[0])
        );
      });

      this.sorted = !this.sorted;
    } else {
      this.Docs.sort(function (a, b) {
        if (b.PageStart.includes('-') || a.PageStart.includes('-')) {
          return (
            parseInt(b.PageStart.split('-')[0]) -
            parseInt(a.PageStart.split('-')[0])
          );
        } else if (b.PageStart.includes(',') || a.PageStart.includes(',')) {
          return (
            parseInt(b.PageStart.split(',')[0]) -
            parseInt(a.PageStart.split(',')[0])
          );
        } else {
          return b.PageStart - a.PageStart;
        }
      });

      this.sorted = !this.sorted;
    }
  }

  CheckAllOptions(event) {
    let checkBoxNodeList = document.querySelectorAll(
      '.checkBoxesDocuments'
    ) as NodeList;
    if (event.target.checked) {
      for (let index = 0; index < checkBoxNodeList.length; index++) {
        const element = checkBoxNodeList[index] as HTMLInputElement;

        element.checked = true;
      }
    } else {
      for (let index = 0; index < checkBoxNodeList.length; index++) {
        const element = checkBoxNodeList[index] as HTMLInputElement;

        element.checked = false;
      }
    }
  }

  onCheckboxChange(event: any, id: any) {
    if (event.target.checked) {
      let selectedDocument = this.Docs.findIndex((obj) => obj._id == id);
      this.checkedDocuments.push(this.Docs[selectedDocument]);
    } else {
      let selectedDocument = this.checkedDocuments.findIndex(
        (obj) => obj._id == id
      );
      this.checkedDocuments.splice(selectedDocument, 1);
    }
  }

  sweetAlertDialog(id, title) {
    Swal.mixin({
      customClass: {
        popup: 'swal-popup-container',
        title: 'swal-popup-title',
        confirmButton: 'swal-confirmBtn',
        cancelButton: 'swal-cancelBtn',
      },
    })
      .fire({
        title: 'Are you sure want to delete document?',
        text: `You will not be able to recover document "${title}"!`,
        showCancelButton: true,
        confirmButtonText: 'Delete!',
        cancelButtonText: 'Cancel',
      })
      .then((result) => {
        if (result.value) {
          this.iconEvent('DELETE', id, title);
          Swal.fire(
            'Deleted',
            'Document has been deleted successfully.',
            'success'
          );
        }
      });

    // let btnContainer = <HTMLInputElement>document.querySelector('.swal2-show');
    // btnContainer.style.padding = '1.5rem !important';

    // let swalTitle = <HTMLInputElement>document.querySelector('.swal--popup-title');
    // swalTitle.style.marginTop = '1rem';
  }

  fetchExtracted(id) {
    this.documentService
      .getDocumentParentById(id)
      .then((childDocumentListResponse: any) => {
        const documents = childDocumentListResponse.data;
        this.allData = { doc: documents };
        this.Docs = documents.childDocs;
        this.localStorageService.setItem('DigitizedDocList', JSON.stringify(documents))

        // Set visibility of pagination
        this.Docs.length > 6
          ? (this.pageVisibility = true)
          : (this.pageVisibility = false);

        this.TrimmedDoc = this.Docs;

        this.documentService.getStatusList().then((res) => {
          this.StatusResponse = res;
          this.statusProperties = res.data?.find(
            (elm) => elm.name == childDocumentListResponse?.ParentDoc?.Status // Check: From where we need to get ParentDoc Status?
          );

          const format = {
            data: { doc: documents },
            styling: this.statusProperties,
          };
          this.DocumentDetails.emit(format);
        });

        this.Docs.map((el) => {
          if (el?.PageStart?.includes(',')) {
            let trimmedIndex = this.TrimmedDoc.findIndex(
              (obj) => obj._id == el._id
            );
            this.TrimmedDoc[trimmedIndex].PageStart =
              el?.PageStart?.split(',')[0];
            // console.log(this.TrimmedDoc[trimmedIndex].PageStart);
          }
        });

        this.dataLoaded = true;

        // console.log("Docs: ", this.Docs);
        // console.log("TrimmedDocs: ", this.TrimmedDoc);
      })
      .catch(function (err) {
        console.log('err in fetch Processed Document Object function', err);
      });
  }
}
