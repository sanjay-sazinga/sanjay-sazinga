import { CommonModule } from '@angular/common';
import { Component, OnInit, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-temporary',
  templateUrl: './temporary.component.html',
  styleUrls: ['./temporary.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule]
})
export class TemporaryComponent implements OnInit {

  @Input() check;
  check2: string="qwery";
  constructor() { }

  ngOnInit(): void {
    console.log(this.check2)
    console.log("entered")
    console.log(this.check)
  }

}
