export interface ClientOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export interface DocumentOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export interface Client {
  dueDetails: any[]; //dueDetails is getting blank in api type will be mentioned later
  name: string;
  email: string;
  startDate: string;
  endDate?: string;
  __v: number;
  _id: string;
}
