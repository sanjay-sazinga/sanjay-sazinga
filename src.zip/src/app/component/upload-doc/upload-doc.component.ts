import { Component, OnInit, ViewChild } from '@angular/core';
import { UploadDocService } from '../../services/upload-doc.service';
import { DocumentService } from '../../services/document.service';
import { UtilityService } from 'src/app/services/utility.service';
import {
  FileUploadControl,
  FileUploadValidators,
} from '@iplab/ngx-file-upload';
import Swal from 'sweetalert2';
import {
  DocumentOption,
  ClientOption,
  Client,
} from './interfaces/upload-doc.interface';
import { Router } from '@angular/router';
import { ToastrService, ToastContainerDirective } from 'ngx-toastr';
import { ChipOption } from 'src/app/shared/components/chip-options/interfaces/chip-option.interface';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UploadButtonComponent } from 'src/app/shared/components/upload-button/upload-button.component';
import { ChipOptionsComponent } from 'src/app/shared/components/chip-options/chip-options.component';

@Component({
  selector: 'app-upload-doc',
  templateUrl: './upload-doc.component.html',
  styleUrls: ['./upload-doc.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,UploadButtonComponent,ChipOptionsComponent]
})
export class UploadDocComponent implements OnInit {
  basicDisabledFilter: ClientOption = {
    value: '-1',
    label: 'Select below . . .',
    disabled: true,
  };
  clientList: ClientOption[] = [];
  selectedClient: string;
  documentTypes: DocumentOption[] = [];
  uploadedFiles: File[] = [];
  allDocTypes: ClientOption[] = [];
  allClientTypes: string[] = [];
  error: boolean;
  clientExtract: Client[];
  @ViewChild(ToastContainerDirective, { static: true })
  toastContainer: ToastContainerDirective;
  fileUploadControl = new FileUploadControl(
    null,
    FileUploadValidators.filesLimit(5)
  );
  configDocumentParams: Record<string, ChipOption>;
  selectedFilters: Record<string, string[]>;

  constructor(
    private uploadDocService: UploadDocService,
    private documentService: DocumentService,
    private utilityService: UtilityService,
    private router: Router,
    private toast: ToastrService
  ) {}

  ngOnInit(): void {
    this.toast.overlayContainer = this.toastContainer;
    this.getClientList();
    this.getConfigDocumentParams();
  }

  async getClientList() {
    try {
      const clientList = await this.documentService.getAllClients();
      if (clientList) {
        this.clientExtract = clientList;
        this.clientList = [this.basicDisabledFilter];
        this.selectedClient = clientList[0]?.name;
        clientList.forEach((item) => {
          this.clientList.push({
            label: item.name,
            value: item.name,
          });
          this.allClientTypes.push(item.name);
        });
        try {
          const documentTypes = await this.documentService.getConfigs();
          if (documentTypes) {
            this.documentTypes = [this.basicDisabledFilter];
            documentTypes.forEach((item) => {
              this.documentTypes.push({
                label: item.name,
                value: item.name,
              });
              this.allDocTypes.push(item.name);
            });
          }
        } catch (error) {
          this.utilityService.log(
            this.constructor.name,
            'Error Getting Configs',
            error
          );
        }
      }
    } catch (error) {
      this.utilityService.log(
        this.constructor.name,
        'Error Getting Clients',
        error
      );
    }
  }

  async uploadFile(uploadedFiles: File[]) {
    if (!this.selectedClient) {
      Swal.fire({
        title: 'Client not Selected',
        text: 'Please select a Client',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false,
      });
    } else {
      const formData = new FormData();

      if (this.selectedFilters) {
        Object.keys(this.selectedFilters)?.forEach((eachKey) => {
          formData.append(
            eachKey.toString().replace(' ', ''),
            this.selectedFilters[eachKey].toString()
          );
        });
      }

      uploadedFiles.forEach((file) => {
        formData.append('file', file, file.name);
      });

      this.clientExtract.forEach((item) => {
        if (this.selectedClient == item.name) {
          formData.append('clientName', item.name);
          formData.append('client_id', item._id);
        }
      });

      try {
        const response = await this.uploadDocService.uploadDocuments(formData);
        Swal.fire({
          title: 'Success',
          text: response.message,
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
        });
        this.router.navigate(['documents']);
      } catch (error) {
        Swal.fire({
          title: 'Error uploading the Files',
          text: 'Please Try Again!',
          icon: 'error',
          timer: 2500,
          showConfirmButton: false,
        });
      }
    }
  }

  async getConfigDocumentParams() {
    try {
      const response = await this.documentService.getConfigDocumentParams();
      if (response) {
        this.configDocumentParams = response?.data;
      }
    } catch (error) {
      Swal.fire({
        title: 'Error Get Config Document Params',
        text: 'Please Try Again!',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false,
      });
    }
  }

  documentFilterEventHandler(event: Record<string, string[]>) {
    this.selectedFilters = event;
  }
}
