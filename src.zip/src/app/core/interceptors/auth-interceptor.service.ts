import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import {CookieService} from 'ngx-cookie-service';
import { AuthService } from 'src/app/services/auth.service';
@Injectable({
  providedIn: 'root'
})
export class AuthInterceptorService implements HttpInterceptor {

  constructor(private authService: AuthService, private router: Router , private cookies: CookieService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const idToken = this.cookies.get('token');

    if (idToken) {
      const cloned = req.clone({
        headers: req.headers.set('Authorization', 'Bearer ' + idToken)
      });
      return next.handle(cloned).pipe(tap(),
        catchError((err: HttpErrorResponse) => {
          if (err.status === 401) {
            this.authService.logout();
            this.router.navigateByUrl('/login');
          }
          return throwError(err.error);
        }));
    } else {
      return next.handle(req).pipe(tap(),
        catchError((err: HttpErrorResponse) => {
          if (err.status === 401) {
            this.authService.logout();
            this.router.navigateByUrl('/login');
          }
          return throwError(err.error);
        }));
    }
  }
}
