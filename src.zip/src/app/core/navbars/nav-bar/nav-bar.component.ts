import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  AfterViewInit,
  Output,
} from '@angular/core';
import { GradientConfig } from '../../../app-config';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { filter, map } from 'rxjs/operators';
import { DocumentService } from 'src/app/services/document.service';
import { Subscription } from 'rxjs';
import { UserService } from '../../../services/user.service';
import { CommonModule } from '@angular/common';
import { NavRightComponent } from './nav-right/nav-right.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatMenuModule } from '@angular/material/menu';
import { MatTabsModule } from '@angular/material/tabs';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { BreadcrumbComponent } from 'src/app/shared/components/breadcrumb/breadcrumb.component';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    NavRightComponent,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatTabsModule,
    MatDialogModule,
    MatMenuModule,
    BreadcrumbComponent,
  ],
})
export class NavBarComponent implements OnInit, AfterViewInit {
  public gradientConfig: any;
  public menuClass: boolean;
  public collapseStyle: string;
  public windowWidth: number;
  public projectName: string;
  public parentObject: any;
  public currentUser: any;
  public pageBoolean: any = {
    dashboardPage: false,
    screeningPage: false,
    documentsPage: false,
    summaryPage: false,
    uploadFiles: false,
    userAdmin: false,
  };
  public summaryPage: boolean;
  public manageUser = false;
  public manageClient = false;
  public manageRole = false;
  public subscription: Subscription;
  public browserRefresh: any;
  public collapsed = true;
  public navVisibility = true;

  @Output() onNavCollapse = new EventEmitter();
  @Output() onNavHeaderMobCollapse = new EventEmitter();
  path: Location;

  constructor(
    private userService: UserService,
    private route: Router,
    private documentService: DocumentService,
    private localStorageService: LocalStorageService
  ) {
    this.gradientConfig = GradientConfig.config;
    this.menuClass = false;
    this.collapseStyle = 'none';
    this.windowWidth = window.innerWidth;
    this.projectName = this.gradientConfig.projectName;

    this.subscription = route.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const arr = event.url.split('/');
        if (event.url.includes('/Screening')) {
          const previousData = JSON.parse(
            this.localStorageService.getItem('documentData')
          );
          this.browserRefresh = event.url;
          if (previousData && previousData.currentURL == this.browserRefresh) {
            this.pageBoolean.screeningPage = true;
            this.pageBoolean.summaryPage = false;
            this.parentObject = previousData.title;
          } else if (event.url.includes('/Screening')) {
            this.pageBoolean.summaryPage = false;
            this.pageBoolean.screeningPage = true;
            this.pageBoolean.documentsPage = false;
            this.pageBoolean.dashboardPage = false;
            this.pageBoolean.uploadFiles = false;
            this.pageBoolean.userAdmin = false;
          }
        } else if (
          (arr[1] === 'documents' && arr[2] !== 'summary') ||
          arr[1] == 'home'
        ) {
          this.pageBoolean.documentsPage = true;
          this.pageBoolean.screeningPage = false;
          this.pageBoolean.userAdmin = false;
          this.pageBoolean.dashboardPage = false;
          this.pageBoolean.uploadFiles = false;
        } else if (arr[2] === 'summary' && arr[3] !== 'screening') {
          this.pageBoolean.summaryPage = true;
          this.pageBoolean.screeningPage = false;
          this.pageBoolean.homePage = false;
          this.pageBoolean.userAdmin = false;
          this.pageBoolean.documentsPage = false;
        } else if (event.url.includes('/dashboard')) {
          this.pageBoolean.dashboardPage = true;
          this.pageBoolean.screeningPage = false;
          this.pageBoolean.documentsPage = false;
          this.pageBoolean.uploadFiles = false;
          this.pageBoolean.userAdmin = false;
        } else if (event.url.includes('/upload')) {
          this.pageBoolean.uploadFiles = true;
          this.pageBoolean.screeningPage = false;
          this.pageBoolean.dashboardPage = false;
          this.pageBoolean.documentsPage = false;
          this.pageBoolean.userAdmin = false;
        } else if (event.url.includes('/admin')) {
          this.pageBoolean.uploadFiles = false;
          this.pageBoolean.screeningPage = false;
          this.pageBoolean.dashboardPage = false;
          this.pageBoolean.documentsPage = false;
          this.pageBoolean.userAdmin = true;
          this.manageRole = false;
          this.manageClient = false;
          this.manageUser = false;
          if (arr[2] == 'users') {
            this.manageUser = true;
          } else if (arr[2] == 'roles') {
            this.manageRole = true;
          } else if (arr[2] == 'clients') {
            this.manageClient = true;
          }
        }
      }
    });
  }

  ngOnInit() {
    this.userService.getCurrentUser().then((resp) => {
      this.currentUser = resp;
      //resolve(this.currentUser);
    });

    this.route.events
      .pipe(
        filter((event) => event instanceof NavigationStart),
        map((event) => event as NavigationStart)
      )
      .subscribe((e) => {
        if (e.url.includes('Screening')) {
          this.pageBoolean.homePage = false;
          this.pageBoolean.documentsPage = false;
          this.pageBoolean.summaryPage = true;
          const location = e.url.split('/');

          this.documentService
            .getDocumentParentById(location[location.length - 1])
            .then((resp) => {
              this.parentObject = resp.ParentDoc.DocumentName.toUpperCase();

              const toBeSaved = {
                currentURL: e.url,
                title: this.parentObject,
              };

              this.localStorageService.setItem(
                'documentData',
                JSON.stringify(toBeSaved)
              );
            });
        } else {
          // localStorage.removeItem('documentData');
          this.pageBoolean.summaryPage = false;
        }
      });
  }

  ngAfterViewInit(): void {
    const realWidth = window.screen.width * window.devicePixelRatio;
    const realHeight = window.screen.height * window.devicePixelRatio;

    const elm = document.getElementById('navMenuText');

    if (realWidth <= 1366) {
      this.onNavCollapse.emit();
      // this.collapsed = false;
      this.navVisibility = false;
      elm.style.marginLeft = '40px';
    } else {
      this.navVisibility = true;
    }
  }

  toggleMobOption() {
    this.menuClass = !this.menuClass;
    this.collapseStyle = this.menuClass ? 'block' : 'none';
  }

  navCollapse() {
    this.collapsed = !this.collapsed;

    if (this.windowWidth >= 992) {
      this.onNavCollapse.emit();
    } else {
      this.onNavHeaderMobCollapse.emit();
    }
  }
}
