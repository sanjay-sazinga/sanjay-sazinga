import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-search',
  templateUrl: './nav-search.component.html',
  styleUrls: ['./nav-search.component.scss'],
  standalone:true,
  imports:[CommonModule]
})
export class NavSearchComponent implements OnInit {
  public searchOn: boolean;

  constructor() {
    this.searchOn = false;
  }

  ngOnInit() { }

}
