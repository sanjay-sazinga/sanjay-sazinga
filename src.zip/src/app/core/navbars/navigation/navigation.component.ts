import { CommonModule } from '@angular/common';
import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { GradientConfig } from 'src/app/app-config';
import { NavContentComponent } from './nav-content/nav-content.component';
import { NavItemComponent } from './nav-content/nav-item/nav-item.component';
import { NavCollapseComponent } from './nav-content/nav-collapse/nav-collapse.component';
import { NavGroupComponent } from './nav-content/nav-group/nav-group.component';
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss'],
  standalone:true,
  imports:[CommonModule,NavContentComponent,NavItemComponent,NavCollapseComponent,
    NavGroupComponent,NgbNavModule]

})
export class NavigationComponent implements OnInit {
  public windowWidth: number;
  public gradientConfig: any;
  @Output() onNavMobCollapse = new EventEmitter();
  @Input() navCollapsed;
  @Input() navigationHover;

  constructor() {
    this.gradientConfig = GradientConfig.config;
    this.windowWidth = window.innerWidth;
  }

  ngOnInit() {}

  navMobCollapse() {
    if (this.windowWidth < 992) {
      this.onNavMobCollapse.emit();
    }
  }
}
