import { Injectable } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
export interface NavigationItem {
  id: string;
  title: string;
  name: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

const NavigationItems = [
  {
    id: 'navigation',
    title: 'Navigation',
    type: 'group',
    icon: 'feather icon-monitor',
    children: [
      {
        id: 'documents',
        title: 'Documents',
        type: 'item',
        icon: 'feather icon-file-text',
        url: '/documents',
        name: 'Document Listing',
      },
      {
        id: 'dashboard',
        title: 'Dashboard',
        type: 'item',
        icon: 'feather icon-bar-chart-2',
        url: '/dashboard',
        name: 'Dashboard',
        // breadcrumbs: false
      },
      {
        id: 'upload',
        title: 'Upload Files',
        type: 'item',
        icon: 'feather icon-upload',
        url: '/upload',
        name: 'Document Upload',
        // breadcrumbs: false
      },

      {
        id: 'userAdmin',
        title: 'Admin',
        type: 'collapse',
        icon: 'feather icon-user',
        children: [
          {
            id: 'users',
            title: 'Users',
            type: 'item',
            url: '/admin/users',
          },
          {
            id: 'roles',
            title: 'Roles',
            type: 'item',
            url: '/admin/roles',
          },
          {
            id: 'clients',
            title: 'Clients',
            type: 'item',
            url: '/admin/clients',
          },
        ],
      },
    ],
  },
];
const childNavigationList = [
  {
    id: 'documents',
    title: 'Documents',
    type: 'group',
    icon: 'feather icon-file-text',
    url: '/documents',
    name: 'Document Listing',
    children: [
      {
        id: 'summary',
        title: 'Summary Page',
        type: 'item',
        url: '/documents/summary/',
        children: [
          {
            id: 'Screening',
            title: 'Screening',
            type: 'item',
            url: '/documents/summary/:documentId/Screening/:childDocumentId',
          },
        ],
      },
    ],
  },
];

@Injectable()
export class NavigationItem {
  public get() {
    return NavigationItems;
  }
  public getChild() {
    return childNavigationList;
  }
}
