import { Component, NgZone, OnInit } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { GradientConfig } from 'src/app/app-config';
import { RouterModule } from '@angular/router';
import { NavBarComponent } from 'src/app/core/navbars/nav-bar/nav-bar.component';
import { NavLeftComponent } from 'src/app/core/navbars/nav-bar/nav-left/nav-left.component';
import { NavSearchComponent } from 'src/app/core/navbars/nav-bar/nav-left/nav-search/nav-search.component';
import { NavRightComponent } from 'src/app/core/navbars/nav-bar/nav-right/nav-right.component';
import { NavCollapseComponent } from 'src/app/core/navbars/navigation/nav-content/nav-collapse/nav-collapse.component';
import { NavContentComponent } from 'src/app/core/navbars/navigation/nav-content/nav-content.component';
import { NavGroupComponent } from 'src/app/core/navbars/navigation/nav-content/nav-group/nav-group.component';
import { NavItemComponent } from 'src/app/core/navbars/navigation/nav-content/nav-item/nav-item.component';
import { NavigationComponent } from 'src/app/core/navbars/navigation/navigation.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { BreadcrumbComponent } from 'src/app/shared/components/breadcrumb/breadcrumb.component';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  standalone:true,
  imports:[CommonModule,
  ConfigurationComponent,
    RouterModule,
    NavBarComponent,
    NavigationComponent,
    NavItemComponent,
    NavBarComponent,
    NavLeftComponent,
    NavSearchComponent,
    NavRightComponent,
    NavContentComponent,
    NavGroupComponent,
    NavCollapseComponent,
    BreadcrumbComponent]
})
export class AdminComponent implements OnInit {
  public gradientConfig: any;
  public navCollapsed: boolean;
  public navCollapsedMob: boolean;
  public windowWidth: number;

  constructor(private zone: NgZone, private location: Location) {
    this.gradientConfig = GradientConfig.config;
    let currentURL = this.location.path();
    const baseHerf = this.location['_baseHref'];
    if (baseHerf) {
      currentURL = baseHerf + this.location.path();
    }

    this.windowWidth = window.innerWidth;

    if (currentURL === baseHerf + '/layout/collapse-menu'
      || currentURL === baseHerf + '/layout/box'
      || (this.windowWidth >= 992 && this.windowWidth <= 760)) {
      this.gradientConfig.collapseMenu = true;
    }

    this.navCollapsed = (this.windowWidth >= 992) ? this.gradientConfig.collapseMenu : false;
    this.navCollapsedMob = false;

  }

  ngOnInit() {
    if (this.windowWidth < 992) {
      this.gradientConfig.layout = 'vertical';
      setTimeout(() => {
        document.querySelector('.pcoded-navbar').classList.add('menupos-static');
        (document.querySelector('#nav-ps-gradient-able') as HTMLElement).style.maxHeight = '100%'; // 100% amit
      }, 500);
    }
  }

  navMobClick() {
    if (this.windowWidth < 992) {
      if (this.navCollapsedMob && !(document.querySelector('app-navigation.pcoded-navbar').classList.contains('mob-open'))) {
        this.navCollapsedMob = !this.navCollapsedMob;
        setTimeout(() => {
          this.navCollapsedMob = !this.navCollapsedMob;
        }, 100);
      } else {
        this.navCollapsedMob = !this.navCollapsedMob;
      }
    }
  }

}
