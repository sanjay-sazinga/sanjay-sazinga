import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from "@angular/material/button";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatSelectModule } from "@angular/material/select";
import { MatRadioModule } from "@angular/material/radio";
import { MatTooltipModule } from "@angular/material/tooltip"
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatIconModule } from "@angular/material/icon";
import { MatTreeModule } from '@angular/material/tree';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatNativeDateModule } from "@angular/material/core"
import { MatMomentDateModule, MomentDateAdapter } from "@angular/material-moment-adapter";

import { MatSortModule } from '@angular/material/sort';
@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatToolbarModule,
        MatSidenavModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatRadioModule,
        MatDatepickerModule,
        MatProgressBarModule,
        MatTooltipModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatIconModule,
        MatTreeModule,
        MatChipsModule,
        MatNativeDateModule,

        MatMomentDateModule,
        MatSortModule


    ],
    exports: [
        CommonModule,
        MatButtonModule,
        MatToolbarModule,
        MatSidenavModule,
        MatInputModule,
        MatFormFieldModule,
        MatSelectModule,
        MatRadioModule,
        MatDatepickerModule,
        MatTooltipModule,
        MatPaginatorModule,
        MatIconModule,
        MatTreeModule,
        MatIconModule,
        MatButtonModule,
        MatChipsModule,
        MatProgressBarModule,
        MatNativeDateModule
    ],
    providers: [
        MatDatepickerModule,
    ]
})

export class AngularMaterialModule { }
