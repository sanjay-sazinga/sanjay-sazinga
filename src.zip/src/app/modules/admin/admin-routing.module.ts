import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { AuthGuard } from '../../services/auth.guard';
 const adminRoutes: Routes = [
  {
    path: 'users',
    data: {title: "Admin", name:"Manage Users"},
    loadComponent:()=> import('../../component/admin/user/user.component').then(mod => mod.UserComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'roles',
    data: {title: "Admin", name:"Manage Roles"},
    loadComponent:()=> import('../../component/admin/role/role.component').then(mod => mod.RoleComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'clients',
    data: {title: "Admin", name:"Manage Clients"},
    loadComponent:()=> import('../../component/admin/client/client.component').then(mod => mod.ClientComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'editsubrole/:id',
    data: {title: "Admin", name:"Manage Subroles"},
    loadComponent:()=> import('../../component/admin/role/sub-role/sub-role.component').then(mod => mod.SubRoleComponent),

    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {
}
