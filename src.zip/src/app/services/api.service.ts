import {environment} from "../../environments/environment";
import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {map} from "rxjs/operators";
import {dummy_data, test_data} from "../../assets/dummy_data"

const SERVER_URL = environment.serverUrl;

@Injectable({
  providedIn: "root"
})
export class ApiService {

  constructor(private http: HttpClient) {
  }

  getDummyData(): Promise<any> {
    return new Promise((resolve, reject)=> {
      resolve(test_data["results"]);
    })
  }

  get(urlAddress: string, options?: any): Promise<any> {
    options = options || {};
    return new Promise((resolve, reject) => {
      this.http
        .get<any>(SERVER_URL + urlAddress)
        .pipe(map(data => data)).subscribe(response => {
        resolve(response);
      }, error => {
        reject(error);
      });
    });
  }

  post(urlAddress: string, payload: any, options?: any): Promise<any> {
    options = options || {};
    return new Promise((resolve, reject) => {
      this.http
        .post<any>(SERVER_URL + urlAddress, payload, options)
        .pipe(map(data => data)).subscribe(response => {
          resolve(response);
        }, error => {
          reject(error);
        });
    });
  }

  put(urlAddress: string, payload: any, options?: any): Promise<any> {
    options = options || {};
    return new Promise((resolve, reject) => {
      this.http
        .put<any>(SERVER_URL + urlAddress, payload, options)
        .pipe(map(data => data)).subscribe(response => {
        resolve(response);
      }, error => {
        reject(error);
      });
    });
  }

  delete(urlAddress: string, options?: any): Promise<any> {
    options = options || {};
    return new Promise((resolve, reject) => {
      this.http
        .delete<any>(SERVER_URL + urlAddress)
        .pipe(map(data => data)).subscribe(response => {
        resolve(response);
      }, error => {
        reject(error);
      });
    });
  }
}
