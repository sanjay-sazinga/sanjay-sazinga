import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from "./auth.service";
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  loggedIn: string= "false";
  constructor (private authService: AuthService, private router: Router, private userService: UserService){}

 canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if(this.authService.isAuthenticated()){
    //   console.log(next.data.name)
     //   console.log(state.url)
      // return true;

        let access:any;

    this.userService.checkPageAcess(next.data.name).then((resp)=>
  {
     access= resp;
  //   console.log("service response")
     if(!access)
     {
      this.router.navigate(['documents']);
     }
  }
  );
 // console.log(access)

  return access;
    console.log("Auth guard check")
   // console.log(access)
   // return access;
    //  console.log(isAccessible)

      // if(isAccessible)
      //   {
      //     return true;

      //   }
      //   else
      //   {
      //     console.log("not accesible")
      //     return false;
      //   }


      }
      else{
        this.router.navigate(['login']);
      }
  }

}
