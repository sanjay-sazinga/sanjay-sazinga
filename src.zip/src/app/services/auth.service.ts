import { Injectable } from '@angular/core';
import { ApiService } from "../services/api.service";
import { UserService } from "./user.service";
import * as moment from 'moment';
import {Router} from '@angular/router';
import {CookieService} from 'ngx-cookie-service';
import { LocalStorageService } from './local-storage.service';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private _currentUser: any;

  constructor(private apiService: ApiService, private userService: UserService,  private cookies: CookieService, private router: Router,
    private localStorageService:LocalStorageService) {
  }

  public get currentUser(): any {
    return this._currentUser;
  }

  public set currentUser(user: any) {
    this._currentUser = user;
  }

  public isAuthenticated(): boolean {
   // console.log("Token")
   // console.log(this.cookies.get('token'))
   // console.log(this.router.url)

    if (this.cookies.get('token')) {
      const loggedOn = this.localStorageService.getItem('isLoggedIn');
      this.currentUser = this.localStorageService.getItem("user");
      if (loggedOn == "true" && this.currentUser) {
        return true;
      }
    }
    else {
      this.localStorageService.clearStorage();
      return false;
    }
  }

  sendToken(user: any): Promise<any> {
    return this.apiService.post('/api/users/token', { email: user.email });
  }

  deleteToken(): Promise<any> {
    return this.apiService.post('/api/users/deleteToken', null);
  }

  private setSession(authResult: any): void {
   // console.log("Auth result")
   // console.log(authResult)
    // Default 2 hours - 60 seconds * 120 minutes
    const expiresAt = moment().add(authResult.tokenExpiryTime || 60 * 120, 'second');
  //  console.log("cookies store")

    this.cookies.set('token',authResult.token)
    this.localStorageService.setItem('isLoggedIn', "true");
   // localStorage.setItem('id_token', authResult.token);
   this.localStorageService.setItem('expires_at', JSON.stringify(expiresAt.valueOf()));
  }

  private getExpiration(): any {
    const expiration = this.localStorageService.getItem('expires_at');
    const expiresAt = JSON.parse(expiration);
    return moment(expiresAt);
  }

  public logout(): void {

    this.cookies.deleteAll();
    this.localStorageService.removeItem('expires_at');
    this.localStorageService.removeItem('user');
    this.localStorageService.removeItem('isLoggedIn');
    this.localStorageService.clearStorage();

    this.currentUser = null;
  }

  public isLoggedIn(): boolean {
    return moment().isBefore(this.getExpiration());
  }

  public isLoggedOut(): boolean {
    return !this.isLoggedIn();
  }

  login(user: any) {
    return new Promise((resolve, reject) => {
      this.apiService.post('/auth/local', {
        email: user.email,
        password: user.password
      }).then((data) => {
        this.setSession(data);
        this.userService.getCurrentUser().then((resp) => {
          this.currentUser = resp;
          resolve(this.currentUser);
        });
      }).catch((err) => {
       // this.logout();
        reject(err);
      });
    });
  }

  sendResetMail(userInfo) {
    return this.apiService.post('/password/forgot', userInfo);
  }

  checkResetPasswordToken(token: string) {
    return this.apiService.post('/password/validate', { token: token });
  }

  resetPasswordByToken(newPassword, confirmPassword, token) {
    return this.apiService.post('/password/reset', {
      newPassword: newPassword,
      confirmPassword: confirmPassword,
      token: token
    });
  }

  generateToken(email: string) {
    return this.apiService.post('/password/generate', {
      email: email
    });
  }
}
