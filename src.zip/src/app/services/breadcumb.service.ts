import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

export interface Breadcrumb {
  parentTitle: string;
  parentUrl: string;
  childTitle: string;
  childUrl: string;
}

@Injectable({
  providedIn: 'root',
})
export class BreadcrumbService {
  breadCrumb!: Breadcrumb;
  breadcrumbs = new BehaviorSubject(this.breadCrumb);
  navSubMenu = new BehaviorSubject('');

  getNavSubMenu() {
    return this.navSubMenu;
  }
  setNavSubMenu(reqObject: string) {
    this.navSubMenu.next(reqObject);
  }
}
