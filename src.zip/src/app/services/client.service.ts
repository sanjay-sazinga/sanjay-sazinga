import {Injectable} from '@angular/core';
import {ApiService} from "./api.service";

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private apiService: ApiService) {
  }

  fetchAllClients(all) {
    return this.apiService.post('/client/getAllClients', all);
  }

  createClient(client) {
    return this.apiService.post('/client/createClient', client);
  }

  editClient(client) {
    return this.apiService.post('/client/editClient', client);
  }

  deleteClient(clientID) {
    return this.apiService.delete('/client/deleteClient/' + clientID);
  }

  restoreClient(clientID) {
    return this.apiService.post('/client/restoreClientByID', {clientId: clientID});
  }
}
