import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonDataService {
  private currentPageFilter: any;

  constructor() {
  }

  public set CurrentPageFilter(filter) {
    this.currentPageFilter = filter;
  }

  public get CurrentPageFilter(): any {
    return this.currentPageFilter;
  }
}
