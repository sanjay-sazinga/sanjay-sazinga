import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../services/api.service';

@Injectable({
  providedIn: 'root',
})
export class DocumentService {
  constructor(private apiService: ApiService) {}

  getDummyData(): Observable<any> {
    // return test_data["results"];
    return new Observable((observer) => {
      this.apiService.getDummyData().then((data) => {
        observer.next(data);
        observer.complete();
      });
    });
  }

  getAllClients() {
    return this.apiService.post('/client/getAllClients', {});
  }

  getConfigs() {
    return this.apiService.get('/config/getConfigs');
  }

  getDocumentTypes() {
    return this.apiService.get('/config/document-type');
  }

  getAllDocumentsFilters(data: any) {
    data.startDate = new Date(data.startDate);
    data.endDate = new Date(data.endDate);
    return this.apiService.post('/document/getAllDocumentsFilters', data);
  }

  downloadReport(data: any) {
    data.startDate = new Date(data.startDate);
    data.endDate = new Date(data.endDate);
    return this.apiService.post('/document/downloadReport', data, {
      responseType: 'blob',
    });
  }

  getDocumentsByPage(options: any) {
    const searchCategories = JSON.parse(options.searchCategories);
    return this.apiService.post(
      `/documents?limit=${options.limit}&page=${options.page}&search=${options.search}`,
      {
        searchCategories: {
          ClientName: searchCategories.Client,
          DocumentName: searchCategories.fileName,
          UploadedBy: searchCategories.UploadedBy,
          'Date Range': {
            from:
              new Date(options.fromDate).toUTCString() === 'null'
                ? null
                : new Date(options.fromDate).toUTCString(),
            to:
              new Date(options.toDate).toUTCString() === 'null'
                ? null
                : new Date(options.toDate).toUTCString(),
          },
          Status: searchCategories.Status,
          'Document Type': searchCategories['Document Type'],
          Region: searchCategories.region,
        },
        isDeleted: options.isDeleted,
      },
      {
        'Content-Type': 'application/json',
      }
    );
  }

  getDocumentList() {
    return this.apiService.get('/document/getDocumentList');
  }

  getStatusList(): Promise<any> {
    return this.apiService.get('/config/statuses');
  }

  downloadDigitizedDoc(_id: any) {
    return this.apiService.post(
      '/digitizedDocument/downloadDigitizedDoc',
      { data: _id },
      { responseType: 'blob', 'Content-Type': 'application/json' }
    );
  }
  processDocumentByID(_id, type) {
    console.log('api front end process doc');
    return this.apiService.post('/document/processDocumentByID', {
      documentID: _id,
      type: type,
    });
  }
  deleteDocumentByID(_id) {
    return this.apiService.delete('/document/deleteDocumentByID/' + _id);
  }
  restoreDocumentByID(_id) {
    return this.apiService.post('/document/restoreDocumentByID/' + _id, {});
  }
  forceDeleteDocument(Doc_id) {
    return this.apiService.post('/document/forceDeleteDocument/', {
      _id: Doc_id,
    });
  }
  getDocumentByID(_id) {
    return this.apiService.get('/document/getDocumentById/' + _id);
  }

  deleteDocumentByIDs(ids) {
    return this.apiService.post('/document/deleteDocumentsByID/', {
      data: ids,
    });
  }

  getDigitizedDocById(documentID) {
    return this.apiService.post('/digitizedDocument/getDigitizedDocByID/', {
      docId: documentID,
    });
  }

  getDocumentPdfbyId(documentId: string) {
    return this.apiService.get(`/documents/${documentId}/pdf`);
  }

  getDocumentParentById(documentId: string): Promise<any> {
    return this.apiService.get(`/child-documents/${documentId}/summary`);
  }

  getChildDocumentById(childDocumentId: string): Promise<any> {
    return this.apiService.get(`/child-documents/${childDocumentId}`);
  }

  getTableDataById(tableId: string): Promise<any> {
    return this.apiService.get(`/tables/${tableId}`);
  }
  updateChildTableDataById(payload: any): Promise<any> {
    return this.apiService.post(`/tables`,payload);
  }

  updateChildDocument(childDocumentId: string, payload: any): Promise<any> {
    return this.apiService.post(
      `/child-documents/${childDocumentId}/attributes`,
      payload
    );
  }

  documentSummaryOperations(id, type, payload) {
    // return this.apiService.post('/digitizedDocument/updateDocumentPage/', id, type);
    return this.apiService.post('/digitizedDocument/updateDocumentPage/', {
      id: id,
      type: type,
      payload: payload,
    });
  }
  RedigitizeFile(file) {
    return this.apiService.post(
      '/document/copyRedigitizeFileAndStoreDocument',
      {
        file: file,
      }
    );
  }

  getDocsByParentID(id) {
    return this.apiService.post('/digitizedDocument/getDocsByParentID', {
      documentID: id,
    });
  }

  cloneDigitizedDocument(document) {
    return this.apiService.post('/digitizedDocument/cloneDigitizedDocument', {
      document: document,
    });
  }

  deleteDigitizedDocumentByID(_id) {
    return this.apiService.delete(
      '/digitizedDocument/deleteDocumentByID/' + _id
    );
  }

  setComment(type, documentID, comment, status) {
    return this.apiService.post('/digitizedDocument/setComments', {
      type,
      documentID,
      comment,
      status,
    });
  }

  getHighlightedLoanDocs(details) {
    return this.apiService.post('/ocrOutput/getHighlightedLoanDocs', {
      details: details,
    });
  }
  convertToExcel(finalExcelData, filePath, formula, type, sheetNames) {
    return this.apiService.post(
      '/document/convertToExcel',
      {
        excelData: finalExcelData,
        path: filePath,
        formula: formula,
        type: type,
        sheetNames: sheetNames,
      },
      { responseType: 'blob' }
    );
  }

  getConfigDocumentParams() {
    return this.apiService.get('/config/document-params');
  }

  getConfigListingParams() {
    return this.apiService.get('/config/listing-params');
  }

  getImageBlockById(id: string) {
    return this.apiService.get(`/image-blocks/${id}`);
  }
}
