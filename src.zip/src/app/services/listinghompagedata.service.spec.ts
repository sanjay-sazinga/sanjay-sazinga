import { TestBed } from '@angular/core/testing';

import { ListingHompageDataService } from './listinghompagedata.service';

describe('ListinghompagedataService', () => {
  let service: ListingHompageDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ListingHompageDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
