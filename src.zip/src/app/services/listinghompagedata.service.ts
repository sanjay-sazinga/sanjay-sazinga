import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ListingHompageDataService {
  private filters: BehaviorSubject<any> = new BehaviorSubject<any>({
    fromdate: new Date(),
    toDate: new Date(),
    Type: 'none',
    Status: 'none',
    Client: 'none',
    ParentId: [],
  });

  currentfilters = this.filters.asObservable();

  updateFilters(message: any) {
    this.filters.next(message);
  }
}
