import {Injectable} from '@angular/core';
import {ApiService} from "./api.service";

@Injectable({
  providedIn: 'root'
})
export class PageService {

  constructor(private apiService: ApiService) {
  }

  getPageControls(): Promise<any> {
    return this.apiService.get("/api/pages/all");
  }

  listPages(): Promise<any> {
    return this.apiService.get("/api/pages/");
  }
}
