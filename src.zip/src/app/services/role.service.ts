import {Injectable} from '@angular/core';
import {ApiService} from "./api.service";

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private apiService: ApiService) {
  }

  getAll() {
    return this.apiService.get('/api/roles');
  }

  getAllSubRoles(parentRole: string) {
    return this.apiService.get('/api/subRoles/?parentRole=' + parentRole);
  }

  checkNameExist(role: any) {
    return this.apiService.post('/api/roles/checkNameExist', role);
  }

  checkSubRoleNameExist(subRole: any) {
    return this.apiService.post('/api/subRoles/checkName', subRole);
  }

  saveRole(role: any) {
    if (role._id) {
      return this.apiService.post('/api/roles/' + role._id, role);
    } else {
      return this.apiService.post('/api/roles/', role);
    }
  }

  saveSubRole(subRole: any) {
    if (subRole._id) {
      return this.apiService.post('/api/subRoles/' + subRole._id, subRole);
    } else {
      return this.apiService.post('/api/subRoles/', subRole);
    }
  }

  getParentRole(roleId: string) {
    return this.apiService.get('/api/roles/' + roleId);
  }

  deleteRole(roleId: string) {
    return this.apiService.delete('/api/roles/' + roleId);
  }

  deleteSubRole(subRoleId: string) {
    return this.apiService.delete('/api/subRoles/' + subRoleId);
  }

  getSubRole(subRoleId) {
    return this.apiService.get('/api/subRoles/' + subRoleId);
  }

  saveSubRolePriority(role: any) {
    return this.apiService.post('/api/roles/' + role._id + '/saveSubRolePriority', role);
  }
}
