import { Injectable } from '@angular/core';
import { ApiService } from "./api.service";
import { HttpClient } from "@angular/common/http";


@Injectable({
  providedIn: 'root'
})
export class ScreeningService {

  constructor(private apiService: ApiService, private httpClient: HttpClient) {
  }

  getScreeningOptions() {
    return this.apiService.get('/screening/screeningOptions');
  }

  getScreeningList() {
    return this.apiService.get('/screening/screeningList');
  }

  getScreeningResultsFromDL(formData: FormData) {
    return this.apiService.post("/screening/checkDlAndScreen", formData)
  }

  getScreeingResults(name, country, address, searchType, searchList = []) {
    var reqBody =  { name: name, country: country, address: address, searchList: searchList }
    if (searchType == "SANCTION Check") {
      return this.apiService.post("/screening/checkSanctionList",reqBody);
    } else if (searchType == "PEP Check") {
      return this.apiService.post("/screening/checkPepList", reqBody);
    } else if (searchType == "PEP And SANCTION Check") {
      return this.apiService.post("/screening/checkPepSanctionList", reqBody);
    }

  }

  downloadReport(from, to, selectedType) {
    return this.apiService.post("/screening/downloadReport", { from: from, to: to, selectedType: selectedType }, {responseType: 'blob'})
  }

}
