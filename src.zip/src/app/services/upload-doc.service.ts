import { Injectable } from '@angular/core';
import {ApiService} from "./api.service";

@Injectable({
  providedIn: 'root'
})
export class UploadDocService {

  baseApiUrl = "https://file.io"

  constructor(private apiService: ApiService) { }

  uploadFile(formData: FormData) {
    return this.apiService.post("/pipeline/uploadFileAndStoreDocument", formData)
  }

  uploadDocuments(formData:FormData) {
    return this.apiService.post('/pipeline/upload',formData);
  }
}
