import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import {
  ActivatedRoute,
  Router,
  ActivatedRouteSnapshot,
} from '@angular/router';
import { filter } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(
    private apiService: ApiService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {}

  user: any;

  pageFilter: any[] = [];
  isAdmin: boolean;

  currentPage: any;

  save(user: any) {
    // console.log("user service save function")
    //   console.log(user)

    if (user._id) {
      return this.apiService.post('/api/users/update', { user: user });
    } else {
      return this.apiService.post('/api/users/create', { user: user });
    }
  }

  getTwoFactorConfig() {
    return this.apiService.get('/config/getTwoFactorConfig');
  }

  get(userId: string) {
    return this.apiService.get('/api/users/' + userId);
  }

  checkEmailExist(user: any) {
    return this.apiService.get(
      '/api/users/check/emailExist?email=' +
        user.email +
        '&userId=' +
        (user._id || 'temp')
    );
  }

  checkUserExistsByEmail(user: any) {
    return this.apiService.post('/auth/local/checkUserIdPassword', {
      email: user.email,
      password: user.password,
    });
  }

  getUserDetails(user: any) {
    return this.apiService.post('/api/users/findUser', {
      email: user.email,
    });
  }

  getCurrentUser() {
    this.user = this.apiService.get('/api/users/profile/me');
    this.user.then((resp) => {
      if (resp.type != 'Admin') {
        this.pageFilter = resp.roles[0].parentRole.subRoles[0].pageFilters;
        this.isAdmin = false;
      } else {
        this.isAdmin = true;
      }
    });
    return this.user;
  }

  doesUserHaveAccess(url: string, permission: string): boolean {
    if (this.isAdmin) {
      return true;
    }
    const selectedPage = this.pageFilter.find((pg) => pg.url === url);

    if (selectedPage) {
      const allowedComponents = selectedPage.allowedComponent ?? [];
      return allowedComponents.includes(permission) ? true : false;
    }
    return false;
  }

  checkValidComponent(component) {
    //   console.log(this.router.getCurrentNavigation().extras.state);
    if (this.isAdmin) {
      return true;
    } else {
      //console.log(this.router.url)

      const page = this.currentPage;
      //console.log(this.currentPage)

      // this.router.events.subscribe((data) => {
      // //  console.log("sjdjsadhskssdhj")
      //   console.log(data)
      //   if (data instanceof RoutesRecognized) {
      //     console.log( data.state.root.firstChild.data);
      //   }
      // });

      // console.log( this.activatedRoute.snapshot.data);

      // this.activatedRoute.data.subscribe(data => {
      //   console.log(data)
      //  })
      // console.log("frontend caalling")
      // console.log(this.pageFilter)
      //  console.log()

      let selectedPage: any;
      selectedPage = this.pageFilter.filter((pg) => pg.name == page);
      if (selectedPage.length == 0) {
        //console.log("page not  found")
        return false;
      }
      // console.log(selectedPage)
      const allowedComponents = selectedPage[0].allowedComponent;
      //console.log(allowedComponents)
      if (allowedComponents.includes(component)) {
        return true;
      } else {
        return false;
      }
    }
  }

  async checkPageAcess(pageName) {
    this.currentPage = pageName;
    this.user = this.apiService.get('/api/users/profile/me');
    await this.user.then((resp) => {
      if (resp.type != 'Admin') {
        this.pageFilter = resp.roles[0].parentRole.subRoles[0].pageFilters;
        this.isAdmin = false;
      } else {
        this.isAdmin = true;
      }
    });
    if (this.isAdmin) {
      return true;
    } else {
      let selectedPage: any;
      // console.log("check page ")
      // console.log(pageName)
      // console.log(this.user)
      // console.log(this.pageFilter)
      selectedPage = this.pageFilter.filter((pg) => pg.name == pageName);
      // console.log(selectedPage)
      if (selectedPage.length == 0) {
        // console.log("page not  found")
        return false;
      } else {
        return true;
      }
    }
  }

  getAll() {
    return this.apiService.get('/api/users/');
  }

  deleteUser(userId: string) {
    return this.apiService.delete('/api/users/' + userId);
  }

  activateUser(emailId: string) {
    return this.apiService.put('/api/users/' + emailId, null);
  }

  getAnalysts() {
    return this.apiService.get('/api/users/analysts');
  }

  getNavText() {
    return this.apiService.get('/config/getnavText');
  }
}
