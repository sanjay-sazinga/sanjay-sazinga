import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChipOptionsComponent } from './chip-options.component';

describe('ChipOptionsComponent', () => {
  let component: ChipOptionsComponent;
  let fixture: ComponentFixture<ChipOptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChipOptionsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChipOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});