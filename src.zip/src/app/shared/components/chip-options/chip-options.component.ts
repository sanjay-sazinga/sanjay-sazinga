import {
  Component,
  Input,
  ElementRef,
  SimpleChanges,
  OnChanges,
  AfterViewInit,
  OnInit,
  Inject,
} from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { ChipOption } from './interfaces/chip-option.interface';
import { CommonModule, DOCUMENT } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/material.module';
import { FilterPipe } from 'src/app/shared/pipes/filter.pipe';
import { DatefilterComponent } from '../datefilter/datefilter.component';
import { LocalStorageService } from 'src/app/services/local-storage.service';

@Component({
  selector: 'app-chip-options',
  templateUrl: './chip-options.component.html',
  styleUrls: ['./chip-options.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AngularMaterialModule,
    FilterPipe,
    DatefilterComponent,
  ],
})
export class ChipOptionsComponent implements OnChanges, AfterViewInit ,OnInit{
  @Input() dictionary: Record<string, ChipOption> = {};
  @Input() title: string;
  @Output() filterEvent: EventEmitter<Record<string, string[]>> =
    new EventEmitter<Record<string, string[]>>();
  @Input() isDropdownTogggle: boolean;
  @Input() selectedFilterData:  Record<string, any> = {};
  searchString: string;
  searchStringForSelect: string;
  documentName: string;
  fromDate: Date = null;
  toDate: Date = null;
  filterData: Record<string, any> = {};
  dropdownSettings: IDropdownSettings;
  inputTypesText: Record<string, string> = {};
  objectKeys = Object.keys;
  objectValues = Object.values;

  constructor(private el: ElementRef,private localStorageService: LocalStorageService, @Inject(DOCUMENT) private document: any,) {}
ngOnInit(): void {
  console.log(this.selectedFilterData,"ssssssss")
  if(this.selectedFilterData){
    const item=JSON.parse(this.selectedFilterData.toString())
    Object.keys(item).forEach(
      (eachKey: string) => {
          this.filterData[eachKey]= item[eachKey];
      }
    );
  }
}
  ngOnChanges(changes: SimpleChanges) {
    if (changes['dictionary'] && changes['dictionary'].currentValue) {
      Object.keys(changes['dictionary'].currentValue).forEach(
        (eachKey: string) => {
          this.filterData[eachKey] = [];
          if (this.dictionary[eachKey].type == 'text') {
            this.inputTypesText[eachKey] = '';
          }
          if (this.dictionary[eachKey].type == 'Date') {
            this.filterData['Date'] = [this.fromDate, this.toDate];
          }
        }
      );
    }
  }

  ngAfterViewInit() {
    const accordion = this.el.nativeElement.getElementsByClassName('accordion');
    for (let i = 0; i < accordion.length; i++) {
      accordion[i].onclick = function () {
        hideAll(this);
        this.classList.toggle('active');
        const panel = this.nextElementSibling;
        if (panel.style.maxHeight) {
          this.classList.toggle('active', false);
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + 'px';
        }
        this.nextElementSibling.classList.toggle('show');
      };
    }

    function hideAll(curr) {
      for (let i = 0; i < accordion.length; i++) {
        accordion[i].classList.toggle('active', false);
        if (accordion[i] != curr) {
          accordion[i].nextElementSibling.classList.toggle('show', false);
          const panel = accordion[i].nextElementSibling;
          panel.style.maxHeight = null;
        }
      }
    }
  }

  onSelectCheckBox(event: Event, key: string, value: string) {
    if (event.target['checked']) {
      this.filterData[key].push(value);
    } else {
      const foundIndex = this.filterData[key].findIndex((x) => x === value);
      this.filterData[key].splice(foundIndex, 1);
    }
    this.sendData();
  }

  onCheckBox(event: Event, key: string, value: string) {
    if (event.target['checked']) {
      this.filterData[key].push(value);
    } else {
      const foundIndex = this.filterData[key].findIndex((x) => x == value);
      this.filterData[key].splice(foundIndex, 1);
    }
    this.sendData();
  }
  onMultiSelectCheckBox(event: Event, key: string) {
    this.filterData[key] = event.target['value'];
    this.sendData();
  }

  onEnterTextBox(event: Event, key: string) {
    if (event.target['value']) {
      this.filterData[key] = event.target['value'];
    }
    this.sendData();
  }

  checkOptions(key: string, value: string) {
    return this.filterData[key].includes(value);
  }

  isArray(key) {
    return Array.isArray(this.filterData[key]) ? true : false;
  }

  applyFilter() {
    const accordion = this.el.nativeElement.getElementsByClassName(
      'small-btn btn-default'
    );
    if (accordion) {
      accordion[0]?.nextElementSibling?.classList.toggle('show', false);
      this.sendData();
    }
  }

  clearFilter() {
    Object.keys(this.dictionary).forEach((eachKey: string) => {
      this.filterData[eachKey] = [];
      if (this.dictionary[eachKey].type == 'text') {
        this.inputTypesText[eachKey] = '';
      }
      if (this.dictionary[eachKey].type == 'date') {
        this.fromDate = null;
        this.toDate = null;
        this.filterData['Date'] = [null];
      }
    });
    this.sendData();
  }

  sendData() {
    this.filterEvent.emit(this.filterData);
  }

  removeChips(key: string, value: number) {
    const index = this.filterData[key].findIndex((x) => x == value);
    this.filterData[key].splice(index, 1);
    this.sendData();
  }

  removeTextChips(key: string) {
    this.filterData[key] = [];
    this.inputTypesText[key] = '';
    this.sendData();
  }

  removeDateChips(key: string) {
    this.fromDate = null;
    this.toDate = null;
    this.filterData[key] = [];
    this.sendData();
  }

  onClickDropdownTogggle(event: Event) {
    event.stopPropagation();
  }

  handleDateFilterSelectEvent(event: Event, key: string) {
    if (event['from'] !== undefined) {
      this.fromDate = event['from'];
    }
    if (event['to'] !== undefined) {
      this.toDate = event['to'];
    }
    this.filterData[key] = [this.fromDate, this.toDate];
    this.sendData();
  }
}
