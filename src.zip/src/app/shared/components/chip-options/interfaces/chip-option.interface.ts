export interface ChipOption {
  type: string;
  validation?: string;
  value?: Record<string, string>;
}
