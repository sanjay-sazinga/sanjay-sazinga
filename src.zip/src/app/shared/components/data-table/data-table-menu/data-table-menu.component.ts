import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MenuItem } from '../interfaces/table-action-menu.interface';
import { AngularMaterialModule } from 'src/app/material.module';
import { MatMenuModule } from '@angular/material/menu';
import { ShowIfAuthorizedDirective } from 'src/app/shared/directives/show-if-authorized.directive';

@Component({
  selector: 'app-data-table-menu',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AngularMaterialModule,
    MatMenuModule,
    ShowIfAuthorizedDirective,
  ],
  templateUrl: './data-table-menu.component.html',
  styleUrls: ['./data-table-menu.component.scss'],
})
export class DataTableMenuComponent {
  @Input() menus: MenuItem[];
}
