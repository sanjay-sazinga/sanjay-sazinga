import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  CUSTOM_ELEMENTS_SCHEMA,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { DataTablesModule } from 'angular-datatables';
import {
  Column,
  TableActionItem,
  TableConfiguration,
  SelectRowItem,
} from './interfaces/table-config.interface';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { InternationalizationModule } from 'src/app/core/internationalization/internationlisation.module';
import {
  IDropdownSettings,
  NgMultiSelectDropDownModule,
} from 'ng-multiselect-dropdown';
import { CustomPipe } from './pipes/custom-pipe';
import { DataTableMenuComponent } from './data-table-menu/data-table-menu.component';
import { MenuItem } from './interfaces/table-action-menu.interface';
import { ShowIfAuthorizedDirective } from '../../directives/show-if-authorized.directive';
@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DataTablesModule,
    NgxSkeletonLoaderModule,
    NgxPaginationModule,
    InternationalizationModule,
    NgMultiSelectDropDownModule,
    CustomPipe,
    DataTableMenuComponent,
    ShowIfAuthorizedDirective,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class DataTableComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() columns: Column[] = [];
  @Input() data = [];
  @Input() tableConfiguration: TableConfiguration = {};
  @Input() isLoading!: boolean;
  @Input() totalItemCounts = 0;
  @Input() currentPage = 1;
  @Input() itemsPerPage = 10;
  @Output() cellClickEvent: EventEmitter<unknown> = new EventEmitter();
  @Output() pageChangeClickEvent: EventEmitter<unknown> = new EventEmitter();
  @Output() changePageSizeClickEvent: EventEmitter<unknown> =
    new EventEmitter();
  @Output() selectedRowIndexEvent: EventEmitter<SelectRowItem> =
    new EventEmitter();
  @Output() mouseEnterEvent: EventEmitter<unknown> = new EventEmitter();
  @Output() mouseLeaveEvent: EventEmitter<unknown> = new EventEmitter();

  @Output() actionEvent: EventEmitter<TableActionItem> =
    new EventEmitter<TableActionItem>();

  // callback function
  @Input() customCellBackgoundColor: (args: any) => string;
  @Input() customCellColor: (args: any) => string;
  @Input() customCellClass: (args: any) => string;
  @Input() actionButtonHideShow: (args: any) => boolean = () => true;
  @ViewChild(DataTableDirective, { static: false })
  private datatableElement!: DataTableDirective;
  columnDropdownSettings: IDropdownSettings = {};
  selectedDropdown = [];
  columnDropdownList = [];
  public tableData = [];
  public dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  selectedRowIndexes: boolean[] = [];
  isSelectAllRows: boolean;
  currentPageNo = 1;
  currentPageSize = 10;
  totalRecords = 0;
  tableActionMenu: MenuItem[] = [];
  tableBorderClass = 'table-border';

  ngOnInit() {
    this.initializeTable();
    this.initializeMenu();
  }

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges?.data?.currentValue) {
      if (this.tableConfiguration.pagination == undefined) {
        this.tableConfiguration.pagination = true;
      }
      this.tableData = simpleChanges?.data.currentValue;
      this.totalRecords =
        this.totalItemCounts == 0
          ? this.tableData.length
          : this.totalItemCounts;
      this.currentPageNo = this.currentPage;
      this.currentPageSize = this.itemsPerPage;
      if (this.tableConfiguration.selectable) {
        this.selectedRowIndexes = new Array(this.tableData.length).fill(false);
      }
      this.tableActionMenu.forEach((menu: MenuItem) => {
        menu.disabled = this.selectedRowIndexes.indexOf(true) === -1;
      });
      this.datatableElement?.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.destroy();
        this.dtTrigger.next(this.dtOptions);
      });
    }
  }

  initializeTable() {
    const columnDefs = [];
    if (this.tableConfiguration.selectable) {
      columnDefs.push({
        targets: 0,
        orderable: false,
      });
    }
    this.columns?.forEach((col: Column, index: number) => {
      if (col.orderable == false) {
        columnDefs.push({
          targets: this.tableConfiguration.selectable ? index + 1 : index,
          orderable: false,
        });
      }
    });
    if (this.tableConfiguration.rowActions) {
      columnDefs.push({
        targets: this.tableConfiguration.selectable
          ? this.columns.length + 1
          : this.columns.length,
        orderable: false,
      });
    }
    this.dtOptions = {
      paging: false,
      info: false,
      searching: this.tableConfiguration.searching ?? false,
      columnDefs: columnDefs,
      autoWidth: false,
    };
    if (this.tableConfiguration.columnShowHideDropdown) {
      this.columnDropdownSettings = {
        idField: 'item_id',
        textField: 'item_text',
        allowSearchFilter: true,
        itemsShowLimit: 1,
      };
      this.columns.forEach((col) => {
        this.columnDropdownList.push({
          item_id: col.field,
          item_text: col.title,
        });
      });
      this.selectedDropdown = this.columnDropdownList;
    }
    let tableBorderClass = '';
    if (this.tableConfiguration.borders) {
      if (typeof this.tableConfiguration.borders === 'boolean') {
        tableBorderClass = 'table-border';
      } else {
        if (this.tableConfiguration.borders.top) {
          tableBorderClass = 'table-border-top';
        }
        if (this.tableConfiguration.borders.right) {
          tableBorderClass = `${tableBorderClass} table-border-right`;
        }
        if (this.tableConfiguration.borders.bottom) {
          tableBorderClass = `${tableBorderClass} table-border-bottom`;
        }
        if (this.tableConfiguration.borders.left) {
          tableBorderClass = `${tableBorderClass} table-border-left`;
        }
      }
    } else {
      tableBorderClass = '';
    }
    this.tableBorderClass = tableBorderClass;
  }

  initializeMenu() {
    const actionMenu: MenuItem[] = [];
    if ((this.tableConfiguration.tableActions ?? []).length > 0) {
      actionMenu.push(...this.tableConfiguration.tableActions);
    }

    this.tableActionMenu = actionMenu;
  }
  onAction(action: string, data: any) {
    const tableActionItem = {
      action: action,
      row: data,
    };
    this.actionEvent.emit(tableActionItem);
  }

  onPageChange = (event: number) => {
    this.currentPage = event;
    this.pageChangeClickEvent.emit(event);
  };
  fetchPaginatedData = (event: any) => {
    this.itemsPerPage = event;
    this.currentPage = 1;
    this.changePageSizeClickEvent.emit(event);
  };

  onCellClick(data: any, column: string) {
    this.cellClickEvent.emit({ data, column });
  }

  ngAfterViewInit() {
    this.dtTrigger.next();
  }

  onItemSelect() {
    this.columnHideShow();
  }
  onItemDeSelect() {
    this.columnHideShow();
  }
  onSelectAll() {
    this.columnHideShow();
  }
  onUnSelectAll() {
    this.columnHideShow();
  }

  columnHideShow() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.columns().visible(true);
      this.columnDropdownList.forEach((element, index) => {
        const colIndex = this.selectedDropdown.findIndex(
          (x) => x.item_id == element.item_id
        );
        if (colIndex == -1) {
          if (this.tableConfiguration.selectable) {
            dtInstance.column(index + 1).visible(false);
          } else {
            dtInstance.column(index).visible(false);
          }
        }
      });
    });
  }

  onCustomBackgoundColor(data: any, column: string) {
    return this.customCellBackgoundColor({ data, column });
  }
  onCustomCellColor(data: any, column: string) {
    return this.customCellColor({ data, column });
  }
  onCustomCellClass(data: any, column: string) {
    return this.customCellClass({ data, column });
  }

  handleRowSelectionChange(): void {
    this.isSelectAllRows = this.selectedRowIndexes.indexOf(false) === -1;
    this.onSelectRowEvent();
  }
  selectAllRows(isChecked: boolean) {
    this.selectedRowIndexes = new Array(this.tableData.length).fill(isChecked);
    this.isSelectAllRows = isChecked;
    this.onSelectRowEvent();
  }

  onSelectRowEvent() {
    const selectedRowData: any[] = [];
    for (let i = 0; i < this.selectedRowIndexes.length; i++) {
      if (this.selectedRowIndexes[i]) {
        selectedRowData.push(this.tableData[i]);
      }
    }
    this.selectedRowIndexEvent.emit({
      selectedAllRows: this.isSelectAllRows,
      selectedRowIndexes: this.selectedRowIndexes,
      selectedRowData: selectedRowData,
    });
    this.tableActionMenu.forEach((menu: MenuItem) => {
      menu.disabled = this.selectedRowIndexes.indexOf(true) === -1;
    });
  }

  onMouseEnter(data: any, column: string) {
    this.mouseEnterEvent.emit({ data, column });
  }
  onMouseLeave(data: any, column: string) {
    this.mouseLeaveEvent.emit({ data, column });
  }

  checkDataType(value: any) {
    return typeof value;
  }
}
