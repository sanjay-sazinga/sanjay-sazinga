export interface MenuItem {
  label: string;
  items?: MenuItem[];
  icon?: string;
  disabled?: boolean;
  class?: string;
  action?: () => void;
  permission?: string;
}
