import { MenuItem } from './table-action-menu.interface';

export interface Column {
  field: string | Column[];
  title: string;
  width?: string;
  dataType?: DataType;
  subColumns?: string[]; // if data Type array subColumns need
  orderable?: boolean;
  mouseEvent?: boolean;
  headerClass?: string;
  customStyle?: boolean;
  className?: string;
  clickable?: boolean;
  pipeType?: PipeType;
  pipeFormat?: string;
}

export enum PipeType {
  date = 'date',
}
export enum DataType {
  string = 'string',
  array = 'array',
}

export interface TableConfiguration {
  rowActions?: ActionItem[];
  tableActions?: MenuItem[];
  columnShowHideDropdown?: boolean;
  selectable?: boolean;
  searching?: boolean;
  pagination?: boolean;
  borders?: boolean | Border;
}

export interface ActionItem {
  icon: string;
  action: ActionEnum;
  title?: string;
  tooltip?: string;
  hide?: boolean;
  permission?: string;
}

export enum ActionEnum {
  view = 'view',
  delete = 'delete',
  edit = 'edit',
  save = 'save',
  refresh = 'refresh',
  download = 'download',
  restore = 'restore',
  forcedelete = 'forcedelete',
}

export interface ActionConditionEvent {
  data: any;
  action: string;
}

export interface ColumnStyle {
  data: any;
  column: string;
}

export interface TableActionItem {
  action: string;
  row: any;
}

export interface SelectRowItem {
  selectedAllRows?: boolean;
  selectedRowIndexes?: boolean[];
  selectedRowData?: any;
}

export interface Border {
  top?: boolean;
  right?: boolean;
  bottom?: boolean;
  left?: boolean;
}
