import { DatePipe } from '@angular/common';
import { PipeTransform, Pipe } from '@angular/core';
import { PipeType } from '../interfaces/table-config.interface';

@Pipe({
  name: 'customPipe',
  standalone: true,
})
export class CustomPipe implements PipeTransform {
  constructor(private datePipe: DatePipe) {}
  transform(value: any, pipeType: string, format?: string): any {
    if (pipeType == PipeType.date) {
      return this.datePipe.transform(value, format || 'short');
    }
    return value;
  }
}
