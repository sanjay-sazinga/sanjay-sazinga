import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges
} from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatRippleModule
} from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import * as moment from 'moment';
import { AngularMaterialModule } from 'src/app/material.module';
import { DataFilterPipe } from '../data-table/data-filter.pipe';
import { MatButtonModule } from '@angular/material/button';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL'
  },
  display: {
    dateInput: 'MMM DD YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};
@Component({
  selector: 'app-datefilter',
  templateUrl: './datefilter.component.html',
  styleUrls: ['./datefilter.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,ReactiveFormsModule,
    AngularMaterialModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    DataFilterPipe,
    
  ],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})
export class DatefilterComponent implements OnInit, OnChanges {
  @Input() fdate = new Date();
  @Input() tdate = new Date();
  fromDate = new FormControl(this.fdate);
  toDate = new FormControl(this.tdate);
  DateObj: any = {
    from: new Date(),
    to: new Date()
  };
  @Output() data: EventEmitter<any> = new EventEmitter<any>();

  constructor() {
    //
  }

  ngOnInit(): void {
    // this.fromDate.value.setDate(this.toDate.value.getDate()-100);
    //console.log("fdate")
    //console.log(this.fdate)
    this.fdate = new Date();
    this.tdate =new Date();
    console.log(this.fdate ,"this.fdate")
    this.fromDate = new FormControl(this.fdate);
    this.toDate = new FormControl(this.tdate);
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.fromDate = new FormControl(this.fdate);
    this.toDate = new FormControl(this.tdate);

    this.printdate();
  }

  printdate() {
    //  console.log(this.fromDate.value['_d'])
    //  console.log(this.toDate.value['_d'])
    // this.DateObj['from'] = this.fromDate?.value['_d'];
    // this.DateObj['to'] = this.toDate?.value['_d'];
    // this.data.emit(this.DateObj);
  }
}
