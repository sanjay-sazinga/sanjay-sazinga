import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  OnInit,
  Output,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogConfig,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-block-modal',
  templateUrl: './block-modal.component.html',
  styleUrls: ['./block-modal.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, AngularMaterialModule, MatDialogModule],
})
export class BlockModalComponent implements OnInit {
  @Output() editCellValue = new EventEmitter();
  private readonly _matDialogRef: MatDialogRef<BlockModalComponent>;
  private readonly triggerElementRef: ElementRef;
  isView = false;
  cellValue = '';
  dialogText = '';
  rowData = { Category: '', SSOTKey: '' };
  constructor(
    _matDialogRef: MatDialogRef<BlockModalComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this._matDialogRef = _matDialogRef;
    this.triggerElementRef = data.trigger;
  }

  ngOnInit() {
    this.updatePosition();
    const string = this.data.state;
    this.rowData = this.data.rowData;
    this.dialogText = string.charAt(0).toUpperCase() + string.slice(1);
    this.cellValue = this.data.value;
    this.isView = this.data.isView;
  }

  updatePosition() {
    const matDialogConfig: MatDialogConfig = new MatDialogConfig();
    const rect = this.triggerElementRef.nativeElement.getBoundingClientRect();
    matDialogConfig.position = {
      left: `${rect.left}px`,
      top: `${rect.top}px`,
    };
    this._matDialogRef.updatePosition(matDialogConfig.position);
  }

  onEditCell() {
    this.editCellValue.emit(this.cellValue);
  }
}
