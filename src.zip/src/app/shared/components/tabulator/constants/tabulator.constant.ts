export const TABULATOR_VALUE_TYPES = {
  TABLE: 'table',
  IMAGE: 'image_block',
  ENTITY: 'entity',
  BLOCK: 'block',
};
