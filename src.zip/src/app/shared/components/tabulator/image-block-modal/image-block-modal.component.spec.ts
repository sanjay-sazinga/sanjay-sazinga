import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageBlockModalComponent } from './image-block-modal.component';

describe('ImageBlockModalComponent', () => {
  let component: ImageBlockModalComponent;
  let fixture: ComponentFixture<ImageBlockModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImageBlockModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImageBlockModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
