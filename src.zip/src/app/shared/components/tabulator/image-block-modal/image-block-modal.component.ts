import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  OnInit,
  Output,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogConfig,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AngularMaterialModule } from 'src/app/material.module';
import { DocumentService } from 'src/app/services/document.service';

@Component({
  selector: 'app-image-block-modal',
  templateUrl: './image-block-modal.component.html',
  styleUrls: ['./image-block-modal.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, AngularMaterialModule, MatDialogModule],
})
export class ImageBlockModalComponent implements OnInit {
  @Output() deleteCellValue = new EventEmitter();
  private readonly _matDialogRef: MatDialogRef<ImageBlockModalComponent>;
  private readonly triggerElementRef: ElementRef;
  isView = false;
  cellValue = '';
  dialogText = '';
  imageBase64 = '';
  rowData = { Category: '', SSOTKey: '' };

  constructor(
    _matDialogRef: MatDialogRef<ImageBlockModalComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private documentService: DocumentService
  ) {
    this._matDialogRef = _matDialogRef;
    this.triggerElementRef = data.trigger;
  }

  ngOnInit(): void {
    this.updatePosition();
    this.dialogText = this.data.columnName;
    this.isView = this.data.isView;
    const value = this.data.value;
    this.rowData = this.data.rowData;
    this.getImageBlock(value);
  }
  updatePosition() {
    const matDialogConfig: MatDialogConfig = new MatDialogConfig();
    const rect = this.triggerElementRef.nativeElement.getBoundingClientRect();
    matDialogConfig.position = {
      left: `${rect.left}px`,
      top: `${rect.top}px`,
    };
    this._matDialogRef.updatePosition(matDialogConfig.position);
  }
  async getImageBlock(id: string) {
    try {
      const imageBlockResponse = await this.documentService.getImageBlockById(
        id
      );
      const blobData = imageBlockResponse?.data?.JSONData?.Value || {};
      this.imageBase64 = blobData?.blob
        ? `data:image/;base64,${blobData?.blob}`
        : '';
    } catch (error) {
      console.log(error);
    }
  }

  onDelete() {
    this.deleteCellValue.emit(true);
  }
}
