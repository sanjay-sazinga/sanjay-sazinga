export interface ActionMenu {
  left: MenuItem[];
  right: {
    edit: boolean;
    filter: boolean;
    custom?: MenuItem[];
  };
}

export interface MenuItem {
  label: string;
  items?: MenuItem[];
  icon?: string;
  disabled?: boolean;
  action?: () => void;
}
