import { ColumnComponent, MenuObject, RowComponent } from 'tabulator-tables';

export interface RowContextMenuConfig {
  addRowAbove: boolean;
  addRowBelow: boolean;
  deleteRow: boolean;
  customActions?: MenuObject<RowComponent>[];
}

export interface Column {
  title: string;
  field: string;
  hasTabularData?: boolean;
  columns?: Column[];
  editor?: string;
}

export interface ColumnContextMenuConfig {
  edit: boolean;
  insertLeft: boolean;
  insertRight: boolean;
  delete: boolean;
  customActions?: MenuObject<ColumnComponent>[];
}
