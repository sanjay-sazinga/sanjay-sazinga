import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatMenuModule } from '@angular/material/menu';
import { MatTabsModule } from '@angular/material/tabs';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
  standalone:true,
  imports:[CommonModule,MatExpansionModule,
    MatTabsModule,
    MatDialogModule,
    MatMenuModule,AngularMaterialModule]
})
export class ModalComponent implements OnInit {

  @Output() columnAdded= new EventEmitter<String>();
  
  showInput: Boolean=false;
  colName: string ="";
  dialogText: String= "";

  constructor(public dialog: MatDialog,@Inject(MAT_DIALOG_DATA) public data: any) {  }

  ngOnInit() {
    console.log("on init data=",this.data);
    let string= this.data.state;
    this.dialogText= string.charAt(0).toUpperCase() + string.slice(1);
  }

  onSelectChange(e){
    const value= e.target.value;
    if(value==="none"){
      this.showInput=true;
      this.colName="";
    } else {
      this.showInput=false;
      this.colName=value;
    }
  }

  onSaveColumn(){
    this.columnAdded.emit(this.colName);
  }
  
}
