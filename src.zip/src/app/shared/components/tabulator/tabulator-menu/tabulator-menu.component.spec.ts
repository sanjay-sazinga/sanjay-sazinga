import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabulatorMenuComponent } from './tabulator-menu.component';

describe('TabulatorMenuComponent', () => {
  let component: TabulatorMenuComponent;
  let fixture: ComponentFixture<TabulatorMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TabulatorMenuComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TabulatorMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
