import { Component, Input } from '@angular/core';
import { MenuItem } from '../interfaces/action-menu.interface';
import { MatMenuModule } from '@angular/material/menu';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/material.module';

@Component({
  selector: 'app-tabulator-menu',
  templateUrl: './tabulator-menu.component.html',
  styleUrls: ['./tabulator-menu.component.scss'],
  standalone:true,
  imports:[MatMenuModule,CommonModule,FormsModule,AngularMaterialModule]
})
export class TabulatorMenuComponent {
  @Input() leftMenu: MenuItem[];
  @Input() rightMenu: MenuItem[];
}
