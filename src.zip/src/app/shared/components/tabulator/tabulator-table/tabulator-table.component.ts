import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import {
  CellComponent,
  ColumnComponent,
  ColumnDefinition,
  GroupArg,
  MenuObject,
  MenuSeparator,
  RowComponent,
  RowContextMenuSignature,
} from 'tabulator-tables';
import { TabulatorFull as Tabulator } from 'tabulator-tables';
import {
  Column,
  ColumnContextMenuConfig,
  RowContextMenuConfig,
} from '../interfaces/tabulator-config.interface';
import { MatDialog } from '@angular/material/dialog';
import { ModalComponent } from '../modal/modal.component';
import { TABULATOR_VALUE_TYPES } from '../constants/tabulator.constant';
import { CommonModule } from '@angular/common';
import { BlockModalComponent } from '../block-modal/block-modal.component';
import { ImageBlockModalComponent } from '../image-block-modal/image-block-modal.component';
import { tabulatorInput } from '../utilities/tabulator-input';

@Component({
  selector: 'app-tabulator-table',
  templateUrl: './tabulator-table.component.html',
  styleUrls: ['./tabulator-table.component.scss'],
  standalone: true,
  imports: [CommonModule, BlockModalComponent, ImageBlockModalComponent],
})
export class TabulatorTableComponent implements OnInit, OnChanges {
  @Input() data = [];
  @Input() columns: Column[] = [];
  @Input() rowContextMenuOptions: RowContextMenuConfig = {
    addRowAbove: true,
    addRowBelow: true,
    deleteRow: true,
  };
  @Input() columnContextMenuOptions: ColumnContextMenuConfig = {
    edit: true,
    insertLeft: true,
    insertRight: true,
    delete: true,
  };
  @Input() freezeUptoXRows = 0;
  @Input() freezeUptoXColumns = 0;
  @Input() groupBy: GroupArg;
  @Input() movableColumns = true;
  @Input() movableRows = true;
  @Input() displayFilterInputs = false;
  @Input() isEditMode = false;
  @Input() level: number;
  @Output() tableTypeDoubleClickEvent: EventEmitter<unknown> =
    new EventEmitter();

  @ViewChild('tabulatorTable', { static: true })
  tabulatorTableElementRef: ElementRef;
  tabulatorTable: Tabulator;

  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {
    this.initializeTable();
  }

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges?.columns?.currentValue) {
      const columns = this.getColumns(
        simpleChanges?.columns?.currentValue ?? [],
        this.getColumnContextMenus(this.columnContextMenuOptions),
        this.freezeUptoXColumns
      );
      this.tabulatorTable?.setColumns(columns);
    } else if (
      Object.prototype.hasOwnProperty.call(simpleChanges, 'displayFilterInputs')
    ) {
      const columns = this.getColumns(
        this.columns ?? [],
        this.getColumnContextMenus(this.columnContextMenuOptions),
        this.freezeUptoXColumns
      );
      this.tabulatorTable?.setColumns(columns);
    }
    if (simpleChanges?.data?.currentValue) {
      this.tabulatorTable?.setData(simpleChanges?.data?.currentValue ?? []);
    }
    if (simpleChanges?.groupBy?.currentValue) {
      this.tabulatorTable?.setGroupBy(simpleChanges?.groupBy?.currentValue);
    }
  }

  getColumns(
    columns: any[],
    headerContextMenu:
      | Array<MenuObject<ColumnComponent> | MenuSeparator>
      | undefined,
    freezeUptoXColumns: number
  ): ColumnDefinition[] {
    const updatedColumns: ColumnDefinition[] = columns.map((c, i) => ({
      ...c,
      editable: true,
      editor: function (
        cell: any,
        onRendered: any,
        success: any,
        cancel: any,
        editorParams: any
      ) {
        return tabulatorInput(
          cell,
          onRendered,
          success,
          cancel,
          editorParams,
          this.isEditMode,
          c
        );
      }.bind(this),
      headerContextMenu,
      frozen: i < freezeUptoXColumns,
      minWidth: 200,
      columns: c.columns,
      headerFilter: this.displayFilterInputs ? 'input' : null,
      formatter: c.hasTabularData
        ? function (cell, _formatterParams, _onRendered) {
            const cellValue = cell.getValue();
            const rowValue: any = cell.getData();
            if (
              rowValue?.ValueType?.toLowerCase() === TABULATOR_VALUE_TYPES.TABLE
            ) {
              return 'Table';
            } else if (
              rowValue?.ValueType?.toLowerCase() === TABULATOR_VALUE_TYPES.IMAGE
            ) {
              return 'Image';
            } else {
              return rowValue?.IsModified && cellValue
                ? `<div class="modified-cell">${cellValue}</div>`
                : cellValue;
            }
          }
        : function (cell, _formatterParams, _onRendered) {
            const cellValue = cell.getValue();
            let isModified = false;
            const rowData: any = cell.getData();
            const field = cell.getField()?.split('.')[0];
            const cellValueObject: any = rowData[field];
            if (cellValueObject?.ColumnSSOT) {
              isModified = cellValueObject.IsModified;
            } else {
              isModified = false; // For primary table, we allow edit only on column with hasTabulator = true
            }
            if (
              cellValueObject?.ValueType?.toLowerCase() ===
              TABULATOR_VALUE_TYPES.TABLE
            ) {
              return 'Table';
            } else if (
              cellValueObject?.ValueType?.toLowerCase() ===
              TABULATOR_VALUE_TYPES.IMAGE
            ) {
              return 'Image';
            }
            return isModified && cellValue
              ? `<div class="modified-cell">${cellValue}</div>`
              : cellValue;
          },
      cellDblClick: c.hasTabularData
        ? (e: UIEvent, cell: CellComponent) => {
            const target = new ElementRef(e.currentTarget);
            const field = cell.getField()?.split('.')[0];
            const rowData = cell.getData();
            const cellValue: any = rowData[field];
            let valueType = TABULATOR_VALUE_TYPES.ENTITY;
            if (cellValue?.ValueType) {
              valueType = cellValue.ValueType;
            } else {
              const rowValue: any = rowData;
              valueType = rowValue?.ValueType;
            }
            if (valueType?.toLowerCase() === TABULATOR_VALUE_TYPES.TABLE) {
              this.tableTypeDoubleClickEvent.emit({ cell, level: this.level });
            }
            if (valueType?.toLowerCase() === TABULATOR_VALUE_TYPES.BLOCK) {
              this.opeBlockDailog(cell, cell.getValue(), 'edit', target);
            }
            if (valueType?.toLowerCase() === TABULATOR_VALUE_TYPES.IMAGE) {
              this.opeImageDailog(cell, cell.getValue(), 'edit', target);
            }
          }
        : null,
      cellEdited: function (cell: CellComponent) {
        if (cell.isEdited()) {
          const rowData: any = cell.getData();
          const field = cell.getField()?.split('.')[0];
          const cellValueObject: any = rowData[field];
          if (cellValueObject?.ColumnSSOT) {
            cellValueObject.IsModified = true;
          } else {
            rowData.IsModified = true;
          }
          setTimeout(function () {
            cell.getRow().reformat();
          }, 3000);
        }
      },
    }));
    return [
      {
        rowHandle: true,
        formatter: 'handle',
        headerSort: false,
        frozen: true,
        width: 30,
        minWidth: 30,
        field: 'id',
        title: '',
      },
      ...updatedColumns,
    ];
  }

  initializeTable(): void {
    this.tabulatorTable = new Tabulator(
      this.tabulatorTableElementRef.nativeElement,
      {
        index: 'id',
        data: this.data,
        columns: this.getColumns(
          this.columns ?? [],
          this.getColumnContextMenus(this.columnContextMenuOptions),
          this.freezeUptoXColumns
        ),
        rowContextMenu: this.getRowContextMenus(this.rowContextMenuOptions),
        layout: 'fitColumns',
        reactiveData: true,
        history: true,
        movableRows: this.movableRows,
        movableColumns: this.movableColumns,
        frozenRows: this.freezeUptoXRows,
        groupBy: this.groupBy,
      }
    );
  }

  getRowContextMenus({
    addRowAbove,
    addRowBelow,
    deleteRow,
    customActions,
  }: RowContextMenuConfig) {
    const rowContextMenus: RowContextMenuSignature = [];
    if (addRowAbove) {
      rowContextMenus.push({
        label: 'Add a row above',
        action: (_e, row: RowComponent) => {
          const currRows = this.tabulatorTable.getData();
          const index = row.getPosition();
          if (index !== false && index >= 0) {
            currRows.splice(index - 1, 0, {});
            this.tabulatorTable.setData(currRows);
          }
        },
      });
    }
    if (addRowBelow) {
      rowContextMenus.push({
        label: 'Add a row below',
        action: (_e, row: RowComponent) => {
          const currRows = this.tabulatorTable.getData();
          const index = row.getPosition();
          if (index !== false && index >= 0) {
            currRows.splice(index, 0, {});
            this.tabulatorTable.setData(currRows);
          }
        },
      });
    }
    if (deleteRow) {
      rowContextMenus.push({
        label: 'Delete row',
        action: (_e, row: RowComponent) => {
          row.delete();
        },
      });
    }
    customActions?.forEach((action: MenuObject<RowComponent>) => {
      rowContextMenus.push(action);
    });
    return rowContextMenus;
  }

  getColumnContextMenus({
    edit,
    insertLeft,
    insertRight,
    delete: enableDelete,
    customActions,
  }: ColumnContextMenuConfig) {
    const headerContextMenu = [];
    if (edit) {
      headerContextMenu.push({
        label: 'Edit column Name',
        action: (_e, column: ColumnComponent) => {
          this.openColumnDialog(column, '', 'edit');
        },
      });
    }
    if (insertLeft) {
      headerContextMenu.push({
        label: 'Insert 1 column left',
        action: (_e, column: ColumnComponent) => {
          this.openColumnDialog(column, 'left', 'add');
        },
      });
    }
    if (insertRight) {
      headerContextMenu.push({
        label: 'Insert 1 column right',
        action: (_e, column: ColumnComponent) => {
          this.openColumnDialog(column, 'right', 'add');
        },
      });
    }
    if (enableDelete) {
      headerContextMenu.push({
        label: 'Delete column',
        action: (_e, column: ColumnComponent) => {
          column.delete();
        },
      });
    }
    customActions?.forEach((action: MenuObject<ColumnComponent>) => {
      headerContextMenu.push(action);
    });
    return headerContextMenu;
  }

  openColumnDialog(column: ColumnComponent, direction: string, state: string) {
    const dialogRef = this.dialog.open(ModalComponent, {
      data: { state: state },
    });
    const subscribeDialog = dialogRef.componentInstance.columnAdded.subscribe(
      (columnName: string) => {
        const existingColumns = this.tabulatorTable.getColumnDefinitions();
        const currentColumnIndex = existingColumns.findIndex(
          (currentColumn: ColumnDefinition) =>
            currentColumn.title === column.getDefinition().title
        );
        if (state === 'edit') {
          const currentData = this.tabulatorTable.getData();
          column.updateDefinition({ field: columnName, title: columnName });
          const updatedData = currentData.map((row) => {
            const currentCol = column.getDefinition().field;
            if (Object.prototype.hasOwnProperty.call(row, currentCol)) {
              row[columnName] = row[currentCol];
              delete row[currentCol];
            }
            return row;
          });
          this.tabulatorTable.setData(updatedData);
        } else if (state === 'add') {
          const newColumn = {
            title: columnName,
            field: columnName,
            headerContextMenu: this.getColumnContextMenus(
              this.columnContextMenuOptions
            ),
          };
          if (direction === 'left') {
            existingColumns.splice(currentColumnIndex, 0, newColumn);
          } else if (direction === 'right') {
            existingColumns.splice(currentColumnIndex + 1, 0, newColumn);
          }
          const columns = this.getColumns(
            existingColumns ?? [],
            this.getColumnContextMenus(this.columnContextMenuOptions),
            this.freezeUptoXColumns
          );
          this.tabulatorTable.setColumns(columns);
          this.tabulatorTable.scrollToColumn(columnName);
        }
      }
    );
    dialogRef.afterClosed().subscribe(() => {
      subscribeDialog.unsubscribe();
    });
  }

  opeBlockDailog(
    cell: CellComponent,
    value: string,
    state: string,
    target: ElementRef
  ) {
    const currRows = cell.getData();
    const dialogRef = this.dialog.open(BlockModalComponent, {
      data: {
        state: state,
        value: value,
        isView: !this.isEditMode,
        rowData: currRows,
        trigger: target,
      },
    });
    const subscribeDialog = dialogRef.componentInstance.editCellValue.subscribe(
      (cellValue: string) => {
        const columnName = cell.getField();
        const currentCol: any = cell.getData();
        currentCol[columnName] = cellValue;
        if (value != cellValue) {
          currentCol.IsModified = true;
        }
        setTimeout(function () {
          cell.getRow().reformat();
        }, 3000);
      }
    );
    dialogRef.afterClosed().subscribe(() => {
      subscribeDialog.unsubscribe();
    });
  }

  opeImageDailog(
    cell: CellComponent,
    value: string,
    state: string,
    target: ElementRef
  ) {
    const dialogRef = this.dialog.open(ImageBlockModalComponent, {
      data: {
        columnName: cell.getField(),
        value: value,
        isView: !this.isEditMode,
        state: state,
        rowData: cell.getData(),
        trigger: target,
      },
    });
    const subscribeDialog =
      dialogRef.componentInstance.deleteCellValue.subscribe(
        (cellValue: string) => {
          const columnName = cell.getField();
          const currentCol: any = cell.getData();
          currentCol[columnName] = '';
          if (value != cellValue) {
            currentCol.IsModified = true;
          }
          setTimeout(function () {
            cell.getRow().reformat();
          }, 3000);
        }
      );
    dialogRef.afterClosed().subscribe(() => {
      subscribeDialog.unsubscribe();
    });
  }
}
