import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import {
  Column,
  ColumnContextMenuConfig,
  RowContextMenuConfig,
} from './interfaces/tabulator-config.interface';
import { GroupArg } from 'tabulator-tables';
import { ActionMenu, MenuItem } from './interfaces/action-menu.interface';
import { TabulatorTableComponent } from './tabulator-table/tabulator-table.component';
import { DocumentService } from 'src/app/services/document.service';
import { TabulatorMenuComponent } from './tabulator-menu/tabulator-menu.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatMenuModule } from '@angular/material/menu';
import { MatTabsModule } from '@angular/material/tabs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tabulator',
  templateUrl: './tabulator.component.html',
  styleUrls: ['./tabulator.component.scss'],
  standalone: true,
  imports: [
    TabulatorMenuComponent,
    MatExpansionModule,
    MatTabsModule,
    MatDialogModule,
    MatMenuModule,
    CommonModule,
    TabulatorTableComponent,
  ],
})
export class TabulatorComponent implements OnInit {
  @Input() data = [];
  @Input() columns: Column[] = [];
  @Input() primaryTableRowContextMenuOptions: RowContextMenuConfig = {
    addRowAbove: false,
    addRowBelow: false,
    deleteRow: false,
  };
  @Input() childTableRowContextMenuOptions: RowContextMenuConfig = {
    addRowAbove: true,
    addRowBelow: true,
    deleteRow: true,
  };
  @Input() primaryTableColumnContextMenuOptions: ColumnContextMenuConfig = {
    edit: true,
    insertLeft: true,
    insertRight: true,
    delete: true,
  };
  @Input() childTableColumnContextMenuOptions: ColumnContextMenuConfig = {
    edit: true,
    insertLeft: true,
    insertRight: true,
    delete: true,
  };
  @Input() freezeUptoXRows = 0;
  @Input() freezeUptoXColumns = 0;
  @Input() groupBy: GroupArg;
  @Input() movableRows = false;
  @Input() movableColumns = false;
  @Input() actionMenu: ActionMenu;
  @Input() childDocumentId = '';
  @Output() saveDataEvent: EventEmitter<unknown[]> = new EventEmitter();

  @ViewChildren(TabulatorTableComponent)
  tabulatorTableListRef: QueryList<TabulatorTableComponent>;

  leftMenu: MenuItem[] = [];
  rightMenu: MenuItem[] = [];
  enableFilter = false;
  isEditMode = false;
  secondaryTabs = [];
  selectedTabIndex = 0;
  level = 0;

  constructor(private documentService: DocumentService) {}

  ngOnInit(): void {
    this.leftMenu = this.actionMenu?.left || [];
    const rightMenu: MenuItem[] = [
      {
        label: 'Edit',
        icon: 'feather icon-edit',
        disabled: !this.actionMenu.right.edit,
        action: () => {
          this.toggleEditMode();
        },
      },
      {
        label: 'Filter',
        icon: 'feather icon-filter',
        disabled: !this.actionMenu.right.filter,
        action: () => {
          this.toggleFilters();
        },
      },
      {
        label: 'Save',
        icon: 'feather icon-save',
        disabled: !this.actionMenu.right.edit,
        action: () => {
          this.handleSaveAction();
        },
      },
    ];
    if (this.actionMenu.right.custom?.length > 0) {
      rightMenu.push(...this.actionMenu.right.custom);
    }
    this.rightMenu = rightMenu;
  }

  toggleFilters() {
    this.enableFilter = !this.enableFilter;
  }

  toggleEditMode() {
    this.isEditMode = !this.isEditMode;
  }

  async handleSaveAction() {
    const tableSaveRequest: any = {
      childDocumentId: this.childDocumentId,
      tables: [],
    };
    for (let index = 0; index < this.secondaryTabs.length; index++) {
      const secondaryTab = this.secondaryTabs[index];
      const tableData = {
        id: secondaryTab.tableId,
        data: { Value: [] },
      };
      (secondaryTab.data ?? []).forEach((column) => {
        const tableColumns = [];
        Object.keys(column).map((key) => {
          const cellData = column[key];
          if (cellData) {
            tableColumns.push(cellData);
          }
        });
        tableData.data.Value.push({
          RowValue: tableColumns,
          ValueCoordinates: [],
        });
      });

      tableSaveRequest.tables.push(tableData);
    }

    await this.documentService.updateChildTableDataById(tableSaveRequest);

    this.saveDataEvent.emit(
      this.tabulatorTableListRef.first.tabulatorTable.getData()
    );
  }

  async handleTableTypeClickEvent(eventData: any) {
    const tabs = [];
    for (let i = 0; i < eventData.level; i++) {
      tabs.push(this.secondaryTabs[i]);
    }
    tabs.push({
      label: 'Table',
      level: eventData.level + 1,
      columns: [],
      data: [],
      tableId: eventData?.cell?.getValue(),
    });
    this.selectedTabIndex = eventData.level + 1;
    this.secondaryTabs = tabs;
    const tabulatorData = await this.getTableData(eventData?.cell?.getValue());
    tabs[tabs.length - 1] = {
      ...tabs[tabs.length - 1],
      data: tabulatorData.data,
      columns: tabulatorData.columns,
    };
    this.secondaryTabs = tabs;
  }

  async getTableData(tableId: string) {
    try {
      const tableDataResponse = await this.documentService.getTableDataById(
        tableId
      );
      const tableData = tableDataResponse?.data?.JSONData?.Value || [];
      const tabulatorData = tableData;
      return this.prepareTabulatorData(tabulatorData);
    } catch {
      return {
        columns: [],
        data: [],
      };
    }
  }

  prepareTabulatorData(tableData: any[]) {
    const columns: Column[] = [],
      data = [];
    tableData.forEach((row) => {
      const dataRow = {};
      (row.RowValue ?? []).forEach((cellData: any) => {
        const columnIndex = columns.findIndex(
          (c) => c.title === cellData.ColumnSSOT
        );
        if (columnIndex == -1) {
          columns.push({
            title: cellData.ColumnSSOT,
            field: `${cellData.ColumnSSOT}.Value`,
            editor: 'input',
          });
        }
        dataRow[cellData.ColumnSSOT] = cellData;
      });
      data.push(dataRow);
    });
    return {
      columns,
      data,
    };
  }
}
