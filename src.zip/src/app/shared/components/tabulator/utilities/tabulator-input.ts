import { TABULATOR_VALUE_TYPES } from '../constants/tabulator.constant';

export function tabulatorInput(
  cell: any,
  onRendered: any,
  success: any,
  cancel: any,
  editorParams: any,
  isEditMode: any,
  column: any
) {
  const input = document.createElement('input');
  let cellValue = cell.getValue();
  if (!isEditMode || !cell.getElement()) {
    input.readOnly = true;
  }

  const field = cell.getField()?.split('.')[0];
  const rowData = cell.getData();
  const cellValueRecord: any = rowData[field];
  let valueType = TABULATOR_VALUE_TYPES.ENTITY;
  if (cellValueRecord?.ValueType) {
    valueType = cellValueRecord.ValueType;
  } else {
    const rowValue: any = rowData;
    valueType = rowValue?.ValueType;
  }
  if (valueType?.toLowerCase() !== TABULATOR_VALUE_TYPES.ENTITY) {
    input.readOnly = true;
  }

  input.value = typeof cellValue !== 'undefined' ? cellValue : '';

  input.setAttribute('type', editorParams.search ? 'search' : 'text');
  if (!column?.hasTabularData && !input.readOnly) {
    if (cellValueRecord?.ValueType) {
      input.readOnly = false;
    } else {
      input.readOnly = true;
    }
  }

  input.style.padding = '4px';
  input.style.width = '100%';
  input.style.boxSizing = 'border-box';

  if (
    editorParams.elementAttributes &&
    typeof editorParams.elementAttributes == 'object'
  ) {
    for (let key in editorParams.elementAttributes) {
      if (key.charAt(0) == '+') {
        key = key.slice(1);
        input.setAttribute(
          key,
          input.getAttribute(key) + editorParams.elementAttributes['+' + key]
        );
      } else {
        input.setAttribute(key, editorParams.elementAttributes[key]);
      }
    }
  }

  onRendered(function () {
    // if(cell.getType() === "cell"){
    input.focus({ preventScroll: true });
    input.style.height = '100%';

    if (editorParams.selectContents) {
      input.select();
    }
    // }
  });

  function onChange(e) {
    if (
      ((cellValue === null || typeof cellValue === 'undefined') &&
        input.value !== '') ||
      input.value !== cellValue
    ) {
      if (success(input.value)) {
        cellValue = input.value; //persist value if successfully validated incase editor is used as header filter
      }
    } else {
      cancel();
    }
  }

  //submit new value on blur or change
  input.addEventListener('change', onChange);
  input.addEventListener('blur', onChange);

  //submit new value on enter
  input.addEventListener('keydown', function (e) {
    switch (e.keyCode) {
      // case 9:
      case 13:
        onChange(e);
        break;

      case 27:
        cancel();
        break;

      case 35:
      case 36:
        e.stopPropagation();
        break;
    }
  });

  if (editorParams.mask) {
    maskInput(input, editorParams);
  }

  return input;
}

function maskInput(el, options) {
  const mask = options.mask,
    maskLetter =
      typeof options.maskLetterChar !== 'undefined'
        ? options.maskLetterChar
        : 'A',
    maskNumber =
      typeof options.maskNumberChar !== 'undefined'
        ? options.maskNumberChar
        : '9',
    maskWildcard =
      typeof options.maskWildcardChar !== 'undefined'
        ? options.maskWildcardChar
        : '*';

  function fillSymbols(index) {
    const symbol = mask[index];
    if (
      typeof symbol !== 'undefined' &&
      symbol !== maskWildcard &&
      symbol !== maskLetter &&
      symbol !== maskNumber
    ) {
      el.value = el.value + '' + symbol;
      fillSymbols(index + 1);
    }
  }

  el.addEventListener('keydown', (e) => {
    const index = el.value.length,
      char = e.key;

    if (e.keyCode > 46 && !e.ctrlKey && !e.metaKey) {
      if (index >= mask.length) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      } else {
        switch (mask[index]) {
          case maskLetter:
            if (char.toUpperCase() == char.toLowerCase()) {
              e.preventDefault();
              e.stopPropagation();
              return false;
            }
            break;

          case maskNumber:
            if (isNaN(char)) {
              e.preventDefault();
              e.stopPropagation();
              return false;
            }
            break;

          case maskWildcard:
            break;

          default:
            if (char !== mask[index]) {
              e.preventDefault();
              e.stopPropagation();
              return false;
            }
        }
      }
    }

    return;
  });

  el.addEventListener('keyup', (e) => {
    if (e.keyCode > 46) {
      if (options.maskAutoFill) {
        fillSymbols(el.value.length);
      }
    }
  });

  if (!el.placeholder) {
    el.placeholder = mask;
  }

  if (options.maskAutoFill) {
    fillSymbols(el.value.length);
  }
}
