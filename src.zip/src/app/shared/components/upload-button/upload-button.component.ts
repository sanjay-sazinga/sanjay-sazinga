import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  FileUploadControl,
  FileUploadModule,
  FileUploadValidators,
} from '@iplab/ngx-file-upload';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-upload-button',
  templateUrl: './upload-button.component.html',
  styleUrls: ['./upload-button.component.scss'],
  standalone:true,
  imports:[CommonModule,FormsModule,FileUploadModule]
})
export class UploadButtonComponent {
  @Input() fileUploadLimit: number = 5;
  @Output() uploadFileEvent = new EventEmitter();
  uploadedFiles: File[] = [];
  error: boolean = false;
  public fileUploadControl = new FileUploadControl(
    null,
    FileUploadValidators.filesLimit(this.fileUploadLimit)
  );

  emitSelectedFiles() {
    if (this.fileUploadControl.getError().length > 0) {
      this.error = true;
      Swal.fire({
        title: 'File Upload Limit Reached!',
        text:
          'Please upload only ' + this.fileUploadLimit + ' documents at a time',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false,
      });
    } else if (this.uploadedFiles?.length == 0) {
      this.error = true;
      Swal.fire({
        title: 'File Not uploaded!',
        text: 'Please upload atleast One file to proceed',
        icon: 'error',
        timer: 2500,
        showConfirmButton: false,
      });
    } else {
      this.uploadFileEvent.emit(this.uploadedFiles);
    }
  }

  removeAll() {
    this.fileUploadControl.clear();
  }
}
