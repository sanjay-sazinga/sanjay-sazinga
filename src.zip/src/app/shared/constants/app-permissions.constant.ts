export const APP_PERMISSIONS: Readonly<Record<string, string>> = {
  IS_DELETED: 'is-deleted',
  DELETE_DOCUMENTS: 'delete-documents',
  VIEW_DOCUMENTS: 'view-documents',
  RESTORE_DOCUMENTS: 'restore-documents',
  REDIGITIZE_DOCUMENT: 'redigitize-document',
  DOWNLOAD_DIGITIZED: 'download-digitized',
  VIEW_PROCESSED_DOC: 'viewprocessed-doc',
  RETRIEVE_CLIENTS: 'retrieve-clients',
};
