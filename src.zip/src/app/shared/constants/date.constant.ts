export const DATE_FORMATS: Record<
  string,
  Record<string, Record<string, string>>
> = {
  MAT_DATE_FORMAT: {
    parse: {
      dateInput: 'LL',
    },
    display: {
      dateInput: 'MMM DD YYYY',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'MMMM YYYY',
    },
  },
};
