import { ShowIfAuthorizedDirective } from './show-if-authorized.directive';

describe('ShowIfAuthorizedDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowIfAuthorizedDirective();
    expect(directive).toBeTruthy();
  });
});
