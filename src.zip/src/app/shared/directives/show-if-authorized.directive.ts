import {
  Directive,
  ElementRef,
  Input,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Directive({
  selector: '[showIfAuthorized]',
  standalone: true,
})
export class ShowIfAuthorizedDirective {
  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private router: Router,
    private userService: UserService
  ) {}

  @Input()
  set showIfAuthorized(permission: string) {
    const url = this.router.url?.substring(1);
    const doesUserHaveAccess = this.userService.doesUserHaveAccess(
      url,
      permission
    );
    if (doesUserHaveAccess) {
      this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }
}
