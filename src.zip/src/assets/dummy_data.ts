export const dummy_data = {
  results: [
    {
      key: 'firstname',
      value: 'Urjit',
      type: 'text',
    },
    {
      key: 'lastname',
      value: 'Desai',
      type: 'text',
    },
    {
      key: 'company',
      value: 'Scry AI',
      type: 'text',
    },
    {
      key: 'age',
      value: '24',
      type: 'text',
    },
    {
      key: 'bio',
      value:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
      type: 'block',
    },
    {
      key: 'address',
      type: 'table',
      value: [
        {
          key: 'street address',
          value: '1234 Hogwarts Lane',
          type: 'text',
        },
        {
          key: 'Apt No.',
          value: '#10-007',
          type: 'text',
        },
        {
          key: 'City',
          value: 'San Jose',
          type: 'text',
        },
        {
          key: 'State',
          value: 'CA',
          type: 'text',
        },
      ],
    },
  ],
};

export const test_data = {
  results: [
    {
      SSOTKey: 'Invoice No',
      Category: 'Invoice',
      Value: 'QQF3762',
      ValueCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      DocKey: 'invoice # qqf printable invoice',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      RawValue: 'QQF3762',
      ValueType: 'entity',
    },
    {
      SSOTKey: 'Customer No',
      Category: 'Invoice',
      Value:
        '190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295',
      ValueCoordinates: [
        {
          scaled_x_start: 0.5161340252250001,
          scaled_y_start: 0.17911186603600002,
          scaled_x_end: 0.6941706339520001,
          scaled_y_end: 0.189368064957,
          page_n: 0,
        },
      ],
      DocKey: 'purchased by customer #',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.562899620704,
          scaled_y_start: 0.165925305299,
          scaled_x_end: 0.711384343166,
          scaled_y_end: 0.176181504221,
          page_n: 0,
        },
      ],
      RawValue:
        '190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295',
      ValueType: 'block',
    },
    {
      SSOTKey: 'Customer Address',
      Category: 'Invoice',
      Value: '2635 N First St, San Jose, 95134',
      ValueCoordinates: [
        {
          scaled_x_start: 0.5161340252250001,
          scaled_y_start: 0.17911186603600002,
          scaled_x_end: 0.6941706339520001,
          scaled_y_end: 0.189368064957,
          page_n: 0,
        },
      ],
      DocKey: 'customer billing address',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.562899620704,
          scaled_y_start: 0.165925305299,
          scaled_x_end: 0.711384343166,
          scaled_y_end: 0.176181504221,
          page_n: 0,
        },
      ],
      RawValue:
        '190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295',
      ValueType: 'entity',
    },
    {
      SSOTKey: 'Customer Contact',
      Category: 'Invoice',
      Value: '9876543210',
      ValueCoordinates: [
        {
          scaled_x_start: 0.5161340252250001,
          scaled_y_start: 0.17911186603600002,
          scaled_x_end: 0.6941706339520001,
          scaled_y_end: 0.189368064957,
          page_n: 0,
        },
      ],
      DocKey: 'customer phone number',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.562899620704,
          scaled_y_start: 0.165925305299,
          scaled_x_end: 0.711384343166,
          scaled_y_end: 0.176181504221,
          page_n: 0,
        },
      ],
      RawValue: '9876543210',
      ValueType: 'entity',
    },
    {
      ValueType: 'image_block',
      SSOTKey: 'image_block',
      Category: 'Invoice',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      Value: {
        blob: '',
        cloud_url: '',
      },
    },
    {
      SSOTKey: 'main_summary',
      DocKey: 'Summary Table',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      ValueType: 'table',
      Value: [
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
        ],
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
          {
            Value: 2000.0,
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Total',
            RawValue: '$2000',
            DocKey: 'amount',
          },
        ],
      ],
    },
    {
      SSOTKey: 'second_summary',
      DocKey: 'Summary Table',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      ValueType: 'table',
      Value: [
        [
          {
            Value: 'Scry AI',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Company',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
        ],
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
          {
            Value: 12345.0,
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Total',
            RawValue: '$2000',
            DocKey: 'amount',
          },
        ],
      ],
    },
    {
      SSOTKey: 'Invoice No',
      Category: 'Vendor',
      Value: 'inv1234',
      ValueCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      DocKey: 'invoice # qqf printable invoice',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      RawValue: 'inv1234',
      ValueType: 'entity',
    },
    {
      SSOTKey: 'Vendor Contact',
      Category: 'Vendor',
      Value: '1234512345',
      ValueCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      DocKey: 'vendor contact details',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      RawValue: '1234512345',
      ValueType: 'entity',
    },
    {
      SSOTKey: 'vendor address',
      Category: 'Vendor',
      Value: '1123 W 37th Dr, Apt 10, Los Angeles, CA- 90007',
      ValueCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      DocKey: 'vendor street address',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      RawValue: '1123 W 37th Dr, Apt 10, Los Angeles, CA- 90007',
      ValueType: 'entity',
    },
    {
      SSOTKey: 'description',
      Category: 'Vendor',
      Value: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In massa tempor nec feugiat nisl pretium. Morbi leo urna molestie at. Cras pulvinar mattis nunc sed blandit libero volutpat. Facilisis magna etiam tempor orci eu. Feugiat sed lectus vestibulum mattis ullamcorper velit. Pellentesque elit eget gravida cum sociis natoque penatibus et. Facilisis sed odio morbi quis commodo odio. Orci phasellus egestas tellus rutrum tellus pellentesque. Id consectetur purus ut faucibus pulvinar elementum integer enim. Quis risus sed vulputate odio ut enim blandit volutpat maecenas. Nec tincidunt praesent semper feugiat nibh sed pulvinar. Convallis a cras semper auctor neque vitae tempus. Pretium vulputate sapien nec sagittis aliquam malesuada bibendum. Lectus vestibulum mattis ullamcorper velit. Sed risus ultricies tristique nulla aliquet enim tortor at. Odio aenean sed adipiscing diam donec adipiscing tristique. Tellus pellentesque eu tincidunt tortor.

Dictum sit amet justo donec. Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis. Tellus orci ac auctor augue mauris augue neque. Velit scelerisque in dictum non consectetur a erat. Morbi tempus iaculis urna id volutpat lacus laoreet non. Et netus et malesuada fames. Id semper risus in hendrerit gravida rutrum. Congue eu consequat ac felis donec et. Consequat interdum varius sit amet. Rhoncus dolor purus non enim praesent elementum facilisis leo. Pulvinar neque laoreet suspendisse interdum consectetur libero id faucibus nisl. Arcu non sodales neque sodales ut etiam sit amet.

Eget gravida cum sociis natoque penatibus et. Cursus mattis molestie a iaculis. At varius vel pharetra vel turpis nunc eget. Ultrices neque ornare aenean euismod. Hac habitasse platea dictumst quisque sagittis purus sit amet volutpat. Nisl nunc mi ipsum faucibus vitae aliquet nec ullamcorper. Libero id faucibus nisl tincidunt. Aenean sed adipiscing diam donec adipiscing tristique risus nec feugiat. Pellentesque nec nam aliquam sem et tortor consequat id. Et malesuada fames ac turpis egestas maecenas pharetra convallis posuere. Enim sed faucibus turpis in eu mi bibendum neque egestas. Facilisi nullam vehicula ipsum a arcu cursus vitae congue mauris. Gravida in fermentum et sollicitudin ac orci.`,
      ValueCoordinates: [
        {
          scaled_x_start: 0.5161340252250001,
          scaled_y_start: 0.17911186603600002,
          scaled_x_end: 0.6941706339520001,
          scaled_y_end: 0.189368064957,
          page_n: 0,
        },
      ],
      DocKey: 'purchased by customer #',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.562899620704,
          scaled_y_start: 0.165925305299,
          scaled_x_end: 0.711384343166,
          scaled_y_end: 0.176181504221,
          page_n: 0,
        },
      ],
      RawValue:
        '190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295',
      ValueType: 'block',
    },
    {
      ValueType: 'image_block',
      SSOTKey: 'image_block',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      Value: {
        blob: '',
        cloud_url: '',
      },
    },
    {
      SSOTKey: 'main_summary',
      DocKey: 'Summary Table',
      Category: 'Vendor',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      ValueType: 'table',
      Value: [
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
        ],
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
          {
            Value: 2000.0,
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Total',
            RawValue: '$2000',
            DocKey: 'amount',
          },
        ],
      ],
    },
    {
      SSOTKey: 'second_summary',
      DocKey: 'Summary Table',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      ValueType: 'table',
      Value: [
        [
          {
            Value: 'Scry AI',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Company',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
        ],
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
          {
            Value: 12345.0,
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Total',
            RawValue: '$2000',
            DocKey: 'amount',
          },
        ],
      ],
    },
    {
      SSOTKey: 'Invoice No',
      Value: 'QQF3762',
      ValueCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      DocKey: 'invoice # qqf printable invoice',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.047647737989,
          scaled_y_start: 0.205315753667,
          scaled_x_end: 0.243680093803,
          scaled_y_end: 0.21483937658399999,
          page_n: 0,
        },
      ],
      RawValue: 'QQF3762',
      ValueType: 'entity',
    },
    {
      SSOTKey: 'description',
      Value: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In massa tempor nec feugiat nisl pretium. Morbi leo urna molestie at. Cras pulvinar mattis nunc sed blandit libero volutpat. Facilisis magna etiam tempor orci eu. Feugiat sed lectus vestibulum mattis ullamcorper velit. Pellentesque elit eget gravida cum sociis natoque penatibus et. Facilisis sed odio morbi quis commodo odio. Orci phasellus egestas tellus rutrum tellus pellentesque. Id consectetur purus ut faucibus pulvinar elementum integer enim. Quis risus sed vulputate odio ut enim blandit volutpat maecenas. Nec tincidunt praesent semper feugiat nibh sed pulvinar. Convallis a cras semper auctor neque vitae tempus. Pretium vulputate sapien nec sagittis aliquam malesuada bibendum. Lectus vestibulum mattis ullamcorper velit. Sed risus ultricies tristique nulla aliquet enim tortor at. Odio aenean sed adipiscing diam donec adipiscing tristique. Tellus pellentesque eu tincidunt tortor.

Dictum sit amet justo donec. Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis. Tellus orci ac auctor augue mauris augue neque. Velit scelerisque in dictum non consectetur a erat. Morbi tempus iaculis urna id volutpat lacus laoreet non. Et netus et malesuada fames. Id semper risus in hendrerit gravida rutrum. Congue eu consequat ac felis donec et. Consequat interdum varius sit amet. Rhoncus dolor purus non enim praesent elementum facilisis leo. Pulvinar neque laoreet suspendisse interdum consectetur libero id faucibus nisl. Arcu non sodales neque sodales ut etiam sit amet.

Eget gravida cum sociis natoque penatibus et. Cursus mattis molestie a iaculis. At varius vel pharetra vel turpis nunc eget. Ultrices neque ornare aenean euismod. Hac habitasse platea dictumst quisque sagittis purus sit amet volutpat. Nisl nunc mi ipsum faucibus vitae aliquet nec ullamcorper. Libero id faucibus nisl tincidunt. Aenean sed adipiscing diam donec adipiscing tristique risus nec feugiat. Pellentesque nec nam aliquam sem et tortor consequat id. Et malesuada fames ac turpis egestas maecenas pharetra convallis posuere. Enim sed faucibus turpis in eu mi bibendum neque egestas. Facilisi nullam vehicula ipsum a arcu cursus vitae congue mauris. Gravida in fermentum et sollicitudin ac orci.`,
      ValueCoordinates: [
        {
          scaled_x_start: 0.5161340252250001,
          scaled_y_start: 0.17911186603600002,
          scaled_x_end: 0.6941706339520001,
          scaled_y_end: 0.189368064957,
          page_n: 0,
        },
      ],
      DocKey: 'purchased by customer #',
      DocKeyCoordinates: [
        {
          scaled_x_start: 0.562899620704,
          scaled_y_start: 0.165925305299,
          scaled_x_end: 0.711384343166,
          scaled_y_end: 0.176181504221,
          page_n: 0,
        },
      ],
      RawValue:
        '190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295 190108MATTHEW BOYLE12250295',
      ValueType: 'block',
    },
    {
      ValueType: 'image_block',
      SSOTKey: 'image_block',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      Value: {
        blob: '',
        cloud_url: '',
      },
    },
    {
      SSOTKey: 'main_summary',
      DocKey: 'Summary Table',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      ValueType: 'table',
      Value: [
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
        ],
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'details',
          },
          {
            Value: 2000.0,
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Total',
            RawValue: '$2000',
            DocKey: 'amount',
          },
        ],
      ],
    },
    {
      SSOTKey: 'second_summary',
      DocKey: 'Summary Table',
      ValueCoordinates: {
        scaled_x_start: 0.047647737989,
        scaled_y_start: 0.205315753667,
        scaled_x_end: 0.243680093803,
        scaled_y_end: 0.21483937658399999,
        page_n: 0,
      },
      ValueType: 'table',
      Value: [
        [
          {
            Value: 'Scry AI',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Company',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
            DocKey: 'company name',
          },
        ],
        [
          {
            Value: 'Web Development General Shopify / Magento Support Hours',
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Description',
            RawValue: 'Web Development General Shopify / Magento Support Hours',
          },
          {
            Value: 12345.0,
            ValueCoordinates: [
              {
                scaled_x_start: 0.08088235294117647,
                scaled_x_end: 0.3034313725490196,
                scaled_y_start: 0.313040398989899,
                scaled_y_end: 0.3372828232323232,
                page_n: 1,
              },
            ],
            RowSSOT: null,
            ColumnSSOT: 'Total',
            RawValue: '$2000',
            DocKey: 'amount payable',
          },
        ],
      ],
    },
  ],
};
