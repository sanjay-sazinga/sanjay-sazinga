export const environment = {
  production: true,
  serverUrl: "http://collatio-node-app.scryanalytics.com"
};
