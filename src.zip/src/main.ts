import { enableProdMode, importProvidersFrom } from '@angular/core';
import { environment } from './environments/environment';
import { BrowserModule, bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideRouter } from '@angular/router';
import { routes } from './app/app.route';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthInterceptorService } from './app/core/interceptors/auth-interceptor.service';
import { provideNgxMask } from 'ngx-mask';

if (environment.production) {
  enableProdMode();
}
  bootstrapApplication(AppComponent,{
    providers:[
      { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptorService, multi: true },
      provideRouter(routes),
      provideNgxMask(),
      importProvidersFrom(HttpClientModule),
      importProvidersFrom(BrowserModule),
      importProvidersFrom(BrowserAnimationsModule),
    ]
  })
